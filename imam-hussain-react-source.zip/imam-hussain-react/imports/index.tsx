import svgPaths from "./svg-7bk7opo5t3";
import imgWebsiteHeroSectionDesign2K2026080521181 from "./a90494661adcd34c73e554ce3b8fad3170b10e49.png";
import imgRectangle3051 from "./0d88dd0ad2ea613131f06bfca72f00811f379b85.png";
import imgRectangle3052 from "./4100d46915bb356063fffb5ea5bee7f8e947e3cd.png";
import imgRectangle3053 from "./40c9d2dbbaf141714e8b367c34196c6ef0d2a875.png";
import imgRectangle2966 from "./5a918e9c49cd4c593555dcffc0ae200d7700a342.png";
import imgRectangle2985 from "./37d39b34e2580b890c68ac69e0b376d89728d359.png";
import imgRectangle2986 from "./d3535001514499a96c1eadb0ae5aa767446bb1c0.png";
import imgRectangle2957 from "./875d9419e7b2e8dffbbfd44041ed66cfac110f0d.png";
import imgRectangle2988 from "./abaccf5102f58754e8c0541ffc3180a3e27ba495.png";
import imgRectangle2989 from "./69bb2487dd485d4cf091de293b2334489d1ec483.png";
import imgRectangle2923 from "./d61759b5cda884fa71c3e9210e6fc237abe62c79.png";
import imgImamAliLogoDark1 from "./de1d2429f1203fedb256c993b850adc2e0c5de83.png";
import imgThe12ThImamIcon1 from "./f791ab36623936774fff2b815963116256c8b030.png";

function FooterFinal({ className }: { className?: string }) {
  return (
    <div className={className || "h-[463px] relative w-[1920px]"} data-name="Footer-Final">
      <div className="absolute bg-[#212121] inset-0" />
      <div className="absolute bg-[#c81e1e] inset-[0_74.32%_10.37%_6.82%] rounded-bl-[300px] rounded-br-[300px]" />
      <p className="[word-break:break-word] absolute font-['Manrope:Regular',sans-serif] font-normal inset-[61.77%_76.98%_27.86%_9.32%] leading-[1.6] mix-blend-luminosity text-[#f4f1de] text-[15px] text-center whitespace-nowrap">
        Copyright © 2026 - imam-hussain.info
        <br aria-hidden />
        All rights reserved.
      </p>
      <div className="absolute content-stretch flex gap-[20px] inset-[65.23%_48.12%_22.25%_31.3%] items-center">
        <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
          <div className="col-1 ml-0 mt-0 relative row-1 size-[58px]">
            <svg className="absolute block inset-0 size-full" fill="none" height="58" preserveAspectRatio="none" viewBox="0 0 58 58" width="58">
              <circle cx="29" cy="29" fill="#C81E1E" id="Ellipse 1062" r="29" />
            </svg>
          </div>
          <div className="col-1 ml-[15px] mt-[15px] overflow-clip relative row-1 size-[28px]" data-name="mail 1">
            <div className="absolute contents inset-[16.67%_0]" data-name="Group">
              <div className="absolute contents inset-[16.67%_0]" data-name="Group">
                <div className="absolute inset-[16.67%_0]" data-name="Vector">
                  <svg className="absolute block inset-0 size-full" fill="none" height="18.6667" preserveAspectRatio="none" viewBox="0 0 28 18.6667" width="28">
                    <path d={svgPaths.p1a0243f0} fill="white" id="Vector" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
        <p className="[word-break:break-word] font-['Manrope:Light',sans-serif] font-light leading-[1.4] relative shrink-0 text-[30px] text-white tracking-[-0.6px] whitespace-nowrap" dir="auto">
          info@imam-hussain.info
        </p>
      </div>
      <div className="absolute flex inset-[13.82%_27.71%_21.17%_72.29%] items-center justify-center" style={{ containerType: "size" }}>
        <div className="flex-none h-[0px] rotate-90 w-[100cqh]">
          <div className="relative size-full">
            <div className="absolute inset-[-1px_0_0_0]">
              <svg className="block size-full" fill="none" height="1" preserveAspectRatio="none" viewBox="0 0 301 1" width="301">
                <line id="Line 14" opacity="0.1" stroke="#F3F3F3" x2="301" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute inset-[56.8%_11.77%_28.51%_76.56%]">
        <svg className="absolute block inset-0 size-full" fill="none" height="68" preserveAspectRatio="none" viewBox="0 0 224 68" width="224">
          <g id="Group 34338">
            <circle cx="34" cy="34" id="Ellipse 1063" opacity="0.3" r="33.5" stroke="white" />
            <circle cx="112" cy="34" id="Ellipse 1064" opacity="0.3" r="33.5" stroke="white" />
            <circle cx="190" cy="34" id="Ellipse 1065" opacity="0.3" r="33.5" stroke="white" />
            <g clipPath="url(#clip0_0_137)" id="facebook 1">
              <path d={svgPaths.p311ca970} fill="white" id="Vector" />
            </g>
            <g clipPath="url(#clip1_0_137)" id="instagram (1) 1">
              <path d={svgPaths.p1b148af0} fill="white" id="Vector_2" />
            </g>
            <g clipPath="url(#clip2_0_137)" id="twitter 1">
              <path d={svgPaths.p1c97de80} fill="white" id="Vector_3" />
            </g>
          </g>
          <defs>
            <clipPath id="clip0_0_137">
              <rect fill="white" height="33" transform="translate(16 19)" width="33" />
            </clipPath>
            <clipPath id="clip1_0_137">
              <rect fill="white" height="26" transform="translate(177 22)" width="26" />
            </clipPath>
            <clipPath id="clip2_0_137">
              <rect fill="white" height="27" transform="translate(100 21)" width="27" />
            </clipPath>
          </defs>
        </svg>
      </div>
      <div className="absolute inset-[19.06%_15.57%_51.7%_79.69%]" data-name="Union">
        <svg className="absolute block inset-0 size-full" fill="none" height="135.369" preserveAspectRatio="none" viewBox="0 0 91.001 135.369" width="91.001">
          <path d={svgPaths.p2d1cad00} fill="white" id="Union" opacity="0.1" />
        </svg>
      </div>
      <div className="[word-break:break-word] absolute content-stretch flex gap-[13px] inset-[13.82%_39.27%_67.82%_31.25%] items-center leading-[1.3] whitespace-nowrap">
        <div className="content-stretch flex flex-col items-start justify-center pr-[20px] py-[20px] relative rounded-[12px] shrink-0 w-[180px]" data-name="Navigation-Link">
          <p className="font-['Manrope:Bold',sans-serif] font-bold relative shrink-0 text-[#c81e1e] text-[11px] tracking-[0.44px] uppercase">CHAPTER 01</p>
          <p className="font-['DM_Serif_Display:Regular',sans-serif] not-italic relative shrink-0 text-[24px] text-white">Imam Hussain</p>
        </div>
        <div className="content-stretch flex flex-col items-start justify-center pr-[20px] py-[20px] relative rounded-[12px] shrink-0 w-[180px]" data-name="Navigation-Link">
          <p className="font-['Manrope:Bold',sans-serif] font-bold relative shrink-0 text-[#c81e1e] text-[11px] tracking-[0.44px] uppercase">CHAPTER 02</p>
          <p className="font-['DM_Serif_Display:Regular',sans-serif] not-italic relative shrink-0 text-[24px] text-white">Muharram</p>
        </div>
        <div className="content-stretch flex flex-col items-start justify-center pr-[20px] py-[20px] relative rounded-[12px] shrink-0 w-[180px]" data-name="Navigation-Link">
          <p className="font-['Manrope:Bold',sans-serif] font-bold relative shrink-0 text-[#c81e1e] text-[11px] tracking-[0.44px] uppercase">CHAPTER 03</p>
          <p className="font-['DM_Serif_Display:Regular',sans-serif] not-italic relative shrink-0 text-[24px] text-white">Karbala</p>
        </div>
      </div>
      <div className="[word-break:break-word] absolute content-stretch flex gap-[12px] inset-[35.85%_39.32%_45.79%_31.3%] items-center leading-[1.3] whitespace-nowrap">
        <div className="content-stretch flex flex-col items-start justify-center pr-[20px] py-[20px] relative rounded-[12px] shrink-0 w-[180px]" data-name="Navigation-Link">
          <p className="font-['Manrope:Bold',sans-serif] font-bold relative shrink-0 text-[#c81e1e] text-[11px] tracking-[0.44px] uppercase">CHAPTER 04</p>
          <p className="font-['DM_Serif_Display:Regular',sans-serif] not-italic relative shrink-0 text-[24px] text-white">Arbaeen</p>
        </div>
        <div className="content-stretch flex flex-col items-start justify-center pr-[20px] py-[20px] relative rounded-[12px] shrink-0 w-[180px]" data-name="Navigation-Link">
          <p className="font-['Manrope:Bold',sans-serif] font-bold relative shrink-0 text-[#c81e1e] text-[11px] tracking-[0.44px] uppercase">CHAPTER 05</p>
          <p className="font-['DM_Serif_Display:Regular',sans-serif] not-italic relative shrink-0 text-[24px] text-white">Lessons</p>
        </div>
        <div className="content-stretch flex flex-col items-start justify-center pr-[20px] py-[20px] relative rounded-[12px] shrink-0 w-[180px]" data-name="Navigation-Link">
          <p className="font-['Manrope:Bold',sans-serif] font-bold relative shrink-0 text-[#c81e1e] text-[11px] tracking-[0.44px] uppercase">CHAPTER 06</p>
          <p className="font-['DM_Serif_Display:Regular',sans-serif] not-italic relative shrink-0 text-[24px] text-white">Resources</p>
        </div>
      </div>
      <div className="absolute inset-[10.58%_79.49%_43.98%_12.03%]">
        <svg className="absolute block inset-0 size-full" fill="none" height="210.37" preserveAspectRatio="none" viewBox="0 0 162.847 210.37" width="162.847">
          <g id="Group 5">
            <path d={svgPaths.p396f3c00} fill="white" id="Union" />
            <path clipRule="evenodd" d={svgPaths.p3818470} fill="white" fillRule="evenodd" id="Vector" />
            <path clipRule="evenodd" d={svgPaths.p2aae1780} fill="white" fillRule="evenodd" id="Vector_2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function SiteHeaderFinal({ className }: { className?: string }) {
  return (
    <div className={className || "h-[160px] relative w-[1920px]"} data-name="site-header-Final">
      <div className="absolute bg-white inset-[0_46.51%_-1.88%_46.51%] rounded-bl-[100px] rounded-br-[100px]" />
      <div className="absolute bg-white content-stretch flex inset-[0_0_31.25%_0] items-start justify-between pb-[12px]">
        <div aria-hidden className="absolute border-b border-solid border-white inset-0 pointer-events-none" />
        <div className="content-stretch flex flex-col gap-[10px] items-start relative shrink-0 w-[700px]">
          <div className="flex items-center justify-center relative shrink-0 w-full">
            <div className="-scale-y-100 flex-none rotate-180 w-full">
              <div className="h-[8px] relative w-full">
                <svg className="absolute block inset-0 size-full" fill="none" height="8" preserveAspectRatio="none" viewBox="0 0 700 8" width="700">
                  <path d="M0 0H700V8H10.9375L0 0Z" fill="#C81E1E" id="Rectangle 3047" />
                </svg>
              </div>
            </div>
          </div>
          <div className="[word-break:break-word] content-stretch flex items-center justify-between leading-[1.3] not-italic pl-[100px] relative shrink-0 w-full">
            <div className="content-stretch flex flex-col items-start justify-center pr-[20px] py-[20px] relative rounded-[12px] shrink-0 w-[180px]" data-name="Navigation-Link">
              <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold relative shrink-0 text-[#c81e1e] text-[11px] tracking-[0.44px] uppercase whitespace-nowrap">CHAPTER 01</p>
              <p className="font-['DM_Serif_Display:Regular',sans-serif] relative shrink-0 text-[#212121] text-[24px] w-[150px]">Imam Hussain</p>
            </div>
            <div className="content-stretch flex flex-col items-start justify-center pr-[20px] py-[20px] relative rounded-[12px] shrink-0 w-[180px] whitespace-nowrap" data-name="Navigation-Link">
              <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold relative shrink-0 text-[#c81e1e] text-[11px] tracking-[0.44px] uppercase">CHAPTER 02</p>
              <p className="font-['DM_Serif_Display:Regular',sans-serif] relative shrink-0 text-[#212121] text-[24px]">Muharram</p>
            </div>
            <div className="content-stretch flex flex-col items-start justify-center pr-[20px] py-[20px] relative rounded-[12px] shrink-0 w-[180px] whitespace-nowrap" data-name="Navigation-Link">
              <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold relative shrink-0 text-[#c81e1e] text-[11px] tracking-[0.44px] uppercase">CHAPTER 03</p>
              <p className="font-['DM_Serif_Display:Regular',sans-serif] relative shrink-0 text-[#212121] text-[24px]">Karbala</p>
            </div>
          </div>
        </div>
        <div className="content-stretch flex items-start justify-center pt-[12px] relative shrink-0">
          <div className="h-[140px] relative shrink-0 w-[108.374px]">
            <svg className="absolute block inset-0 size-full" fill="none" height="140" preserveAspectRatio="none" viewBox="0 0 108.374 140" width="108.374">
              <g id="Group 4">
                <path d={svgPaths.p3867ec00} fill="#C81E1E" id="Union" />
                <path clipRule="evenodd" d={svgPaths.p6b41500} fill="black" fillRule="evenodd" id="Vector" />
                <path clipRule="evenodd" d={svgPaths.p2873a000} fill="#C81E1E" fillRule="evenodd" id="Vector_2" />
              </g>
            </svg>
          </div>
        </div>
        <div className="content-stretch flex flex-col gap-[10px] items-start relative shrink-0 w-[700px]">
          <div className="h-[8px] relative shrink-0 w-full">
            <svg className="absolute block inset-0 size-full" fill="none" height="8" preserveAspectRatio="none" viewBox="0 0 700 8" width="700">
              <path d="M0 0H700V8H10.9375L0 0Z" fill="#C81E1E" id="Rectangle 3047" />
            </svg>
          </div>
          <div className="content-stretch flex items-center justify-between pr-[100px] relative shrink-0 w-full">
            <div className="[word-break:break-word] content-stretch flex flex-col items-start justify-center leading-[1.3] not-italic pr-[20px] py-[20px] relative rounded-[12px] shrink-0 w-[180px] whitespace-nowrap" data-name="Navigation-Link">
              <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold relative shrink-0 text-[#c81e1e] text-[11px] tracking-[0.44px] uppercase">CHAPTER 04</p>
              <p className="font-['DM_Serif_Display:Regular',sans-serif] relative shrink-0 text-[#212121] text-[24px]">Arbaeen</p>
            </div>
            <div className="[word-break:break-word] content-stretch flex flex-col items-start justify-center leading-[1.3] not-italic pr-[20px] py-[20px] relative rounded-[12px] shrink-0 w-[180px] whitespace-nowrap" data-name="Navigation-Link">
              <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold relative shrink-0 text-[#c81e1e] text-[11px] tracking-[0.44px] uppercase">CHAPTER 05</p>
              <p className="font-['DM_Serif_Display:Regular',sans-serif] relative shrink-0 text-[#212121] text-[24px]">Lessons</p>
            </div>
            <div className="[word-break:break-word] content-stretch flex flex-col items-start justify-center leading-[1.3] not-italic pr-[20px] py-[20px] relative rounded-[12px] shrink-0 w-[180px] whitespace-nowrap" data-name="Navigation-Link">
              <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold relative shrink-0 text-[#c81e1e] text-[11px] tracking-[0.44px] uppercase">CHAPTER 06</p>
              <p className="font-['DM_Serif_Display:Regular',sans-serif] relative shrink-0 text-[#212121] text-[24px]">Resources</p>
            </div>
            <div className="overflow-clip relative shrink-0 size-[24px]" data-name="search-md">
              <div className="absolute inset-[12.5%]" data-name="Icon">
                <div className="absolute inset-[-5.56%]">
                  <svg className="block size-full" fill="none" height="20" preserveAspectRatio="none" viewBox="0 0 20 20" width="20">
                    <path d={svgPaths.p29ecb700} id="Icon" stroke="#212121" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex items-center justify-center pb-[2px] relative shrink-0">
      <p className="[word-break:break-word] font-['Manrope:Regular',sans-serif] font-normal leading-[1.6] relative shrink-0 text-[#212121] text-[15px] text-center whitespace-nowrap">Read Full Story</p>
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex items-center justify-center pb-[2px] relative shrink-0">
      <p className="[word-break:break-word] font-['Manrope:Regular',sans-serif] font-normal leading-[1.6] relative shrink-0 text-[#212121] text-[15px] text-center whitespace-nowrap">Read Full Story</p>
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex items-center justify-center pb-[2px] relative shrink-0">
      <p className="[word-break:break-word] font-['Manrope:Regular',sans-serif] font-normal leading-[1.6] relative shrink-0 text-[#212121] text-[15px] text-center whitespace-nowrap">Read Full Story</p>
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex items-center justify-center pb-[2px] relative shrink-0">
      <p className="[word-break:break-word] font-['Manrope:Regular',sans-serif] font-normal leading-[1.6] relative shrink-0 text-[#212121] text-[15px] text-center whitespace-nowrap">Read Full Story</p>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex items-center justify-center pb-[2px] relative shrink-0">
      <p className="[word-break:break-word] font-['Manrope:Regular',sans-serif] font-normal leading-[1.6] relative shrink-0 text-[#212121] text-[15px] text-center whitespace-nowrap">Read Full Story</p>
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex items-center justify-center pb-[2px] relative shrink-0">
      <p className="[word-break:break-word] font-['Manrope:Regular',sans-serif] font-normal leading-[1.6] relative shrink-0 text-[#212121] text-[15px] text-center whitespace-nowrap">Read Full Story</p>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-[179px] top-[173px]">
      <p className="[word-break:break-word] absolute font-['Manrope:Medium',sans-serif] font-medium leading-[0] left-[179px] not-italic text-[#836f5d] text-[0px] top-[173px] tracking-[-0.6px] whitespace-nowrap">
        <span className="font-['Inter:Regular',sans-serif] font-normal leading-none text-[#3a3a3a] text-[30px]">Chapter</span>
        <span className="font-['Inter:Regular',sans-serif] font-normal leading-none text-[#3a3a3a] text-[30px]">{` `}</span>
        <span className="font-['Inter:Regular',sans-serif] font-normal leading-none text-[#3a3a3a] text-[30px]">{`1: `}</span>
        <span className="font-['Inter:Regular',sans-serif] font-normal leading-none text-[#c81e1e] text-[30px]">Imam Hussain</span>
      </p>
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex items-center pb-[4px] relative shrink-0">
      <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[1.6] not-italic relative shrink-0 text-[#212121] text-[18px] whitespace-nowrap">Read Full Story</p>
    </div>
  );
}

function Frame7() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center left-[calc(4.17%+190.5px)] pb-[10px] pt-[12px] px-[32px] rounded-[8px] top-[623px]">
      <div aria-hidden className="absolute border-[#c81e1e] border-[1.5px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <Frame6 />
    </div>
  );
}

function Frame8() {
  return (
    <div className="absolute content-stretch flex gap-[6px] items-center left-[calc(50%+31px)] top-[1024px]">
      <div className="overflow-clip relative shrink-0 size-[14px]" data-name="clock">
        <div className="absolute inset-[8.33%]" data-name="Icon">
          <div className="absolute inset-[-6.43%]">
            <svg className="block size-full" fill="none" height="13.1667" preserveAspectRatio="none" viewBox="0 0 13.1667 13.1667" width="13.1667">
              <path d={svgPaths.p3bd66880} id="Icon" stroke="#707070" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            </svg>
          </div>
        </div>
      </div>
      <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[1.5] not-italic relative shrink-0 text-[#707070] text-[13px] whitespace-nowrap">5 min read</p>
    </div>
  );
}

function Frame9() {
  return (
    <div className="absolute content-stretch flex gap-[6px] items-center left-[calc(50%+31px)] top-[1303px]">
      <div className="overflow-clip relative shrink-0 size-[14px]" data-name="clock">
        <div className="absolute inset-[8.33%]" data-name="Icon">
          <div className="absolute inset-[-6.43%]">
            <svg className="block size-full" fill="none" height="13.1667" preserveAspectRatio="none" viewBox="0 0 13.1667 13.1667" width="13.1667">
              <path d={svgPaths.p3bd66880} id="Icon" stroke="#707070" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            </svg>
          </div>
        </div>
      </div>
      <p className="[word-break:break-word] font-['Inter:Regular',sans-serif] font-normal leading-[1.5] not-italic relative shrink-0 text-[#707070] text-[13px] whitespace-nowrap">5 min read</p>
    </div>
  );
}

function Frame10() {
  return (
    <div className="[word-break:break-word] content-stretch flex flex-col gap-[10px] items-start not-italic relative shrink-0 w-[326px]">
      <p className="font-['DM_Serif_Display:Regular',sans-serif] leading-[1.2] relative shrink-0 text-[#212121] text-[40px] tracking-[-0.8px] w-full">Imam Ali (A.S)</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.6] relative shrink-0 text-[#3a3a3a] text-[16px] w-full">Discover the life, wisdom, teachings, and legacy of Imam Ali (A.S.).</p>
    </div>
  );
}

function Frame13() {
  return (
    <div className="absolute content-stretch flex gap-[21px] items-center left-[calc(66.67%+14px)] top-[5265px]">
      <div className="h-[118px] relative shrink-0 w-[127px]" data-name="imam-ali-logo-dark 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImamAliLogoDark1} />
      </div>
      <Frame10 />
    </div>
  );
}

function Frame11() {
  return (
    <div className="[word-break:break-word] content-stretch flex flex-col gap-[7px] items-start not-italic relative shrink-0 w-[338px]">
      <p className="font-['DM_Serif_Display:Regular',sans-serif] leading-[1.2] relative shrink-0 text-[#212121] text-[40px] tracking-[-0.8px] w-full">Imam Mahdi (A.S)</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.6] relative shrink-0 text-[#3a3a3a] text-[16px] w-full">Discover the life, mission, and teachings of Imam Mahdi (A.S.), the awaited savior and Imam of our time.</p>
    </div>
  );
}

function Frame12() {
  return (
    <div className="absolute content-stretch flex gap-[31px] items-center left-[calc(66.67%+14px)] top-[5490px]">
      <div className="relative shrink-0 size-[100px]" data-name="the-12th-Imam-icon 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgThe12ThImamIcon1} />
      </div>
      <Frame11 />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-0 top-[5213px]">
      <div className="absolute bg-[rgba(6,144,96,0.05)] border border-[#068f60] border-solid h-[211px] left-[calc(66.67%-20px)] rounded-[24px] top-[5218px] w-[538px]" />
      <div className="absolute bg-[rgba(230,218,148,0.2)] border border-[#c2b56c] border-solid h-[211px] left-[calc(66.67%-20px)] rounded-[24px] top-[5451px] w-[538px]" />
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.4] left-[calc(4.17%+50px)] not-italic text-[#c81e1e] text-[28px] top-[5213px] whitespace-nowrap">MOST POPULAR</p>
      <p className="[word-break:break-word] absolute font-['Inter:Bold',sans-serif] font-bold leading-[1.3] left-[calc(4.17%+50px)] not-italic text-[#212121] text-[26px] top-[5311px] tracking-[-0.26px] whitespace-nowrap">Imam Hussain (A.S)</p>
      <p className="[word-break:break-word] absolute font-['Inter:Bold',sans-serif] font-bold leading-[1.3] left-[calc(29.17%-93px)] not-italic text-[#212121] text-[26px] top-[5311px] tracking-[-0.26px] whitespace-nowrap">{`Karbala & Muharram`}</p>
      <p className="[word-break:break-word] absolute font-['Inter:Bold',sans-serif] font-bold leading-[1.3] left-[calc(54.17%-193px)] not-italic text-[#212121] text-[26px] top-[5311px] tracking-[-0.26px] whitespace-nowrap">{`Teachings & Lessons`}</p>
      <div className="[word-break:break-word] absolute font-['Manrope:Medium',sans-serif] font-medium leading-[0] left-[calc(4.17%+85px)] text-[#212121] text-[20px] top-[5381px] whitespace-nowrap">
        <p className="leading-[1.6] mb-[14px]">Biography</p>
        <p className="leading-[1.6] mb-[14px]">{`Family & Lineage`}</p>
        <p className="leading-[1.6] mb-[14px]">Companions</p>
        <p className="leading-[1.6] mb-[14px]">{`Teachings & Letters`}</p>
        <p className="leading-[1.6]">{`Life & Legacy`}</p>
      </div>
      <div className="[word-break:break-word] absolute font-['Manrope:Medium',sans-serif] font-medium leading-[0] left-[calc(29.17%-48px)] text-[#212121] text-[20px] top-[5381px] whitespace-nowrap">
        <p className="leading-[1.6] mb-[14px]">Battle of Karbala</p>
        <p className="leading-[1.6] mb-[14px]">Events of Karbala</p>
        <p className="leading-[1.6] mb-[14px]">Martyrs of Karbala</p>
        <p className="leading-[1.6] mb-[14px]">Ashura</p>
        <p className="leading-[1.6]">Arbaeen</p>
      </div>
      <div className="[word-break:break-word] absolute font-['Manrope:Medium',sans-serif] font-medium leading-[0] left-[calc(54.17%-150px)] text-[#212121] text-[20px] top-[5381px] whitespace-nowrap">
        <p className="leading-[1.6] mb-[14px]">Moral Lessons</p>
        <p className="leading-[1.6] mb-[14px]">Quotes</p>
        <p className="leading-[1.6] mb-[14px]">{`Justice & Freedom`}</p>
        <p className="leading-[1.6] mb-[14px]">{`Patience & Faith`}</p>
        <p className="leading-[1.6]">{`Humanity & Peace`}</p>
      </div>
      <div className="absolute left-[138px] overflow-clip size-[20px] top-[5387px]" data-name="chevron-right">
        <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-9%_-18%]">
            <svg className="block size-full" fill="none" height="11.8" preserveAspectRatio="none" viewBox="0 0 6.8 11.8" width="6.8">
              <path d="M0.9 10.9L5.9 5.9L0.9 0.9" id="Icon" stroke="#C81E1E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[138px] overflow-clip size-[20px] top-[5433px]" data-name="chevron-right">
        <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-9%_-18%]">
            <svg className="block size-full" fill="none" height="11.8" preserveAspectRatio="none" viewBox="0 0 6.8 11.8" width="6.8">
              <path d="M0.9 10.9L5.9 5.9L0.9 0.9" id="Icon" stroke="#C81E1E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[138px] overflow-clip size-[20px] top-[5479px]" data-name="chevron-right">
        <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-9%_-18%]">
            <svg className="block size-full" fill="none" height="11.8" preserveAspectRatio="none" viewBox="0 0 6.8 11.8" width="6.8">
              <path d="M0.9 10.9L5.9 5.9L0.9 0.9" id="Icon" stroke="#C81E1E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[138px] overflow-clip size-[20px] top-[5525px]" data-name="chevron-right">
        <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-9%_-18%]">
            <svg className="block size-full" fill="none" height="11.8" preserveAspectRatio="none" viewBox="0 0 6.8 11.8" width="6.8">
              <path d="M0.9 10.9L5.9 5.9L0.9 0.9" id="Icon" stroke="#C81E1E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[138px] overflow-clip size-[20px] top-[5571px]" data-name="chevron-right">
        <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-9%_-18%]">
            <svg className="block size-full" fill="none" height="11.8" preserveAspectRatio="none" viewBox="0 0 6.8 11.8" width="6.8">
              <path d="M0.9 10.9L5.9 5.9L0.9 0.9" id="Icon" stroke="#C81E1E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[calc(16.67%+161px)] overflow-clip size-[20px] top-[5387px]" data-name="chevron-right">
        <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-9%_-18%]">
            <svg className="block size-full" fill="none" height="11.8" preserveAspectRatio="none" viewBox="0 0 6.8 11.8" width="6.8">
              <path d="M0.9 10.9L5.9 5.9L0.9 0.9" id="Icon" stroke="#C81E1E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[calc(41.67%+63px)] overflow-clip size-[20px] top-[5387px]" data-name="chevron-right">
        <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-9%_-18%]">
            <svg className="block size-full" fill="none" height="11.8" preserveAspectRatio="none" viewBox="0 0 6.8 11.8" width="6.8">
              <path d="M0.9 10.9L5.9 5.9L0.9 0.9" id="Icon" stroke="#C81E1E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[calc(16.67%+161px)] overflow-clip size-[20px] top-[5433px]" data-name="chevron-right">
        <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-9%_-18%]">
            <svg className="block size-full" fill="none" height="11.8" preserveAspectRatio="none" viewBox="0 0 6.8 11.8" width="6.8">
              <path d="M0.9 10.9L5.9 5.9L0.9 0.9" id="Icon" stroke="#C81E1E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[calc(41.67%+63px)] overflow-clip size-[20px] top-[5433px]" data-name="chevron-right">
        <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-9%_-18%]">
            <svg className="block size-full" fill="none" height="11.8" preserveAspectRatio="none" viewBox="0 0 6.8 11.8" width="6.8">
              <path d="M0.9 10.9L5.9 5.9L0.9 0.9" id="Icon" stroke="#C81E1E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[calc(16.67%+161px)] overflow-clip size-[20px] top-[5479px]" data-name="chevron-right">
        <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-9%_-18%]">
            <svg className="block size-full" fill="none" height="11.8" preserveAspectRatio="none" viewBox="0 0 6.8 11.8" width="6.8">
              <path d="M0.9 10.9L5.9 5.9L0.9 0.9" id="Icon" stroke="#C81E1E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[calc(41.67%+63px)] overflow-clip size-[20px] top-[5479px]" data-name="chevron-right">
        <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-9%_-18%]">
            <svg className="block size-full" fill="none" height="11.8" preserveAspectRatio="none" viewBox="0 0 6.8 11.8" width="6.8">
              <path d="M0.9 10.9L5.9 5.9L0.9 0.9" id="Icon" stroke="#C81E1E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[calc(16.67%+161px)] overflow-clip size-[20px] top-[5525px]" data-name="chevron-right">
        <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-9%_-18%]">
            <svg className="block size-full" fill="none" height="11.8" preserveAspectRatio="none" viewBox="0 0 6.8 11.8" width="6.8">
              <path d="M0.9 10.9L5.9 5.9L0.9 0.9" id="Icon" stroke="#C81E1E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[calc(41.67%+63px)] overflow-clip size-[20px] top-[5525px]" data-name="chevron-right">
        <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-9%_-18%]">
            <svg className="block size-full" fill="none" height="11.8" preserveAspectRatio="none" viewBox="0 0 6.8 11.8" width="6.8">
              <path d="M0.9 10.9L5.9 5.9L0.9 0.9" id="Icon" stroke="#C81E1E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[calc(16.67%+161px)] overflow-clip size-[20px] top-[5573px]" data-name="chevron-right">
        <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-9%_-18%]">
            <svg className="block size-full" fill="none" height="11.8" preserveAspectRatio="none" viewBox="0 0 6.8 11.8" width="6.8">
              <path d="M0.9 10.9L5.9 5.9L0.9 0.9" id="Icon" stroke="#C81E1E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[calc(41.67%+63px)] overflow-clip size-[20px] top-[5573px]" data-name="chevron-right">
        <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-9%_-18%]">
            <svg className="block size-full" fill="none" height="11.8" preserveAspectRatio="none" viewBox="0 0 6.8 11.8" width="6.8">
              <path d="M0.9 10.9L5.9 5.9L0.9 0.9" id="Icon" stroke="#C81E1E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
            </svg>
          </div>
        </div>
      </div>
      <FooterFinal className="absolute h-[463px] left-0 top-[5748px] w-[1920px]" />
      <Frame13 />
      <Frame12 />
    </div>
  );
}

export default function CategoryPage() {
  return (
    <div className="bg-white relative size-full" data-name="Category-Page">
      <div className="absolute bg-gradient-to-b from-[#edebdd] h-[744px] left-0 to-white top-0 w-[1920px]" />
      <div className="-translate-x-1/2 absolute bg-gradient-to-b from-[#edebdd] h-[407px] left-1/2 to-white top-[3025px] w-[1920px]" />
      <div className="-translate-x-1/2 absolute h-[680px] left-1/2 top-[3956px] w-[1920px]" data-name="Website_hero_section_design_2K_202608052118 1">
        <div aria-hidden className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0 overflow-hidden">
            <img alt="" className="absolute h-[185.29%] left-[-8.79%] max-w-none top-[-17.65%] w-[117.58%]" src={imgWebsiteHeroSectionDesign2K2026080521181} />
          </div>
          <div className="absolute inset-0" style={{ backgroundImage: "url(\"data:image/svg+xml;utf8,<svg viewBox='0 0 1920 680' xmlns='http://www.w3.org/2000/svg' preserveAspectRatio='none'><rect x='0' y='0' height='100%' width='100%' fill='url(%23grad)' opacity='0.800000011920929'/><defs><radialGradient id='grad' gradientUnits='userSpaceOnUse' cx='0' cy='0' r='10' gradientTransform='matrix(-1.0732e-13 46.268 -130.64 -1.6216e-7 960 217.32)'><stop stop-color='rgba(255,255,255,0)' offset='0.5'/><stop stop-color='rgba(255,255,255,1)' offset='0.75'/></radialGradient></defs></svg>\"), url(\"data:image/svg+xml;utf8,<svg viewBox='0 0 1920 680' xmlns='http://www.w3.org/2000/svg' preserveAspectRatio='none'><rect x='0' y='0' height='100%' width='100%' fill='url(%23grad)' opacity='0.800000011920929'/><defs><radialGradient id='grad' gradientUnits='userSpaceOnUse' cx='0' cy='0' r='10' gradientTransform='matrix(8.1841e-14 12.913 -55.135 1.5734e-13 960 473.76)'><stop stop-color='rgba(255,255,255,1)' offset='0.14966'/><stop stop-color='rgba(255,255,255,0)' offset='0.5'/></radialGradient></defs></svg>\"), linear-gradient(180deg, rgba(255, 255, 255, 0) 67.577%, rgba(255, 255, 255, 0.8) 79.079%)" }} />
        </div>
      </div>
      <div className="-translate-x-1/2 absolute h-[365px] left-[calc(12.5%+149px)] rounded-[24px] top-[4700px] w-[538px]">
        <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[24px]">
          <img alt="" className="absolute h-[262.04%] left-0 max-w-none top-[-35.54%] w-full" src={imgRectangle3051} />
        </div>
      </div>
      <div className="-translate-x-1/2 absolute h-[365px] left-[calc(87.5%-151px)] rounded-[24px] top-[4700px] w-[538px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[24px] size-full" src={imgRectangle3052} />
      </div>
      <div className="-translate-x-1/2 absolute h-[365px] left-1/2 rounded-[24px] top-[4700px] w-[540px]">
        <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[24px]">
          <img alt="" className="absolute h-[182.88%] left-0 max-w-none top-[-66.64%] w-full" src={imgRectangle3053} />
        </div>
      </div>
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['DM_Serif_Display:Regular',sans-serif] leading-[1.1] left-[calc(50%+0.5px)] not-italic text-[#212121] text-[55px] text-center top-[4471px] tracking-[-1.65px] whitespace-nowrap">A Glimpse of Paradise on Earth</p>
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[95px] leading-[1.6] left-1/2 not-italic text-[#3a3a3a] text-[18px] text-center top-[4566px] w-[898px]">For those who visit the shrine of Imam Hussain, the experience feels unlike anything they have ever known—a profound spiritual presence that touches the soul and feels like a glimpse of Paradise.</p>
      <div className="absolute bg-white h-[603px] left-[179px] rounded-[32px] shadow-[0px_60px_90px_0px_rgba(14,14,14,0.15)] top-[790px] w-[1561px]" />
      <div className="absolute h-[580px] left-[190px] rounded-[24px] top-[801px] w-[754px]">
        <div aria-hidden className="absolute inset-0 pointer-events-none rounded-[24px]">
          <img alt="" className="absolute max-w-none object-cover rounded-[24px] size-full" src={imgRectangle2966} />
          <div className="absolute bg-gradient-to-b from-[rgba(7,24,14,0)] inset-0 rounded-[24px] to-[#07180e] to-[76.839%]" />
        </div>
      </div>
      <div className="absolute h-[220px] left-[calc(83.33%-120px)] rounded-[24px] top-[821px] w-[221px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[24px] size-full" src={imgRectangle2985} />
      </div>
      <div className="absolute h-[220px] left-[calc(83.33%-120px)] rounded-[24px] top-[1120px] w-[221px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[24px] size-full" src={imgRectangle2986} />
      </div>
      <div className="absolute h-[48px] left-[calc(8.33%+163px)] top-[71px] w-[199px]" />
      <p className="[word-break:break-word] absolute font-['DM_Serif_Display:Regular',sans-serif] leading-[1.2] left-[176px] not-italic text-[#212121] text-[60px] top-[313px] tracking-[-1.8px] w-[740px]">The Major Occultation: The Awaited Savior’s Absence</p>
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['DM_Serif_Display:Regular',sans-serif] leading-[1.1] left-1/2 not-italic text-[#212121] text-[55px] text-center top-[3123px] tracking-[-1.65px] w-[858px]">You Might be Interested to Read</p>
      <p className="[word-break:break-word] absolute font-['DM_Serif_Display:Regular',sans-serif] h-[99px] leading-[1.2] left-[calc(16.67%-141px)] not-italic text-[#212121] text-[32px] top-[1874px] tracking-[-0.32px] w-[480px]">The Role of Believers During the Occultation</p>
      <p className="[word-break:break-word] absolute font-['DM_Serif_Display:Regular',sans-serif] h-[99px] leading-[1.2] left-[calc(16.67%-141px)] not-italic text-[#212121] text-[32px] top-[2640px] tracking-[-0.32px] w-[480px]">Imam Mahdi in Contemporary Times</p>
      <p className="[word-break:break-word] absolute font-['DM_Serif_Display:Regular',sans-serif] h-[99px] leading-[1.2] left-[calc(16.67%-141px)] not-italic text-[#212121] text-[32px] top-[3660px] tracking-[-0.32px] w-[480px]">Imam Mahdi in Contemporary Times</p>
      <p className="[word-break:break-word] absolute font-['DM_Serif_Display:Regular',sans-serif] h-[94px] leading-[1.2] left-[calc(50%-250px)] not-italic text-[#212121] text-[32px] top-[1874px] tracking-[-0.32px] w-[480px]">Comparing Imam Mahdi with Other Messianic Figures</p>
      <p className="[word-break:break-word] absolute font-['DM_Serif_Display:Regular',sans-serif] h-[94px] leading-[1.2] left-[calc(50%-250px)] not-italic text-[#212121] text-[32px] top-[2640px] tracking-[-0.32px] w-[480px]">The Awaited Future: Life Under Imam Mahdi’s Rule</p>
      <p className="[word-break:break-word] absolute font-['DM_Serif_Display:Regular',sans-serif] h-[94px] leading-[1.2] left-[calc(83.33%-360px)] not-italic text-[#212121] text-[32px] top-[2640px] tracking-[-0.32px] w-[480px]">The Minor Occultation: Imam Mahdi’s Hidden Communication</p>
      <p className="[word-break:break-word] absolute font-['DM_Serif_Display:Regular',sans-serif] h-[94px] leading-[1.2] left-[calc(83.33%-360px)] not-italic text-[#212121] text-[32px] top-[1874px] tracking-[-0.32px] w-[480px]">Imam Mahdi and the Return of Jesus Christ</p>
      <p className="[word-break:break-word] absolute font-['DM_Serif_Display:Regular',sans-serif] h-[94px] leading-[1.2] left-[calc(50%-250px)] not-italic text-[#212121] text-[32px] top-[3660px] tracking-[-0.32px] w-[480px]">The Awaited Future: Life Under Imam Mahdi’s Rule</p>
      <p className="[word-break:break-word] absolute font-['DM_Serif_Display:Regular',sans-serif] h-[94px] leading-[1.2] left-[calc(83.33%-360px)] not-italic text-[#212121] text-[32px] top-[3660px] tracking-[-0.32px] w-[480px]">The Minor Occultation: Imam Mahdi’s Hidden Communication</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[1.6] left-[calc(16.67%-141px)] not-italic text-[#323433] text-[16px] top-[1976px] w-[480px]">Examining the responsibilities of Muslims in maintaining faith, practicing righteousness, and preparing for Imam Mahdi’s return in a world filled with challenges and distractions.</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[1.6] left-[calc(50%-250px)] not-italic text-[#323433] text-[16px] top-[1976px] w-[480px]">A comparative study of Islamic, Christian, Jewish, and Eastern messianic prophecies, highlighting similarities and differences in their roles and missions.</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[1.5] left-[calc(62.5%-209px)] not-italic text-[#323433] text-[13px] top-[956px] w-[421px]">Imam al-Ridha’s (AS) hadith shows the Imam as a loving guide—like a father, brother, and friend. It reminds us of ...</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[1.5] left-[calc(62.5%-209px)] not-italic text-[#323433] text-[13px] top-[1240px] w-[421px]">Imam al-Ridha’s (AS) hadith shows the Imam as a loving guide—like a father, brother, and friend. It reminds us of ...</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[1.6] left-[calc(16.67%-141px)] not-italic text-[#323433] text-[16px] top-[2742px] w-[480px]">Examining modern perspectives on Imam Mahdi’s mission, how scholars interpret his role today, and the impact of his prophecy on global socio-political movements.</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[1.6] left-[calc(50%-250px)] not-italic text-[#323433] text-[16px] top-[2742px] w-[480px]">A vision of the world after Imam Mahdi’s return, including the establishment of absolute justice, the eradication of corruption, and the unity of all people under divine leadership.</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[1.6] left-[calc(83.33%-360px)] not-italic text-[#323433] text-[16px] top-[1976px] w-[480px]">Exploring the role of Prophet Isa (Jesus) alongside Imam Mahdi, their mission to restore justice, and how both figures are prophesied to work together in the end times.</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[1.6] left-[calc(16.67%-141px)] not-italic text-[#323433] text-[16px] top-[3762px] w-[480px]">Examining modern perspectives on Imam Mahdi’s mission, how scholars interpret his role today, and the impact of his prophecy on global socio-political movements.</p>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[1.6] left-[calc(83.33%-360px)] not-italic text-[#323433] text-[16px] top-[2742px] w-[480px]">A look at the 69-year period when Imam Mahdi remained in contact with his followers through four appointed deputies, guiding the community while remaining unseen.</p>
      <div className="absolute h-[300px] left-[180px] rounded-[24px] top-[1499px] w-[500px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[24px] size-full" src={imgRectangle2957} />
      </div>
      <div className="absolute h-[300px] left-[180px] rounded-[24px] top-[2265px] w-[500px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[24px] size-full" src={imgRectangle2957} />
      </div>
      <div className="absolute h-[300px] left-[calc(33.33%+70px)] rounded-[24px] top-[2265px] w-[500px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[24px] size-full" src={imgRectangle2988} />
      </div>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[1.6] left-[calc(50%-250px)] not-italic text-[#323433] text-[16px] top-[3762px] w-[480px]">A vision of the world after Imam Mahdi’s return, including the establishment of absolute justice, the eradication of corruption, and the unity of all people under divine leadership.</p>
      <div className="absolute h-[300px] left-[calc(66.67%-40px)] rounded-[24px] top-[2265px] w-[500px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[24px] size-full" src={imgRectangle2989} />
      </div>
      <div className="absolute h-[300px] left-[calc(33.33%+70px)] rounded-[24px] top-[1499px] w-[500px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[24px] size-full" src={imgRectangle2988} />
      </div>
      <div className="absolute h-[300px] left-[calc(66.67%-40px)] rounded-[24px] top-[1499px] w-[500px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[24px] size-full" src={imgRectangle2989} />
      </div>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal leading-[1.6] left-[calc(83.33%-360px)] not-italic text-[#323433] text-[16px] top-[3762px] w-[480px]">A look at the 69-year period when Imam Mahdi remained in contact with his followers through four appointed deputies, guiding the community while remaining unseen.</p>
      <div className="absolute h-[300px] left-[180px] rounded-[24px] top-[3281px] w-[500px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[24px] size-full" src={imgRectangle2957} />
      </div>
      <div className="absolute h-[300px] left-[calc(33.33%+70px)] rounded-[24px] top-[3281px] w-[500px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[24px] size-full" src={imgRectangle2988} />
      </div>
      <div className="absolute h-[42px] left-[179px] rounded-[8px] top-[2089px] w-[150px]" data-name="Button-Medium">
        <div aria-hidden className="absolute border-[#c81e1e] border-[1.5px] border-solid inset-0 pointer-events-none rounded-[8px]" />
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex items-center justify-center px-[32px] py-[12px] relative size-full">
            <Frame />
          </div>
        </div>
      </div>
      <div className="absolute h-[42px] left-[179px] rounded-[8px] top-[2849px] w-[150px]" data-name="Button-Medium">
        <div aria-hidden className="absolute border-[#c81e1e] border-[1.5px] border-solid inset-0 pointer-events-none rounded-[8px]" />
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex items-center justify-center px-[32px] py-[12px] relative size-full">
            <Frame1 />
          </div>
        </div>
      </div>
      <div className="absolute h-[42px] left-[calc(33.33%+70px)] rounded-[8px] top-[2089px] w-[150px]" data-name="Button-Medium">
        <div aria-hidden className="absolute border-[#c81e1e] border-[1.5px] border-solid inset-0 pointer-events-none rounded-[8px]" />
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex items-center justify-center px-[32px] py-[12px] relative size-full">
            <Frame2 />
          </div>
        </div>
      </div>
      <div className="absolute h-[42px] left-[calc(33.33%+70px)] rounded-[8px] top-[2849px] w-[150px]" data-name="Button-Medium">
        <div aria-hidden className="absolute border-[#c81e1e] border-[1.5px] border-solid inset-0 pointer-events-none rounded-[8px]" />
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex items-center justify-center px-[32px] py-[12px] relative size-full">
            <Frame3 />
          </div>
        </div>
      </div>
      <div className="absolute h-[42px] left-[calc(66.67%-40px)] rounded-[8px] top-[2089px] w-[150px]" data-name="Button-Medium">
        <div aria-hidden className="absolute border-[#c81e1e] border-[1.5px] border-solid inset-0 pointer-events-none rounded-[8px]" />
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex items-center justify-center px-[32px] py-[12px] relative size-full">
            <Frame4 />
          </div>
        </div>
      </div>
      <div className="absolute h-[42px] left-[calc(66.67%-40px)] rounded-[8px] top-[2849px] w-[150px]" data-name="Button-Medium">
        <div aria-hidden className="absolute border-[#c81e1e] border-[1.5px] border-solid inset-0 pointer-events-none rounded-[8px]" />
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex items-center justify-center px-[32px] py-[12px] relative size-full">
            <Frame5 />
          </div>
        </div>
      </div>
      <div className="absolute h-[300px] left-[calc(66.67%-40px)] rounded-[24px] top-[3281px] w-[500px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[24px] size-full" src={imgRectangle2989} />
      </div>
      <p className="[word-break:break-word] absolute font-['DM_Serif_Display:Regular',sans-serif] leading-[1.2] left-[calc(50%+31px)] not-italic text-[#212121] text-[32px] top-[874px] tracking-[-0.32px] w-[451px]">Media’s Role in Distorting Imam Mahdi’s (AS) Truth</p>
      <p className="[word-break:break-word] absolute font-['DM_Serif_Display:Regular',sans-serif] leading-[1.2] left-[calc(50%+31px)] not-italic text-[#212121] text-[32px] top-[1159px] tracking-[-0.32px] w-[411px]">Imam Mahdi in the Quran and Hadith</p>
      <div className="absolute h-0 left-[180px] top-[2198px] w-[1560px]">
        <div className="absolute inset-[-2px_0_0_0]">
          <svg className="block size-full" fill="none" height="2" preserveAspectRatio="none" viewBox="0 0 1560 2" width="1560">
            <line id="Line 10" opacity="0.1" stroke="#C81E1E" strokeWidth="2" x2="1560" y1="1" y2="1" />
          </svg>
        </div>
      </div>
      <div className="absolute h-[442px] left-[calc(50%+21px)] rounded-[24px] top-[264px] w-[757px]">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[24px] size-full" src={imgRectangle2923} />
      </div>
      <p className="[word-break:break-word] absolute font-['DM_Serif_Display:Regular',sans-serif] leading-[1.1] left-[253px] not-italic text-[55px] text-white top-[1138.1px] tracking-[-1.65px] w-[550px]">The Birth and Early Life of Imam Mahdi</p>
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] left-[calc(50%+31px)] not-italic text-[#c81e1e] text-[14px] top-[843px] tracking-[1.4px] w-[240px]">IMAM HUSSAIN</p>
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] left-[253px] not-italic text-[14px] text-white top-[1103px] tracking-[1.4px] w-[240px]">IMAM HUSSAIN</p>
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] left-[calc(50%+31px)] not-italic text-[#c81e1e] text-[14px] top-[1131px] tracking-[1.4px] w-[240px]">IMAM HUSSAIN</p>
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] left-[181px] not-italic text-[#c81e1e] text-[14px] top-[1843px] tracking-[1.4px] w-[240px]">IMAM HUSSAIN</p>
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] left-[181px] not-italic text-[#c81e1e] text-[14px] top-[2606px] tracking-[1.4px] w-[240px]">IMAM HUSSAIN</p>
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] left-[181px] not-italic text-[#c81e1e] text-[14px] top-[3625px] tracking-[1.4px] w-[240px]">IMAM HUSSAIN</p>
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] left-[calc(33.33%+70px)] not-italic text-[#c81e1e] text-[14px] top-[1843px] tracking-[1.4px] w-[240px]">IMAM HUSSAIN</p>
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] left-[calc(33.33%+70px)] not-italic text-[#c81e1e] text-[14px] top-[2606px] tracking-[1.4px] w-[240px]">IMAM HUSSAIN</p>
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] left-[calc(33.33%+70px)] not-italic text-[#c81e1e] text-[14px] top-[3625px] tracking-[1.4px] w-[240px]">IMAM HUSSAIN</p>
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] left-[calc(66.67%-40px)] not-italic text-[#c81e1e] text-[14px] top-[1843px] tracking-[1.4px] w-[240px]">IMAM HUSSAIN</p>
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] left-[calc(66.67%-40px)] not-italic text-[#c81e1e] text-[14px] top-[2606px] tracking-[1.4px] w-[240px]">IMAM HUSSAIN</p>
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[1.5] left-[calc(66.67%-40px)] not-italic text-[#c81e1e] text-[14px] top-[3625px] tracking-[1.4px] w-[240px]">IMAM HUSSAIN</p>
      <Group />
      <Frame7 />
      <div className="absolute h-0 left-[calc(41.67%+144px)] top-[1085px] w-[794px]">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" height="1" preserveAspectRatio="none" viewBox="0 0 794 1" width="794">
            <line id="Line 18" stroke="#E5E6E6" x2="794" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[180px] top-[254px] w-[152px]">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" height="1" preserveAspectRatio="none" viewBox="0 0 152 1" width="152">
            <line id="Line 19" opacity="0.4" stroke="#707070" x2="152" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[82px] leading-[1.6] left-[176px] not-italic text-[#212121] text-[20px] top-[485px] w-[669px]">Understanding why Imam Mahdi entered a prolonged occultation, how believers maintain their faith in his return, and what Islamic teachings say about his eventual reappearance.</p>
      <Frame8 />
      <Frame9 />
      <SiteHeaderFinal className="absolute h-[160px] left-0 top-0 w-[1920px]" />
      <Group1 />
    </div>
  );
}