<?php get_header(); ?>
<div class="ih-wrap" style="padding:64px 0">
    <p class="ih-section-eyebrow">SEARCH RESULTS</p>
    <h1 class="ih-section-title" style="margin-bottom:40px">
        <?php
        $query = get_search_query();
        if ($query) {
            printf('%d results for "%s"', $wp_query->found_posts, esc_html($query));
        } else {
            echo 'Search';
        }
        ?>
    </h1>
    <?php if (have_posts()): ?>
    <div class="ih-articles-grid">
        <?php while (have_posts()): the_post();
            $thumb = has_post_thumbnail() ? get_the_post_thumbnail_url(null, 'ih-card') : '';
            $cats  = get_the_terms(get_the_ID(), 'category');
            $cat   = ($cats && !is_wp_error($cats)) ? $cats[0] : null;
        ?>
        <article class="ih-article-card">
            <a href="<?php the_permalink(); ?>">
                <?php if ($thumb): ?>
                <div class="ih-article-card-img"><img src="<?php echo esc_url($thumb); ?>" alt="<?php the_title_attribute(); ?>"></div>
                <?php endif; ?>
                <?php if ($cat): ?><p class="cat-label"><?php echo esc_html($cat->name); ?></p><?php endif; ?>
                <h3><?php the_title(); ?></h3>
                <p class="excerpt"><?php echo wp_trim_words(get_the_excerpt(), 18); ?></p>
            </a>
        </article>
        <?php endwhile; ?>
    </div>
    <?php else: ?>
    <p style="color:#707070;font-family:'Inter',sans-serif">No results found. Try a different search term.</p>
    <?php endif; ?>
</div>
<?php get_footer();
