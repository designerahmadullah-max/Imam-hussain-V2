<?php
if (!defined('ABSPATH')) exit;

define('IH_THEME_VERSION', '3.0.0');
define('IH_THEME_URI', get_template_directory_uri());

/* ── Google Fonts & assets ── */
function ih_enqueue_assets() {
    wp_enqueue_style('ih-fonts',
        'https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Inter:wght@300;400;500;600&family=Manrope:wght@300;400;500;600&family=Merriweather:ital,wght@0,400;1,400&display=swap',
        [], null);
    wp_enqueue_style('ih-main', IH_THEME_URI . '/assets/css/main.css', ['ih-fonts'], IH_THEME_VERSION);
    wp_enqueue_script('ih-main', IH_THEME_URI . '/assets/js/main.js', ['jquery'], IH_THEME_VERSION, true);

    wp_localize_script('ih-main', 'ihAjax', [
        'url'   => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('ih_search_nonce'),
    ]);
}
add_action('wp_enqueue_scripts', 'ih_enqueue_assets');

/* ── Theme setup ── */
function ih_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption','style','script']);
    add_theme_support('customize-selective-refresh-widgets');

    register_nav_menus([
        'primary' => __('Primary Navigation', 'imam-hussain'),
        'footer'  => __('Footer Navigation', 'imam-hussain'),
    ]);

    add_image_size('ih-hero',    1920, 900, true);
    add_image_size('ih-card',     800, 600, true);
    add_image_size('ih-thumb',    220, 168, true);
}
add_action('after_setup_theme', 'ih_setup');

/* ── Custom post type ── */
function ih_register_cpt() {
    register_post_type('ih_article', [
        'labels'   => [
            'name'          => __('Articles', 'imam-hussain'),
            'singular_name' => __('Article', 'imam-hussain'),
            'add_new_item'  => __('Add New Article', 'imam-hussain'),
            'edit_item'     => __('Edit Article', 'imam-hussain'),
        ],
        'public'            => true,
        'show_in_rest'      => true,
        'has_archive'       => true,
        'supports'          => ['title','editor','thumbnail','excerpt','custom-fields','author'],
        'menu_icon'         => 'dashicons-book-alt',
        'rewrite'           => ['slug' => 'articles'],
    ]);
}
add_action('init', 'ih_register_cpt');

/* ── Customizer ── */
require_once get_template_directory() . '/inc/customizer.php';

/* ── Nav Walker ── */
require_once get_template_directory() . '/inc/nav-walker.php';

/* ── AJAX search ── */
function ih_ajax_search() {
    check_ajax_referer('ih_search_nonce', 'nonce');
    $query = sanitize_text_field($_POST['query'] ?? '');
    if (strlen($query) < 2) { wp_send_json_success([]); }

    $results = new WP_Query([
        's'              => $query,
        'post_type'      => ['post', 'ih_article'],
        'post_status'    => 'publish',
        'posts_per_page' => 6,
    ]);

    $data = [];
    if ($results->have_posts()) {
        while ($results->have_posts()) {
            $results->the_post();
            $cats = get_the_terms(get_the_ID(), 'category');
            $cat_name = ($cats && !is_wp_error($cats)) ? $cats[0]->name : '';
            $data[] = [
                'title'    => get_the_title(),
                'url'      => get_permalink(),
                'category' => $cat_name,
                'excerpt'  => wp_trim_words(get_the_excerpt(), 12),
            ];
        }
        wp_reset_postdata();
    }
    wp_send_json_success($data);
}
add_action('wp_ajax_ih_search', 'ih_ajax_search');
add_action('wp_ajax_nopriv_ih_search', 'ih_ajax_search');

/* ── Elementor compatibility notice ── */
function ih_elementor_notice() {
    if (!did_action('elementor/loaded') && current_user_can('install_plugins')) {
        echo '<div class="notice notice-warning is-dismissible"><p>';
        echo '<strong>Imam Hussain Theme:</strong> For full homepage editing, please install the <em>Imam Hussain Elementor Widgets</em> plugin included in the zip.';
        echo '</p></div>';
    }
}
add_action('admin_notices', 'ih_elementor_notice');
