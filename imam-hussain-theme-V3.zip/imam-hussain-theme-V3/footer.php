</main><!-- #main -->

<?php
$tagline = get_theme_mod('ih_footer_tagline', 'Illuminating the path of justice through the legacy of Imam Hussain (A.S.)');
$email   = get_theme_mod('ih_footer_email', 'info@imam-hussain.info');
?>
<footer class="ih-footer" role="contentinfo">
    <div class="ih-footer-arc" aria-hidden="true"></div>

    <div class="ih-footer-inner">
        <div class="ih-footer-grid">

            <!-- Logo -->
            <div>
                <a href="<?php echo esc_url(home_url('/')); ?>" class="ih-footer-logo" aria-label="<?php bloginfo('name'); ?> Home">
                    <img src="<?php echo esc_url(IH_THEME_URI . '/assets/images/logo-white.png'); ?>" alt="<?php bloginfo('name'); ?>">
                </a>
                <?php if ($tagline): ?>
                <p style="font:300 14px/1.6 var(--mano,'Manrope',sans-serif);color:rgba(255,255,255,.5);margin:16px 0 0;max-width:200px">
                    <?php echo esc_html($tagline); ?>
                </p>
                <?php endif; ?>
            </div>

            <!-- 3 nav columns -->
            <div class="ih-footer-cols">
                <?php
                $cols = [
                    ['CHAPTER 01', 'Imam Hussain (A.S.)', 'imam-hussain',
                        ['Biography', 'Family & Lineage', 'Companions', 'Teachings & Letters', 'Life & Legacy']],
                    ['CHAPTER 02–03', 'Karbala & Muharram', 'karbala',
                        ['Battle of Karbala', 'Events of Karbala', 'Martyrs of Karbala', 'Ashura', 'Arbaeen']],
                    ['CHAPTER 05', 'Teachings & Lessons', 'lessons',
                        ['Moral Lessons', 'Quotes', 'Justice & Freedom', 'Patience & Faith', 'Humanity & Peace']],
                ];
                foreach ($cols as [$chapter, $title, $slug, $links]):
                    $cat_url = get_term_link($slug, 'category');
                    if (is_wp_error($cat_url)) $cat_url = get_post_type_archive_link('ih_article') ?: home_url('/');
                ?>
                <div class="ih-footer-col">
                    <p class="ih-footer-col-chapter"><?php echo esc_html($chapter); ?></p>
                    <h4 class="ih-footer-col-title"><?php echo esc_html($title); ?></h4>
                    <ul>
                        <?php foreach ($links as $link): ?>
                        <li><a href="<?php echo esc_url($cat_url); ?>"><?php echo esc_html($link); ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endforeach; ?>
            </div>

        </div><!-- .ih-footer-grid -->

        <hr class="ih-footer-divider">

        <div class="ih-footer-bottom">
            <!-- Email -->
            <div class="ih-footer-email">
                <div class="ih-footer-email-icon">
                    <svg width="20" height="14" fill="none" viewBox="0 0 20 14">
                        <path d="M1 1l9 6 9-6M1 1h18v12H1z" stroke="white" stroke-width="1.5" stroke-linejoin="round"/>
                    </svg>
                </div>
                <span><?php echo esc_html($email); ?></span>
            </div>

            <!-- Social icons -->
            <div class="ih-footer-social">
                <a href="#" aria-label="Facebook">
                    <svg width="10" height="20" fill="white" viewBox="0 0 10 20"><path d="M6.5 11.5H9l.5-3H6.5V7c0-.8.4-1.5 1.6-1.5H9.5V2.8S8.3 2.5 7.2 2.5C4.7 2.5 3 4 3 6.7v1.8H.5v3H3V20h3.5V11.5z"/></svg>
                </a>
                <a href="#" aria-label="Instagram">
                    <svg width="18" height="18" fill="none" viewBox="0 0 18 18"><rect x="2" y="2" width="14" height="14" rx="4" stroke="white" stroke-width="1.5"/><circle cx="9" cy="9" r="3" stroke="white" stroke-width="1.5"/><circle cx="13" cy="5" r="1" fill="white"/></svg>
                </a>
                <a href="#" aria-label="X (Twitter)">
                    <svg width="16" height="16" fill="white" viewBox="0 0 16 16"><path d="M9.27 7.06L14.64 1H13.3L8.67 6.24 5.01 1H1l5.64 7.9L1 15h1.34l4.93-5.57L11 15h4.01L9.27 7.06zM7.96 8.66l-.57-.79L2.76 1.96h1.96l3.68 5.14.57.79 4.78 6.67h-1.96L7.96 8.66z"/></svg>
                </a>
            </div>

            <!-- Copyright -->
            <p class="ih-footer-copy">Copyright &copy; <?php echo date('Y'); ?> &mdash; <?php bloginfo('name'); ?> &middot; All rights reserved.</p>
        </div>

    </div><!-- .ih-footer-inner -->
</footer>

<?php wp_footer(); ?>
</body>
</html>
