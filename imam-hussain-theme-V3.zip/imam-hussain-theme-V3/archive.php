<?php get_header(); ?>

<div class="ih-archive-hero">
    <div class="ih-wrap">
        <?php
        $term = get_queried_object();
        $chapter_map = [
            'imam-hussain' => '01',
            'muharram'     => '02',
            'karbala'      => '03',
            'companions'   => '04',
            'arbaeen'      => '05',
            'ziarat'       => '06',
            'lessons'      => '07',
            'resources'    => '08',
        ];
        $slug    = $term->slug ?? '';
        $chapter = $chapter_map[$slug] ?? '—';
        ?>
        <p class="cat-chapter"><?php echo esc_html($chapter); ?></p>
        <h1><?php single_cat_title(); ?></h1>
        <?php if (term_description()): ?>
        <p><?php echo term_description(); ?></p>
        <?php endif; ?>
    </div>
</div>

<div class="ih-articles" style="background:#faf9f5;padding:64px 0">
    <div class="ih-articles-inner">
        <div class="ih-archive-grid">
            <?php while (have_posts()): the_post();
                $thumb = has_post_thumbnail() ? get_the_post_thumbnail_url(null, 'ih-card') : '';
                $cats  = get_the_terms(get_the_ID(), 'category');
                $cat   = ($cats && !is_wp_error($cats)) ? $cats[0] : null;
            ?>
            <article class="ih-article-card">
                <a href="<?php the_permalink(); ?>">
                    <?php if ($thumb): ?>
                    <div class="ih-article-card-img">
                        <img src="<?php echo esc_url($thumb); ?>" alt="<?php the_title_attribute(); ?>">
                    </div>
                    <?php endif; ?>
                    <?php if ($cat): ?>
                    <p class="cat-label"><?php echo esc_html($cat->name); ?></p>
                    <?php endif; ?>
                    <h3><?php the_title(); ?></h3>
                    <p class="excerpt"><?php echo wp_trim_words(get_the_excerpt(), 18); ?></p>
                    <div class="meta">
                        <svg width="12" height="12" fill="none" viewBox="0 0 14 14"><circle cx="7" cy="7" r="6" stroke="currentColor" stroke-width="1.5"/><path d="M7 4v3l2 2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
                        <?php echo get_post_meta(get_the_ID(), '_read_time', true) ?: '5 min read'; ?>
                        &middot; <?php the_date(); ?>
                    </div>
                </a>
            </article>
            <?php endwhile; ?>
        </div>
        <div style="margin-top:48px"><?php the_posts_pagination(); ?></div>
    </div>
</div>

<?php get_footer();
