<?php
/**
 * Custom nav walker that adds chapter numbers above nav labels.
 * Assign menu items custom CSS classes like "chapter-01" to "chapter-08".
 */
class IH_Nav_Walker extends Walker_Nav_Menu {

    private static $chapter_map = [
        'imam-hussain' => '01',
        'muharram'     => '02',
        'karbala'      => '03',
        'companions'   => '04',
        'arbaeen'      => '05',
        'ziarat'       => '06',
        'lessons'      => '07',
        'resources'    => '08',
    ];

    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $classes  = empty($item->classes) ? [] : (array) $item->classes;
        $title    = apply_filters('the_title', $item->title, $item->ID);
        $url      = $item->url ?: '#';
        $is_active = in_array('current-menu-item', $classes) || in_array('current-menu-ancestor', $classes);

        // Detect chapter from slug or classes
        $slug    = sanitize_title($title);
        $chapter = '';
        foreach (self::$chapter_map as $key => $ch) {
            if (strpos(implode(' ', $classes), $key) !== false || $key === $slug) {
                $chapter = $ch;
                break;
            }
        }
        // Fallback: check custom field on item
        if (!$chapter && !empty($item->chapter)) {
            $chapter = $item->chapter;
        }

        $active_class = $is_active ? ' ih-nav-active' : '';

        $output .= '<li class="ih-nav-item' . $active_class . '">';
        $output .= '<a href="' . esc_url($url) . '" class="ih-nav-link">';
        if ($chapter) {
            $output .= '<span class="ih-nav-chapter">' . esc_html($chapter) . '</span>';
        }
        $output .= '<span class="ih-nav-label">' . esc_html($title) . '</span>';
        $output .= '</a>';
    }

    public function end_el(&$output, $item, $depth = 0, $args = null) {
        $output .= '</li>';
    }
}
