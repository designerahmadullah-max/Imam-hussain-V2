<?php
function ih_customizer_register($wp_customize) {
    /* ── Hero Section ── */
    $wp_customize->add_section('ih_hero', [
        'title'    => __('Hero Section', 'imam-hussain'),
        'priority' => 30,
    ]);
    $fields = [
        ['hero_heading',     'text',  'Hero Heading',          'The Light of Karbala'],
        ['hero_subtext',     'textarea', 'Hero Subtext',       'Explore the teachings, sacrifice, and eternal legacy of Imam Hussain ibn Ali (A.S.)'],
        ['hero_btn1_text',   'text',  'Button 1 Text',         'Explore Karbala'],
        ['hero_btn1_url',    'url',   'Button 1 URL',          '#'],
        ['hero_btn2_text',   'text',  'Button 2 Text',         'Read Teachings'],
        ['hero_btn2_url',    'url',   'Button 2 URL',          '#'],
    ];
    foreach ($fields as [$id, $type, $label, $default]) {
        $wp_customize->add_setting("ih_$id", ['default' => $default, 'sanitize_callback' => 'sanitize_text_field', 'transport' => 'refresh']);
        $wp_customize->add_control("ih_$id", ['label' => $label, 'section' => 'ih_hero', 'type' => $type]);
    }
    $wp_customize->add_setting('ih_hero_image', ['default' => '', 'sanitize_callback' => 'esc_url_raw']);
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'ih_hero_image', [
        'label' => __('Hero Background Image', 'imam-hussain'), 'section' => 'ih_hero',
    ]));

    /* ── Site Footer ── */
    $wp_customize->add_section('ih_footer', [
        'title'    => __('Footer', 'imam-hussain'),
        'priority' => 200,
    ]);
    $wp_customize->add_setting('ih_footer_email', ['default' => 'info@imam-hussain.info', 'sanitize_callback' => 'sanitize_email']);
    $wp_customize->add_control('ih_footer_email', ['label' => __('Footer Email', 'imam-hussain'), 'section' => 'ih_footer', 'type' => 'email']);
    $wp_customize->add_setting('ih_footer_tagline', ['default' => 'Illuminating the path of justice through the legacy of Imam Hussain (A.S.)', 'sanitize_callback' => 'sanitize_text_field']);
    $wp_customize->add_control('ih_footer_tagline', ['label' => __('Footer Tagline', 'imam-hussain'), 'section' => 'ih_footer', 'type' => 'textarea']);
}
add_action('customize_register', 'ih_customizer_register');
