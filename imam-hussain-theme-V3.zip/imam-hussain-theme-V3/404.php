<?php get_header(); ?>
<div class="ih-wrap" style="padding:120px 0;text-align:center">
    <p style="font:600 11px/1 'Inter',sans-serif;letter-spacing:2px;text-transform:uppercase;color:#c81e1e;margin-bottom:16px">404</p>
    <h1 style="font:400 54px/1.1 'DM Serif Display',serif;color:#212121;margin:0 0 16px;letter-spacing:-1.5px">Page Not Found</h1>
    <p style="font:400 17px/1.6 'Inter',sans-serif;color:#707070;margin:0 0 36px">The page you are looking for does not exist.</p>
    <a href="<?php echo esc_url(home_url('/')); ?>" class="ih-btn-primary" style="display:inline-flex">Return Home</a>
</div>
<?php get_footer();
