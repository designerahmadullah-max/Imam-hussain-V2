<?php
/**
 * Front page / blog index.
 * If using Elementor to build the homepage, WordPress will use page.php for static pages.
 * This file handles the default blog loop.
 */
get_header(); ?>

<div class="ih-wrap" style="padding-top:56px;padding-bottom:80px">
    <div class="ih-section-header" style="margin-bottom:40px">
        <div>
            <p class="ih-section-eyebrow">LATEST ARTICLES</p>
            <h1 class="ih-section-title">All Articles</h1>
        </div>
    </div>

    <?php if (have_posts()): ?>
    <div class="ih-articles-grid">
        <?php while (have_posts()): the_post();
            $thumb = has_post_thumbnail() ? get_the_post_thumbnail_url(null, 'ih-card') : '';
            $cats  = get_the_terms(get_the_ID(), 'category');
            $cat   = ($cats && !is_wp_error($cats)) ? $cats[0] : null;
        ?>
        <article class="ih-article-card">
            <a href="<?php the_permalink(); ?>">
                <?php if ($thumb): ?>
                <div class="ih-article-card-img">
                    <img src="<?php echo esc_url($thumb); ?>" alt="<?php the_title_attribute(); ?>">
                </div>
                <?php endif; ?>
                <?php if ($cat): ?>
                <p class="cat-label"><?php echo esc_html($cat->name); ?></p>
                <?php endif; ?>
                <h3><?php the_title(); ?></h3>
                <p class="excerpt"><?php echo wp_trim_words(get_the_excerpt(), 18); ?></p>
                <div class="meta">
                    <svg width="12" height="12" fill="none" viewBox="0 0 14 14">
                        <circle cx="7" cy="7" r="6" stroke="currentColor" stroke-width="1.5"/>
                        <path d="M7 4v3l2 2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    </svg>
                    <?php echo get_post_meta(get_the_ID(), '_read_time', true) ?: '5 min read'; ?>
                    &middot; <?php echo get_the_date(); ?>
                </div>
            </a>
        </article>
        <?php endwhile; ?>
    </div>

    <div style="margin-top:48px">
        <?php the_posts_pagination(['mid_size' => 2]); ?>
    </div>

    <?php else: ?>
    <p style="color:#707070;font-family:'Inter',sans-serif">No articles found. Add content in WordPress admin.</p>
    <?php endif; ?>
</div>

<?php get_footer();
