<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Search Overlay -->
<div class="ih-search-overlay" role="dialog" aria-label="Search" aria-modal="true">
    <div class="ih-search-top">
        <a href="<?php echo esc_url(home_url('/')); ?>">
            <img src="<?php echo esc_url(IH_THEME_URI . '/assets/images/logo.png'); ?>" alt="<?php bloginfo('name'); ?>">
        </a>
        <button class="ih-search-cancel" aria-label="Close search">
            <span>Cancel</span>
            <svg width="20" height="20" fill="none" viewBox="0 0 20 20">
                <path d="M15 5L5 15M5 5l10 10" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
            </svg>
        </button>
    </div>
    <div class="ih-search-body">
        <div class="ih-search-input-row">
            <svg width="28" height="28" fill="none" viewBox="0 0 28 28" style="color:#707070;flex-shrink:0">
                <path d="M24.5 24.5l-5.833-5.833M21.583 12.833a8.75 8.75 0 1 1-17.5 0 8.75 8.75 0 0 1 17.5 0Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <input type="search" class="ih-search-query" placeholder="Search articles, topics…" autocomplete="off">
        </div>
        <div id="ih-search-results" class="ih-search-results"></div>
    </div>
</div>

<!-- ── Site Header ── -->
<header class="ih-header" role="banner">

    <!-- Desktop: split nav with centered logo -->
    <div class="ih-header-inner">

        <!-- Left nav: Imam Hussain · Muharram · Karbala · Companions -->
        <div class="ih-nav-half ih-nav-half--left">
            <div class="ih-nav-bar"></div>
            <nav class="ih-nav-list" aria-label="Left navigation">
                <?php
                $left_items = [
                    ['01', 'Imam Hussain', get_term_link('imam-hussain', 'category') ?: '#'],
                    ['02', 'Muharram',     get_term_link('muharram', 'category') ?: '#'],
                    ['03', 'Karbala',      get_term_link('karbala', 'category') ?: '#'],
                    ['04', 'Companions',   get_term_link('companions', 'category') ?: '#'],
                ];
                foreach ($left_items as [$ch, $label, $url]):
                    $current = is_category($label) ? ' ih-nav-active' : '';
                ?>
                <div class="ih-nav-item<?php echo $current; ?>">
                    <a href="<?php echo esc_url($url); ?>" class="ih-nav-link">
                        <span class="ih-nav-chapter"><?php echo esc_html($ch); ?></span>
                        <span class="ih-nav-label"><?php echo esc_html($label); ?></span>
                    </a>
                </div>
                <?php endforeach; ?>
            </nav>
        </div>

        <!-- Center logo -->
        <div class="ih-header-logo">
            <a href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php bloginfo('name'); ?> Home">
                <img src="<?php echo esc_url(IH_THEME_URI . '/assets/images/logo.png'); ?>" alt="<?php bloginfo('name'); ?>">
            </a>
        </div>

        <!-- Right nav: Arbaeen · Ziarat · Lessons · Resources + Search -->
        <div class="ih-nav-half ih-nav-half--right">
            <div class="ih-nav-bar"></div>
            <nav class="ih-nav-list" aria-label="Right navigation">
                <?php
                $right_items = [
                    ['05', 'Arbaeen',   get_term_link('arbaeen', 'category') ?: '#'],
                    ['06', 'Ziarat',    get_term_link('ziarat', 'category') ?: '#'],
                    ['07', 'Lessons',   get_term_link('lessons', 'category') ?: '#'],
                    ['08', 'Resources', get_term_link('resources', 'category') ?: '#'],
                ];
                foreach ($right_items as [$ch, $label, $url]):
                    $current = is_category($label) ? ' ih-nav-active' : '';
                ?>
                <div class="ih-nav-item<?php echo $current; ?>">
                    <a href="<?php echo esc_url($url); ?>" class="ih-nav-link">
                        <span class="ih-nav-chapter"><?php echo esc_html($ch); ?></span>
                        <span class="ih-nav-label"><?php echo esc_html($label); ?></span>
                    </a>
                </div>
                <?php endforeach; ?>
                <button class="ih-search-btn" aria-label="Open search">
                    <svg width="20" height="20" fill="none" viewBox="0 0 20 20">
                        <path d="M17.5 17.5l-4.167-4.167M15.833 9.167A6.667 6.667 0 1 1 2.5 9.167a6.667 6.667 0 0 1 13.333 0Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </button>
            </nav>
        </div>

    </div><!-- .ih-header-inner -->

    <!-- Mobile header -->
    <div class="ih-header-mobile">
        <a href="<?php echo esc_url(home_url('/')); ?>">
            <img src="<?php echo esc_url(IH_THEME_URI . '/assets/images/logo.png'); ?>" alt="<?php bloginfo('name'); ?>">
        </a>
        <div class="ih-mobile-actions">
            <button class="ih-mobile-search" aria-label="Search">
                <svg width="20" height="20" fill="none" viewBox="0 0 20 20">
                    <path d="M17.5 17.5l-4.167-4.167M15.833 9.167A6.667 6.667 0 1 1 2.5 9.167a6.667 6.667 0 0 1 13.333 0Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </button>
            <button class="ih-burger" aria-label="Toggle menu" aria-expanded="false">
                <svg width="24" height="24" fill="none" viewBox="0 0 24 24">
                    <path d="M3 12h18M3 6h18M3 18h18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
            </button>
        </div>
    </div>

    <!-- Mobile menu dropdown -->
    <nav class="ih-mobile-nav" aria-label="Mobile navigation">
        <?php
        $all_items = [
            ['01', 'Imam Hussain', get_term_link('imam-hussain', 'category') ?: '#'],
            ['02', 'Muharram',     get_term_link('muharram', 'category') ?: '#'],
            ['03', 'Karbala',      get_term_link('karbala', 'category') ?: '#'],
            ['04', 'Companions',   get_term_link('companions', 'category') ?: '#'],
            ['05', 'Arbaeen',      get_term_link('arbaeen', 'category') ?: '#'],
            ['06', 'Ziarat',       get_term_link('ziarat', 'category') ?: '#'],
            ['07', 'Lessons',      get_term_link('lessons', 'category') ?: '#'],
            ['08', 'Resources',    get_term_link('resources', 'category') ?: '#'],
        ];
        foreach ($all_items as [$ch, $label, $url]):
        ?>
        <a href="<?php echo esc_url($url); ?>" class="ih-mobile-nav-item">
            <span>
                <span class="ih-nav-chapter"><?php echo esc_html($ch); ?></span>
                <span class="ih-nav-label"><?php echo esc_html($label); ?></span>
            </span>
            <svg width="6" height="10" fill="none" viewBox="0 0 7 12">
                <path d="M1 11l5-5L1 1" stroke="#c81e1e" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </a>
        <?php endforeach; ?>
    </nav>

</header><!-- .ih-header -->

<main id="main" class="ih-main">
