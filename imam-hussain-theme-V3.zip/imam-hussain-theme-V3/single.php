<?php get_header(); ?>

<?php while (have_posts()): the_post();
    $cats = get_the_terms(get_the_ID(), 'category');
    $cat  = ($cats && !is_wp_error($cats)) ? $cats[0] : null;
    $read_time = get_post_meta(get_the_ID(), '_read_time', true) ?: '5 min read';
?>

<!-- Breadcrumb -->
<div class="ih-single-header" style="max-width:1400px;margin-inline:auto;padding:32px clamp(24px,4vw,80px) 0">
    <div class="ih-single-breadcrumb">
        <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
        <svg width="6" height="10" fill="none" viewBox="0 0 7 12"><path d="M1 11l5-5L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
        <?php if ($cat): ?>
        <a href="<?php echo esc_url(get_term_link($cat)); ?>"><?php echo esc_html($cat->name); ?></a>
        <svg width="6" height="10" fill="none" viewBox="0 0 7 12"><path d="M1 11l5-5L1 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
        <?php endif; ?>
        <span style="color:#212121"><?php the_title(); ?></span>
    </div>
</div>

<!-- Article header -->
<div class="ih-single-header" style="text-align:center;max-width:800px;margin-inline:auto;padding:40px 24px 40px">
    <?php if ($cat): ?>
    <p class="cat-label"><?php echo esc_html($cat->name); ?></p>
    <?php endif; ?>
    <h1><?php the_title(); ?></h1>
    <?php if (has_excerpt()): ?>
    <p class="excerpt" style="font:300 18px/1.6 'Inter',sans-serif;color:#3a3a3a;margin:16px 0 24px"><?php the_excerpt(); ?></p>
    <?php endif; ?>
    <div style="display:flex;align-items:center;justify-content:center;gap:16px;font:400 14px 'Inter',sans-serif;color:#707070">
        <span style="color:#212121;font-family:'Manrope',sans-serif;font-weight:500"><?php the_author(); ?></span>
        <span>&middot;</span>
        <span><?php the_date(); ?></span>
        <span>&middot;</span>
        <span><?php echo esc_html($read_time); ?></span>
    </div>
</div>

<!-- Hero image -->
<?php if (has_post_thumbnail()): ?>
<div class="ih-single-hero">
    <?php the_post_thumbnail('ih-hero', ['style' => 'width:100%;aspect-ratio:16/8;object-fit:cover;border-radius:16px']); ?>
</div>
<?php endif; ?>

<!-- Article body -->
<div class="ih-single" style="max-width:740px;margin-inline:auto">
    <div class="ih-single-body">
        <?php the_content(); ?>
    </div>

    <?php
    $post_tags = get_the_tags();
    if ($post_tags):
    ?>
    <div class="ih-single-tags">
        <?php foreach ($post_tags as $tag): ?>
        <a href="<?php echo esc_url(get_tag_link($tag)); ?>"><?php echo esc_html($tag->name); ?></a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<!-- Related articles -->
<?php if ($cat):
    $related = new WP_Query([
        'post_type'      => ['post', 'ih_article'],
        'posts_per_page' => 3,
        'post__not_in'   => [get_the_ID()],
        'tax_query'      => [['taxonomy' => 'category', 'field' => 'term_id', 'terms' => $cat->term_id]],
    ]);
    if ($related->have_posts()):
?>
<section class="ih-articles" style="background:#faf9f5;padding:80px 0;margin-top:64px">
    <div class="ih-articles-inner">
        <p class="ih-section-eyebrow">RELATED ARTICLES</p>
        <h2 class="ih-section-title" style="margin-bottom:40px">Continue Reading</h2>
        <div class="ih-articles-grid">
            <?php while ($related->have_posts()): $related->the_post();
                $thumb = has_post_thumbnail() ? get_the_post_thumbnail_url(null, 'ih-card') : '';
            ?>
            <article class="ih-article-card">
                <a href="<?php the_permalink(); ?>">
                    <?php if ($thumb): ?>
                    <div class="ih-article-card-img">
                        <img src="<?php echo esc_url($thumb); ?>" alt="<?php the_title_attribute(); ?>">
                    </div>
                    <?php endif; ?>
                    <h3><?php the_title(); ?></h3>
                    <div class="meta">
                        <svg width="12" height="12" fill="none" viewBox="0 0 14 14"><circle cx="7" cy="7" r="6" stroke="currentColor" stroke-width="1.5"/><path d="M7 4v3l2 2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
                        <?php echo get_post_meta(get_the_ID(), '_read_time', true) ?: '5 min read'; ?>
                    </div>
                </a>
            </article>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
    </div>
</section>
<?php endif; endif; ?>

<?php endwhile; ?>

<?php get_footer();
