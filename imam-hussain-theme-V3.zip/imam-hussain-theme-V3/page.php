<?php
/**
 * Template for static pages — including Elementor-built homepage.
 * Elementor replaces the_content() with its own canvas when page is built with Elementor.
 */
get_header(); ?>

<?php while (have_posts()): the_post(); ?>
    <?php the_content(); ?>
<?php endwhile; ?>

<?php get_footer();
