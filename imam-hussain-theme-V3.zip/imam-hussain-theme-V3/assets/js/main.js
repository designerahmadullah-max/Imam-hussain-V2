(function($) {
    'use strict';

    /* ── Mobile menu ── */
    var $burger = $('.ih-burger');
    var $mobileNav = $('.ih-mobile-nav');
    $burger.on('click', function() {
        $mobileNav.toggleClass('is-open');
        var open = $mobileNav.hasClass('is-open');
        $burger.attr('aria-expanded', open);
    });

    /* ── Search overlay ── */
    var $overlay = $('.ih-search-overlay');
    var $searchInput = $overlay.find('.ih-search-query');
    var searchTimer;

    function openSearch() {
        $overlay.addClass('is-open');
        setTimeout(function() { $searchInput.focus(); }, 80);
    }
    function closeSearch() {
        $overlay.removeClass('is-open');
        $searchInput.val('').trigger('input');
    }

    $(document).on('click', '.ih-search-btn, .ih-mobile-search', openSearch);
    $(document).on('click', '.ih-search-cancel', closeSearch);

    $(document).on('keydown', function(e) {
        if (e.key === 'Escape') closeSearch();
    });

    /* ── Live search ── */
    $searchInput.on('input', function() {
        clearTimeout(searchTimer);
        var q = $(this).val().trim();
        if (q.length < 2) {
            $('#ih-search-results').html('');
            return;
        }
        searchTimer = setTimeout(function() {
            $.post(ihAjax.url, {
                action: 'ih_search', nonce: ihAjax.nonce, query: q
            }, function(res) {
                if (!res.success || !res.data.length) {
                    $('#ih-search-results').html('<p class="ih-no-results">No results found</p>');
                    return;
                }
                var html = res.data.map(function(r) {
                    return '<a href="' + r.url + '" class="ih-result-item">' +
                        '<span class="cat-label">' + (r.category || '') + '</span>' +
                        '<span class="title">' + r.title + '</span>' +
                        '<span class="excerpt">' + r.excerpt + '</span>' +
                        '</a>';
                }).join('');
                $('#ih-search-results').html(html);
            });
        }, 260);
    });

    /* ── Sticky header shadow on scroll ── */
    $(window).on('scroll', function() {
        $('.ih-header').toggleClass('scrolled', $(this).scrollTop() > 20);
    });

})(jQuery);
