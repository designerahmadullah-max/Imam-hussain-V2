/* Imam Hussain Elementor Widgets — Frontend JS */
(function() {
    'use strict';

    /* Animate topics bar on scroll */
    function initTopics() {
        var lists = document.querySelectorAll('.ih-topics-list');
        lists.forEach(function(list) {
            list.addEventListener('wheel', function(e) {
                if (window.innerWidth < 768) {
                    e.preventDefault();
                    list.scrollLeft += e.deltaY;
                }
            }, { passive: false });
        });
    }

    /* Lazy-load hero BG after Elementor renders */
    function initHeroBg() {
        var heroes = document.querySelectorAll('.ih-hero[style*="background-image"]');
        heroes.forEach(function(el) {
            el.style.backgroundSize = 'cover';
            el.style.backgroundPosition = 'center';
        });
    }

    document.addEventListener('DOMContentLoaded', function() {
        initTopics();
        initHeroBg();
    });

    /* Elementor frontend hook */
    if (typeof window.elementorFrontend !== 'undefined') {
        window.elementorFrontend.hooks.addAction('frontend/element_ready/ih_hero/default', initHeroBg);
        window.elementorFrontend.hooks.addAction('frontend/element_ready/ih_topics/default', initTopics);
    }
})();
