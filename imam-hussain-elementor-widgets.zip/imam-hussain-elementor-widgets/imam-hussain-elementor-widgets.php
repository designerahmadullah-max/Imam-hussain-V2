<?php
/**
 * Plugin Name:  Imam Hussain Elementor Widgets
 * Plugin URI:   https://github.com/designerahmadullah-max/Imam-hussain-V2
 * Description:  Adds custom Elementor widgets for each homepage section of the Imam Hussain Knowledge Portal.
 * Version:      3.0.0
 * Author:       Imam Hussain Portal
 * Text Domain:  ih-widgets
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Elementor tested up to: 3.22
 */

if (!defined('ABSPATH')) exit;

define('IH_WIDGETS_VERSION', '3.0.0');
define('IH_WIDGETS_URI', plugin_dir_url(__FILE__));
define('IH_WIDGETS_DIR', plugin_dir_path(__FILE__));

/* ── Check Elementor is active ── */
function ih_widgets_check_elementor() {
    if (!did_action('elementor/loaded')) {
        add_action('admin_notices', function() {
            echo '<div class="notice notice-error"><p><strong>Imam Hussain Elementor Widgets</strong> requires the <strong>Elementor</strong> plugin to be installed and active.</p></div>';
        });
        return false;
    }
    return true;
}

/* ── Register Widgets ── */
function ih_register_elementor_widgets() {
    if (!ih_widgets_check_elementor()) return;

    $widgets = [
        'hero'             => 'IH_Hero_Widget',
        'topics'           => 'IH_Topics_Widget',
        'featured-articles'=> 'IH_Featured_Articles_Widget',
        'philosophy'       => 'IH_Philosophy_Widget',
        'new-articles'     => 'IH_New_Articles_Widget',
        'karbala'          => 'IH_Karbala_Widget',
        'most-popular'     => 'IH_Most_Popular_Widget',
    ];

    foreach ($widgets as $file => $class) {
        require_once IH_WIDGETS_DIR . 'widgets/class-' . $file . '-widget.php';
        \Elementor\Plugin::instance()->widgets_manager->register(new $class());
    }
}
add_action('elementor/widgets/register', 'ih_register_elementor_widgets');

/* ── Enqueue widget CSS ── */
function ih_widgets_enqueue() {
    wp_enqueue_style('ih-widgets',
        IH_WIDGETS_URI . 'assets/css/ih-widgets.css',
        [], IH_WIDGETS_VERSION);
    wp_enqueue_script('ih-widgets',
        IH_WIDGETS_URI . 'assets/js/ih-widgets.js',
        ['jquery'], IH_WIDGETS_VERSION, true);
}
add_action('wp_enqueue_scripts', 'ih_widgets_enqueue');

/* ── Register widget category ── */
function ih_elementor_category($manager) {
    $manager->add_category('imam-hussain', [
        'title' => __('Imam Hussain Portal', 'ih-widgets'),
        'icon'  => 'fa fa-star',
    ]);
}
add_action('elementor/elements/categories_registered', 'ih_elementor_category');
