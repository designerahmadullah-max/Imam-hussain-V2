<?php
if (!defined('ABSPATH')) exit;

class IH_Most_Popular_Widget extends \Elementor\Widget_Base {

    public function get_name()  { return 'ih_most_popular'; }
    public function get_title() { return __('IH — Most Popular Section', 'ih-widgets'); }
    public function get_icon()  { return 'eicon-featured-image'; }
    public function get_categories() { return ['imam-hussain']; }

    protected function register_controls() {
        $this->start_controls_section('sec_title', ['label' => __('Section', 'ih-widgets')]);
        $this->add_control('section_title', [
            'label'   => __('Section Title', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'Most Popular',
        ]);
        $this->end_controls_section();

        /* 3 link columns */
        for ($i = 1; $i <= 3; $i++) {
            $this->start_controls_section("sec_col$i", ['label' => "Column $i"]);
            $this->add_control("col{$i}_heading", [
                'label'   => __('Column Heading', 'ih-widgets'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => ["Life & Legacy", "Karbala & Ziarat", "Lessons & Wisdom"][$i-1],
            ]);
            $this->add_control("col{$i}_url", [
                'label'   => __('Column Heading URL', 'ih-widgets'),
                'type'    => \Elementor\Controls_Manager::URL,
                'default' => ['url' => '#'],
            ]);
            $rep = new \Elementor\Repeater();
            $rep->add_control('text', ['label' => __('Link Text', 'ih-widgets'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Article link']);
            $rep->add_control('url',  ['label' => __('URL', 'ih-widgets'),       'type' => \Elementor\Controls_Manager::URL,  'default' => ['url' => '#']]);
            $defaults = [
                1 => ['Life of Imam Hussain','Teachings & Wisdom','Duas & Supplications','Family of the Prophet','Companions of Karbala'],
                2 => ['The Battle of Karbala','Arbaeen Walk','Ziarat & Pilgrimage','Muharram','Day of Ashura'],
                3 => ['Moral Lessons','Quotes','Justice & Freedom','Patience & Faith','Humanity & Peace'],
            ];
            $this->add_control("col{$i}_links", [
                'label'       => __('Links', 'ih-widgets'),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $rep->get_controls(),
                'default'     => array_map(fn($t) => ['text' => $t, 'url' => ['url' => '#']], $defaults[$i]),
                'title_field' => '{{{ text }}}',
            ]);
            $this->end_controls_section();
        }

        /* Banner cards (4th column) */
        $this->start_controls_section('sec_banners', ['label' => __('Banner Cards (4th Column)', 'ih-widgets')]);
        $rep2 = new \Elementor\Repeater();
        $rep2->add_control('icon',    ['label' => __('Icon Image', 'ih-widgets'),   'type' => \Elementor\Controls_Manager::MEDIA]);
        $rep2->add_control('heading', ['label' => __('Banner Heading', 'ih-widgets'),'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Imam Ali (A.S.)']);
        $rep2->add_control('subtext', ['label' => __('Banner Subtext', 'ih-widgets'),'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Gateway of Knowledge']);
        $rep2->add_control('url',     ['label' => __('URL', 'ih-widgets'),           'type' => \Elementor\Controls_Manager::URL, 'default' => ['url' => '#']]);
        $this->add_control('banners', [
            'label'       => __('Banner Cards (max 2)', 'ih-widgets'),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'fields'      => $rep2->get_controls(),
            'default'     => [
                ['heading' => 'Imam Ali (A.S.)',   'subtext' => 'Gateway of Knowledge'],
                ['heading' => 'Imam Mahdi (A.J.)', 'subtext' => 'The Expected Saviour'],
            ],
            'title_field' => '{{{ heading }}}',
        ]);
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        ?>
        <section class="ih-popular">
            <div class="ih-popular-inner">
                <h2 class="ih-popular-title"><?php echo esc_html($s['section_title']); ?></h2>
                <div class="ih-popular-grid">

                    <?php for ($i = 1; $i <= 3; $i++):
                        $h_url = !empty($s["col{$i}_url"]['url']) ? esc_url($s["col{$i}_url"]['url']) : '#';
                    ?>
                    <div class="ih-popular-col">
                        <h3><a href="<?php echo $h_url; ?>" style="color:inherit;text-decoration:none"><?php echo esc_html($s["col{$i}_heading"]); ?></a></h3>
                        <ul>
                            <?php foreach ((array)$s["col{$i}_links"] as $link):
                                $url = !empty($link['url']['url']) ? esc_url($link['url']['url']) : '#';
                            ?>
                            <li><a href="<?php echo $url; ?>"><?php echo esc_html($link['text']); ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endfor; ?>

                    <!-- 4th column: banner cards -->
                    <div class="ih-popular-col">
                        <h3 style="visibility:hidden">Explore</h3>
                        <?php foreach (array_slice((array)$s['banners'], 0, 2) as $b):
                            $b_url  = !empty($b['url']['url']) ? esc_url($b['url']['url']) : '#';
                            $b_icon = !empty($b['icon']['url']) ? esc_url($b['icon']['url']) : '';
                        ?>
                        <a href="<?php echo $b_url; ?>" class="ih-popular-banner">
                            <div class="ih-popular-banner-icon">
                                <?php if ($b_icon): ?>
                                <img src="<?php echo $b_icon; ?>" alt="<?php echo esc_attr($b['heading']); ?>">
                                <?php else: ?>
                                <svg width="28" height="28" fill="white" viewBox="0 0 28 28"><circle cx="14" cy="14" r="12" stroke="white" stroke-width="1.5" fill="none"/><path d="M14 9v5l3 3" stroke="white" stroke-width="1.5" stroke-linecap="round"/></svg>
                                <?php endif; ?>
                            </div>
                            <div class="ih-popular-banner-text">
                                <h4><?php echo esc_html($b['heading']); ?></h4>
                                <p><?php echo esc_html($b['subtext']); ?></p>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>

                </div>
            </div>
        </section>
        <?php
    }
}
