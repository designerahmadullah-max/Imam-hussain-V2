<?php
if (!defined('ABSPATH')) exit;

class IH_Featured_Articles_Widget extends \Elementor\Widget_Base {

    public function get_name()  { return 'ih_featured_articles'; }
    public function get_title() { return __('IH — Featured Articles', 'ih-widgets'); }
    public function get_icon()  { return 'eicon-post-list'; }
    public function get_categories() { return ['imam-hussain']; }

    protected function register_controls() {
        /* Section label */
        $this->start_controls_section('sec_label', ['label' => __('Section Header', 'ih-widgets')]);
        $this->add_control('section_label', [
            'label'   => __('Section Label', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'FEATURED ARTICLES',
        ]);
        $this->end_controls_section();

        /* Main (left) featured article */
        $this->start_controls_section('sec_main', ['label' => __('Main Featured Article (Left Large Card)', 'ih-widgets')]);

        $this->add_control('main_image', [
            'label'   => __('Article Image', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => ['url' => ''],
            'description' => __('Upload a high-quality image. Displayed at 500px height.', 'ih-widgets'),
        ]);
        $this->add_control('main_category', [
            'label'   => __('Category Label', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'IMAM HUSSAIN',
        ]);
        $this->add_control('main_title', [
            'label'   => __('Article Title', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXTAREA,
            'default' => 'The Life and Legacy of Imam Hussain ibn Ali',
            'rows'    => 3,
        ]);
        $this->add_control('main_excerpt', [
            'label'   => __('Excerpt', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXTAREA,
            'default' => 'Imam Hussain ibn Ali, the grandson of Prophet Muhammad, stands as one of the most revered figures in Islamic history.',
            'rows'    => 3,
        ]);
        $this->add_control('main_author', [
            'label'   => __('Author Name', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'Editorial Team',
        ]);
        $this->add_control('main_date', [
            'label'   => __('Date', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'January 2025',
        ]);
        $this->add_control('main_read_time', [
            'label'   => __('Read Time', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => '12 min read',
        ]);
        $this->add_control('main_url', [
            'label'   => __('Article URL', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::URL,
            'default' => ['url' => '#'],
        ]);

        $this->end_controls_section();

        /* Side articles */
        $this->start_controls_section('sec_side', ['label' => __('Side Articles (Right Column — 3 thumbs)', 'ih-widgets')]);
        $this->add_side_articles_repeater();
        $this->end_controls_section();
    }

    protected function add_side_articles_repeater() {
        $repeater = new \Elementor\Repeater();

        $repeater->add_control('image', [
            'label' => __('Thumbnail Image', 'ih-widgets'),
            'type'  => \Elementor\Controls_Manager::MEDIA,
        ]);
        $repeater->add_control('category', [
            'label'   => __('Category', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'KARBALA',
        ]);
        $repeater->add_control('title', [
            'label'   => __('Title', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'Article Title Here',
        ]);
        $repeater->add_control('read_time', [
            'label'   => __('Read Time', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => '6 min read',
        ]);
        $repeater->add_control('url', [
            'label'   => __('Article URL', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::URL,
            'default' => ['url' => '#'],
        ]);

        $this->add_control('side_articles', [
            'label'       => __('Side Articles (add up to 3)', 'ih-widgets'),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'fields'      => $repeater->get_controls(),
            'default'     => [
                ['category' => 'MUHARRAM',  'title' => 'The Significance of Muharram in Islamic Calendar',  'read_time' => '8 min read'],
                ['category' => 'KARBALA',   'title' => 'Understanding the Battle of Karbala',               'read_time' => '10 min read'],
                ['category' => 'COMPANIONS','title' => 'The Loyal Companions of Imam Hussain',              'read_time' => '7 min read'],
            ],
            'title_field' => '{{{ title }}}',
        ]);
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        $main_url = !empty($s['main_url']['url']) ? esc_url($s['main_url']['url']) : '#';
        $main_img = !empty($s['main_image']['url']) ? esc_url($s['main_image']['url']) : '';
        ?>
        <section class="ih-featured">
            <div class="ih-featured-inner" style="max-width:1400px;margin-inline:auto;padding-inline:clamp(24px,4vw,80px)">
                <?php if (!empty($s['section_label'])): ?>
                <p class="ih-featured-section-label"><?php echo esc_html($s['section_label']); ?></p>
                <?php endif; ?>

                <!-- Main left card -->
                <a href="<?php echo $main_url; ?>" class="ih-featured-main" style="<?php echo $main_img ? 'background:none' : ''; ?>">
                    <?php if ($main_img): ?>
                    <img src="<?php echo $main_img; ?>" alt="<?php echo esc_attr($s['main_title']); ?>">
                    <?php else: ?>
                    <div style="width:100%;height:100%;background:linear-gradient(135deg,#c81e1e,#7a1212)"></div>
                    <?php endif; ?>
                    <div class="ih-featured-main-overlay"></div>
                    <div class="ih-featured-main-content">
                        <?php if (!empty($s['main_category'])): ?>
                        <p class="cat-label"><?php echo esc_html($s['main_category']); ?></p>
                        <?php endif; ?>
                        <h2><?php echo esc_html($s['main_title']); ?></h2>
                        <?php if (!empty($s['main_excerpt'])): ?>
                        <p class="excerpt"><?php echo esc_html($s['main_excerpt']); ?></p>
                        <?php endif; ?>
                        <div class="ih-featured-main-meta">
                            <?php if (!empty($s['main_author'])): ?>
                            <span style="color:#fff;font-family:'Manrope',sans-serif"><?php echo esc_html($s['main_author']); ?></span>
                            <span>&middot;</span>
                            <?php endif; ?>
                            <?php echo esc_html($s['main_date']); ?>
                            <span>&middot;</span>
                            <?php echo esc_html($s['main_read_time']); ?>
                        </div>
                    </div>
                </a>

                <!-- Right side articles -->
                <div class="ih-featured-side">
                    <?php foreach (array_slice((array)$s['side_articles'], 0, 3) as $item):
                        $url   = !empty($item['url']['url']) ? esc_url($item['url']['url']) : '#';
                        $thumb = !empty($item['image']['url']) ? esc_url($item['image']['url']) : '';
                    ?>
                    <a href="<?php echo $url; ?>" class="ih-featured-side-item">
                        <div class="ih-featured-side-thumb">
                            <?php if ($thumb): ?>
                            <img src="<?php echo $thumb; ?>" alt="<?php echo esc_attr($item['title']); ?>">
                            <?php else: ?>
                            <div style="width:100%;height:100%;background:linear-gradient(135deg,#c81e1e,#7a1212);border-radius:8px"></div>
                            <?php endif; ?>
                        </div>
                        <div class="ih-featured-side-text">
                            <p class="cat-label"><?php echo esc_html($item['category']); ?></p>
                            <h3><?php echo esc_html($item['title']); ?></h3>
                            <p class="meta"><?php echo esc_html($item['read_time']); ?></p>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>

            </div>
        </section>
        <?php
    }
}
