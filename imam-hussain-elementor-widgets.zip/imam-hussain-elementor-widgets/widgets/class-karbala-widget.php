<?php
if (!defined('ABSPATH')) exit;

class IH_Karbala_Widget extends \Elementor\Widget_Base {

    public function get_name()  { return 'ih_karbala'; }
    public function get_title() { return __('IH — Karbala & Ziarat Section', 'ih-widgets'); }
    public function get_icon()  { return 'eicon-banner'; }
    public function get_categories() { return ['imam-hussain']; }

    protected function register_controls() {
        $this->start_controls_section('sec', ['label' => __('Karbala & Ziarat Section', 'ih-widgets')]);

        $this->add_control('bg_image', [
            'label'       => __('Main Background Image', 'ih-widgets'),
            'type'        => \Elementor\Controls_Manager::MEDIA,
            'description' => __('Landscape image of Karbala / Imam Hussain shrine.', 'ih-widgets'),
        ]);
        $this->add_control('eyebrow', [
            'label'   => __('Eyebrow', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'KARBALA & ZIARAT',
        ]);
        $this->add_control('heading_plain', [
            'label'   => __('Heading — Plain Part', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'Journey to',
        ]);
        $this->add_control('heading_red', [
            'label'   => __('Heading — Red Part', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'the Sacred Land',
        ]);
        $this->add_control('body_text', [
            'label'   => __('Body Text', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXTAREA,
            'default' => 'The city of Karbala holds one of the holiest shrines in the Islamic world — the resting place of Imam Hussain ibn Ali (A.S.). Every year, pilgrims from across the globe journey here to pay their respects, recite ziarat, and renew their connection to his timeless message.',
            'rows'    => 4,
        ]);
        $this->add_control('btn_text', [
            'label'   => __('Button Text', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'Explore Ziarat',
        ]);
        $this->add_control('btn_url', [
            'label'   => __('Button URL', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::URL,
            'default' => ['url' => '#'],
        ]);

        $this->end_controls_section();

        /* Gallery images below */
        $this->start_controls_section('sec_gallery', ['label' => __('Gallery Images (3 small images at bottom)', 'ih-widgets')]);
        $rep = new \Elementor\Repeater();
        $rep->add_control('image', ['label' => __('Image', 'ih-widgets'), 'type' => \Elementor\Controls_Manager::MEDIA]);
        $rep->add_control('alt',   ['label' => __('Alt Text', 'ih-widgets'), 'type' => \Elementor\Controls_Manager::TEXT]);
        $this->add_control('gallery_items', [
            'label'   => __('Gallery Images', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::REPEATER,
            'fields'  => $rep->get_controls(),
            'default' => [['alt' => 'Karbala'], ['alt' => 'Shrine'], ['alt' => 'Pilgrims']],
            'title_field' => '{{{ alt }}}',
        ]);
        $this->end_controls_section();
    }

    protected function render() {
        $s       = $this->get_settings_for_display();
        $bg_url  = !empty($s['bg_image']['url']) ? esc_url($s['bg_image']['url']) : '';
        $btn_url = !empty($s['btn_url']['url']) ? esc_url($s['btn_url']['url']) : '#';
        ?>
        <section class="ih-karbala">
            <?php if ($bg_url): ?>
            <img src="<?php echo $bg_url; ?>" alt="Karbala" class="ih-karbala-img">
            <?php else: ?>
            <div class="ih-karbala-img" style="background:linear-gradient(180deg,#1a0000,#5a0f0f)"></div>
            <?php endif; ?>

            <div class="ih-karbala-fade">
                <p class="ih-karbala-eyebrow"><?php echo esc_html($s['eyebrow']); ?></p>
                <h2 class="ih-karbala-title">
                    <?php echo esc_html($s['heading_plain']); ?>
                    <?php if (!empty($s['heading_red'])): ?>
                    <em><?php echo esc_html($s['heading_red']); ?></em>
                    <?php endif; ?>
                </h2>
                <?php if (!empty($s['body_text'])): ?>
                <p class="ih-karbala-text"><?php echo esc_html($s['body_text']); ?></p>
                <?php endif; ?>
                <?php if (!empty($s['btn_text'])): ?>
                <a href="<?php echo $btn_url; ?>" class="ih-btn-primary"><?php echo esc_html($s['btn_text']); ?></a>
                <?php endif; ?>

                <?php
                $gallery = array_filter((array)$s['gallery_items'], fn($g) => !empty($g['image']['url']));
                if (count($gallery) > 0):
                ?>
                <div class="ih-karbala-imgs" style="margin-top:32px">
                    <?php foreach (array_slice(array_values($gallery), 0, 3) as $g): ?>
                    <img src="<?php echo esc_url($g['image']['url']); ?>" alt="<?php echo esc_attr($g['alt']); ?>">
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </section>
        <?php
    }
}
