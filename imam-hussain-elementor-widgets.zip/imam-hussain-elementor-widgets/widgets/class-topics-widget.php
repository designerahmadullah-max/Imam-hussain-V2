<?php
if (!defined('ABSPATH')) exit;

class IH_Topics_Widget extends \Elementor\Widget_Base {

    public function get_name()  { return 'ih_topics'; }
    public function get_title() { return __('IH — Browse by Topics', 'ih-widgets'); }
    public function get_icon()  { return 'eicon-nav-menu'; }
    public function get_categories() { return ['imam-hussain']; }

    protected function register_controls() {
        $this->start_controls_section('sec_topics', ['label' => __('Topics Bar', 'ih-widgets')]);

        $this->add_control('label', [
            'label'   => __('Section Label', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'BROWSE BY TOPIC',
        ]);

        $this->add_repeater_control();

        $this->end_controls_section();
    }

    protected function add_repeater_control() {
        $repeater = new \Elementor\Repeater();

        $repeater->add_control('chapter', [
            'label'   => __('Chapter Number', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => '01',
        ]);
        $repeater->add_control('topic_name', [
            'label'   => __('Topic Name', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'Imam Hussain',
        ]);
        $repeater->add_control('topic_url', [
            'label'   => __('Link URL', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::URL,
            'default' => ['url' => '#'],
        ]);

        $this->add_control('topics', [
            'label'       => __('Topics', 'ih-widgets'),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'fields'      => $repeater->get_controls(),
            'default'     => [
                ['chapter' => '01', 'topic_name' => 'Imam Hussain', 'topic_url' => ['url' => '#']],
                ['chapter' => '02', 'topic_name' => 'Muharram',     'topic_url' => ['url' => '#']],
                ['chapter' => '03', 'topic_name' => 'Karbala',      'topic_url' => ['url' => '#']],
                ['chapter' => '04', 'topic_name' => 'Companions',   'topic_url' => ['url' => '#']],
                ['chapter' => '05', 'topic_name' => 'Arbaeen',      'topic_url' => ['url' => '#']],
                ['chapter' => '06', 'topic_name' => 'Ziarat',       'topic_url' => ['url' => '#']],
                ['chapter' => '07', 'topic_name' => 'Lessons',      'topic_url' => ['url' => '#']],
                ['chapter' => '08', 'topic_name' => 'Resources',    'topic_url' => ['url' => '#']],
            ],
            'title_field' => '{{{ topic_name }}}',
        ]);
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        ?>
        <div class="ih-topics">
            <div class="ih-topics-inner" style="max-width:1400px;margin-inline:auto;padding-inline:clamp(24px,4vw,80px)">
                <?php if (!empty($s['label'])): ?>
                <div class="ih-topics-label"><?php echo esc_html($s['label']); ?></div>
                <?php endif; ?>
                <div class="ih-topics-list">
                    <?php foreach ((array)$s['topics'] as $topic):
                        $url = !empty($topic['topic_url']['url']) ? esc_url($topic['topic_url']['url']) : '#';
                    ?>
                    <a href="<?php echo $url; ?>" class="ih-topic-item">
                        <span class="ih-topic-inner">
                            <?php if (!empty($topic['chapter'])): ?>
                            <span class="ih-topic-chapter"><?php echo esc_html($topic['chapter']); ?></span>
                            <?php endif; ?>
                            <?php echo esc_html($topic['topic_name']); ?>
                        </span>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
    }
}
