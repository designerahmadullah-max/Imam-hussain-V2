<?php
if (!defined('ABSPATH')) exit;

class IH_Hero_Widget extends \Elementor\Widget_Base {

    public function get_name()  { return 'ih_hero'; }
    public function get_title() { return __('IH — Hero Section', 'ih-widgets'); }
    public function get_icon()  { return 'eicon-slider-full-screen'; }
    public function get_categories() { return ['imam-hussain']; }
    public function get_keywords() { return ['hero', 'imam hussain', 'banner', 'karbala']; }

    protected function register_controls() {
        /* ── Content ── */
        $this->start_controls_section('sec_content', ['label' => __('Hero Content', 'ih-widgets')]);

        $this->add_control('eyebrow', [
            'label'   => __('Eyebrow Text', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'ISLAMIC KNOWLEDGE PORTAL',
        ]);
        $this->add_control('heading', [
            'label'   => __('Main Heading', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXTAREA,
            'default' => 'The Light of Karbala',
            'rows'    => 3,
        ]);
        $this->add_control('subtext', [
            'label'   => __('Subtext / Description', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXTAREA,
            'default' => 'Explore the teachings, sacrifice, and eternal legacy of Imam Hussain ibn Ali (A.S.) — the master of martyrs whose stand at Karbala illuminated the path of justice for all humanity.',
            'rows'    => 4,
        ]);

        $this->end_controls_section();

        /* ── Buttons ── */
        $this->start_controls_section('sec_buttons', ['label' => __('CTA Buttons', 'ih-widgets')]);

        $this->add_control('btn1_text', ['label' => __('Button 1 Text', 'ih-widgets'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Explore Karbala']);
        $this->add_control('btn1_url',  ['label' => __('Button 1 URL',  'ih-widgets'), 'type' => \Elementor\Controls_Manager::URL,  'default' => ['url' => '#']]);
        $this->add_control('btn2_text', ['label' => __('Button 2 Text', 'ih-widgets'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Read Teachings']);
        $this->add_control('btn2_url',  ['label' => __('Button 2 URL',  'ih-widgets'), 'type' => \Elementor\Controls_Manager::URL,  'default' => ['url' => '#']]);

        $this->end_controls_section();

        /* ── Background Image ── */
        $this->start_controls_section('sec_image', ['label' => __('Background Image', 'ih-widgets')]);

        $this->add_control('bg_image', [
            'label'   => __('Hero Background Image', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => ['url' => ''],
            'description' => __('Upload a high-resolution image (1920×900px recommended).', 'ih-widgets'),
        ]);
        $this->add_control('min_height', [
            'label'      => __('Minimum Height (vh)', 'ih-widgets'),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['vh'],
            'range'      => ['vh' => ['min' => 40, 'max' => 100]],
            'default'    => ['unit' => 'vh', 'size' => 85],
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        $s         = $this->get_settings_for_display();
        $bg_url    = !empty($s['bg_image']['url']) ? esc_url($s['bg_image']['url']) : '';
        $min_h     = !empty($s['min_height']['size']) ? intval($s['min_height']['size']) . 'vh' : '85vh';
        $style     = $bg_url ? 'background-image:url(' . $bg_url . ')' : '';
        $btn1_url  = !empty($s['btn1_url']['url']) ? esc_url($s['btn1_url']['url']) : '#';
        $btn2_url  = !empty($s['btn2_url']['url']) ? esc_url($s['btn2_url']['url']) : '#';
        $btn1_attr = !empty($s['btn1_url']['is_external']) ? ' target="_blank" rel="noopener"' : '';
        $btn2_attr = !empty($s['btn2_url']['is_external']) ? ' target="_blank" rel="noopener"' : '';
        ?>
        <section class="ih-hero" style="<?php echo $style; ?>;min-height:<?php echo esc_attr($min_h); ?>">
            <div class="ih-hero-overlay"></div>
            <div class="ih-hero-content">
                <?php if (!empty($s['eyebrow'])): ?>
                <p class="ih-hero-eyebrow"><?php echo esc_html($s['eyebrow']); ?></p>
                <?php endif; ?>
                <h1 class="ih-hero-heading"><?php echo nl2br(esc_html($s['heading'])); ?></h1>
                <?php if (!empty($s['subtext'])): ?>
                <p class="ih-hero-text"><?php echo esc_html($s['subtext']); ?></p>
                <?php endif; ?>
                <div class="ih-hero-buttons">
                    <?php if (!empty($s['btn1_text'])): ?>
                    <a href="<?php echo $btn1_url; ?>" class="ih-btn-primary"<?php echo $btn1_attr; ?>>
                        <?php echo esc_html($s['btn1_text']); ?>
                    </a>
                    <?php endif; ?>
                    <?php if (!empty($s['btn2_text'])): ?>
                    <a href="<?php echo $btn2_url; ?>" class="ih-btn-outline"<?php echo $btn2_attr; ?>>
                        <?php echo esc_html($s['btn2_text']); ?>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php
    }
}
