<?php
if (!defined('ABSPATH')) exit;

class IH_Philosophy_Widget extends \Elementor\Widget_Base {

    public function get_name()  { return 'ih_philosophy'; }
    public function get_title() { return __('IH — Philosophy / Quote Panel', 'ih-widgets'); }
    public function get_icon()  { return 'eicon-blockquote'; }
    public function get_categories() { return ['imam-hussain']; }

    protected function register_controls() {
        $this->start_controls_section('sec', ['label' => __('Quote Panel', 'ih-widgets')]);

        $this->add_control('eyebrow', [
            'label'   => __('Eyebrow Text', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'THE PHILOSOPHY OF HUSSAIN',
        ]);
        $this->add_control('quote_before', [
            'label'   => __('Quote — Plain Part', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXTAREA,
            'default' => '"Death with dignity is better than',
            'rows'    => 2,
        ]);
        $this->add_control('quote_highlight', [
            'label'   => __('Quote — Highlighted Part (red)', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'life with humiliation."',
        ]);
        $this->add_control('source', [
            'label'   => __('Source / Attribution', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => '— Imam Hussain ibn Ali (A.S.)',
        ]);
        $this->add_control('btn_text', [
            'label'   => __('Button Text (optional)', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::TEXT,
            'default' => 'Explore Teachings',
        ]);
        $this->add_control('btn_url', [
            'label'   => __('Button URL', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::URL,
            'default' => ['url' => '#'],
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        $s       = $this->get_settings_for_display();
        $btn_url = !empty($s['btn_url']['url']) ? esc_url($s['btn_url']['url']) : '#';
        ?>
        <section class="ih-philosophy">
            <div class="ih-philosophy-wrap">
                <p class="ih-philosophy-eyebrow"><?php echo esc_html($s['eyebrow']); ?></p>
                <p class="ih-philosophy-quote">
                    <?php echo esc_html($s['quote_before']); ?>
                    <?php if (!empty($s['quote_highlight'])): ?>
                    <span><?php echo esc_html($s['quote_highlight']); ?></span>
                    <?php endif; ?>
                </p>
                <?php if (!empty($s['source'])): ?>
                <p class="ih-philosophy-source"><?php echo esc_html($s['source']); ?></p>
                <?php endif; ?>
                <?php if (!empty($s['btn_text'])): ?>
                <div style="margin-top:40px">
                    <a href="<?php echo $btn_url; ?>" class="ih-btn-primary"><?php echo esc_html($s['btn_text']); ?></a>
                </div>
                <?php endif; ?>
            </div>
        </section>
        <?php
    }
}
