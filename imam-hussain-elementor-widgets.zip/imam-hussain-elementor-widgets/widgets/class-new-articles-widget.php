<?php
if (!defined('ABSPATH')) exit;

class IH_New_Articles_Widget extends \Elementor\Widget_Base {

    public function get_name()  { return 'ih_new_articles'; }
    public function get_title() { return __('IH — New Articles Grid', 'ih-widgets'); }
    public function get_icon()  { return 'eicon-posts-grid'; }
    public function get_categories() { return ['imam-hussain']; }

    protected function register_controls() {
        $this->start_controls_section('sec_header', ['label' => __('Section Header', 'ih-widgets')]);
        $this->add_control('eyebrow',        ['label' => __('Eyebrow',      'ih-widgets'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'NEW THIS WEEK']);
        $this->add_control('title',          ['label' => __('Title',        'ih-widgets'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Latest Articles']);
        $this->add_control('view_all_text',  ['label' => __('View All Text','ih-widgets'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'View All Articles']);
        $this->add_control('view_all_url',   ['label' => __('View All URL', 'ih-widgets'), 'type' => \Elementor\Controls_Manager::URL,  'default' => ['url' => '#']]);
        $this->end_controls_section();

        $this->start_controls_section('sec_source', ['label' => __('Articles Source', 'ih-widgets')]);
        $this->add_control('source_type', [
            'label'   => __('Source', 'ih-widgets'),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'options' => [
                'latest' => __('Latest posts (auto)', 'ih-widgets'),
                'manual' => __('Manual entry', 'ih-widgets'),
            ],
            'default' => 'manual',
        ]);
        $this->add_control('posts_count', [
            'label'     => __('Number of Posts (auto)', 'ih-widgets'),
            'type'      => \Elementor\Controls_Manager::NUMBER,
            'default'   => 6,
            'condition' => ['source_type' => 'latest'],
        ]);
        $this->add_manual_articles_repeater();
        $this->end_controls_section();
    }

    protected function add_manual_articles_repeater() {
        $repeater = new \Elementor\Repeater();
        $repeater->add_control('image',     ['label' => __('Image',    'ih-widgets'), 'type' => \Elementor\Controls_Manager::MEDIA]);
        $repeater->add_control('category',  ['label' => __('Category', 'ih-widgets'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'KARBALA']);
        $repeater->add_control('title',     ['label' => __('Title',    'ih-widgets'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Article Title']);
        $repeater->add_control('excerpt',   ['label' => __('Excerpt',  'ih-widgets'), 'type' => \Elementor\Controls_Manager::TEXTAREA, 'rows' => 2]);
        $repeater->add_control('read_time', ['label' => __('Read Time','ih-widgets'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => '6 min read']);
        $repeater->add_control('date',      ['label' => __('Date',     'ih-widgets'), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Jan 2025']);
        $repeater->add_control('url',       ['label' => __('URL',      'ih-widgets'), 'type' => \Elementor\Controls_Manager::URL, 'default' => ['url' => '#']]);

        $this->add_control('articles', [
            'label'       => __('Articles (manual, up to 6)', 'ih-widgets'),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'fields'      => $repeater->get_controls(),
            'default'     => [
                ['category' => 'MUHARRAM',   'title' => 'The Sacred Month of Muharram',          'read_time' => '8 min', 'date' => 'Jan 2025'],
                ['category' => 'KARBALA',    'title' => 'Understanding the Battle of Karbala',    'read_time' => '10 min','date' => 'Dec 2024'],
                ['category' => 'COMPANIONS', 'title' => 'Loyal Companions of Imam Hussain',       'read_time' => '7 min', 'date' => 'Dec 2024'],
                ['category' => 'ARBAEEN',    'title' => 'The Arbaeen Pilgrimage Experience',      'read_time' => '9 min', 'date' => 'Nov 2024'],
                ['category' => 'ZIARAT',     'title' => 'A Guide to Ziarat of Imam Hussain',      'read_time' => '6 min', 'date' => 'Nov 2024'],
                ['category' => 'LESSONS',    'title' => 'Lessons of Justice and Dignity',         'read_time' => '5 min', 'date' => 'Oct 2024'],
            ],
            'title_field' => '{{{ title }}}',
            'condition'   => ['source_type' => 'manual'],
        ]);
    }

    protected function render() {
        $s       = $this->get_settings_for_display();
        $va_url  = !empty($s['view_all_url']['url']) ? esc_url($s['view_all_url']['url']) : '#';

        if ($s['source_type'] === 'latest') {
            $query = new WP_Query([
                'post_type'      => ['post', 'ih_article'],
                'posts_per_page' => intval($s['posts_count']) ?: 6,
                'post_status'    => 'publish',
            ]);
            $items = [];
            if ($query->have_posts()) {
                while ($query->have_posts()) {
                    $query->the_post();
                    $cats = get_the_terms(get_the_ID(), 'category');
                    $items[] = [
                        'image'    => ['url' => has_post_thumbnail() ? get_the_post_thumbnail_url(null, 'ih-card') : ''],
                        'category' => ($cats && !is_wp_error($cats)) ? $cats[0]->name : '',
                        'title'    => get_the_title(),
                        'excerpt'  => wp_trim_words(get_the_excerpt(), 18),
                        'read_time'=> get_post_meta(get_the_ID(), '_read_time', true) ?: '5 min read',
                        'date'     => get_the_date('M Y'),
                        'url'      => ['url' => get_permalink()],
                    ];
                }
                wp_reset_postdata();
            }
        } else {
            $items = (array)$s['articles'];
        }
        ?>
        <section class="ih-articles">
            <div class="ih-articles-inner">
                <div class="ih-section-header">
                    <div>
                        <p class="ih-section-eyebrow"><?php echo esc_html($s['eyebrow']); ?></p>
                        <h2 class="ih-section-title"><?php echo esc_html($s['title']); ?></h2>
                    </div>
                    <?php if (!empty($s['view_all_text'])): ?>
                    <a href="<?php echo $va_url; ?>" class="ih-view-all">
                        <?php echo esc_html($s['view_all_text']); ?>
                        <svg width="14" height="14" fill="none" viewBox="0 0 14 14"><path d="M3 7h8M8 4l3 3-3 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </a>
                    <?php endif; ?>
                </div>

                <div class="ih-articles-grid">
                    <?php foreach (array_slice($items, 0, 6) as $item):
                        $url   = !empty($item['url']['url']) ? esc_url($item['url']['url']) : '#';
                        $thumb = !empty($item['image']['url']) ? esc_url($item['image']['url']) : '';
                    ?>
                    <article class="ih-article-card">
                        <a href="<?php echo $url; ?>">
                            <?php if ($thumb): ?>
                            <div class="ih-article-card-img"><img src="<?php echo $thumb; ?>" alt="<?php echo esc_attr($item['title']); ?>"></div>
                            <?php else: ?>
                            <div class="ih-article-card-img" style="background:linear-gradient(135deg,#e8e2d9,#c8c0b0)"></div>
                            <?php endif; ?>
                            <p class="cat-label"><?php echo esc_html($item['category']); ?></p>
                            <h3><?php echo esc_html($item['title']); ?></h3>
                            <?php if (!empty($item['excerpt'])): ?>
                            <p class="excerpt"><?php echo esc_html($item['excerpt']); ?></p>
                            <?php endif; ?>
                            <div class="meta">
                                <svg width="12" height="12" fill="none" viewBox="0 0 14 14"><circle cx="7" cy="7" r="6" stroke="currentColor" stroke-width="1.5"/><path d="M7 4v3l2 2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
                                <?php echo esc_html($item['read_time']); ?>
                                &middot; <?php echo esc_html($item['date']); ?>
                            </div>
                        </a>
                    </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
    }
}
