/**
 * Imam Hussain Editorial Theme — Main JS
 */
(function () {
  'use strict';

  // ─────────────────────────────────────────
  // Mobile Menu Toggle
  // ─────────────────────────────────────────
  var mobileMenuBtn = document.querySelector('.ih-mobile-menu-btn');
  var mobileNav     = document.querySelector('.ih-mobile-nav');

  if (mobileMenuBtn && mobileNav) {
    mobileMenuBtn.addEventListener('click', function () {
      var isOpen = mobileNav.classList.toggle('open');
      mobileMenuBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }

  // ─────────────────────────────────────────
  // Search Overlay
  // ─────────────────────────────────────────
  var searchBtns    = document.querySelectorAll('.ih-search-btn, .ih-mobile-search-btn');
  var searchOverlay = document.querySelector('.ih-search-overlay');
  var searchCancel  = document.querySelector('.ih-search-cancel');
  var searchInput   = document.querySelector('.ih-search-input');

  function openSearch() {
    if (!searchOverlay) return;
    searchOverlay.classList.add('open');
    document.body.style.overflow = 'hidden';
    if (searchInput) {
      setTimeout(function () { searchInput.focus(); }, 100);
    }
  }

  function closeSearch() {
    if (!searchOverlay) return;
    searchOverlay.classList.remove('open');
    document.body.style.overflow = '';
  }

  searchBtns.forEach(function (btn) {
    btn.addEventListener('click', openSearch);
  });

  if (searchCancel) {
    searchCancel.addEventListener('click', closeSearch);
  }

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeSearch();
  });

  // ─────────────────────────────────────────
  // Live Search (AJAX)
  // ─────────────────────────────────────────
  if (searchInput) {
    var searchResults = document.querySelector('.ih-search-results');
    var searchTimer   = null;

    searchInput.addEventListener('input', function () {
      clearTimeout(searchTimer);
      var query = this.value.trim();

      if (query.length < 2) {
        if (searchResults) searchResults.innerHTML = '';
        return;
      }

      searchTimer = setTimeout(function () {
        var ajaxUrl = (typeof ihData !== 'undefined') ? ihData.ajaxUrl : '/wp-admin/admin-ajax.php';

        fetch(ajaxUrl + '?action=ih_live_search&q=' + encodeURIComponent(query))
          .then(function (res) { return res.json(); })
          .then(function (data) {
            if (!searchResults) return;
            if (!data.posts || data.posts.length === 0) {
              searchResults.innerHTML = '<p style="text-align:center;color:#707070;padding:40px 0;font-family:\'Manrope\',sans-serif;">No results found for "' + escapeHtml(query) + '"</p>';
              return;
            }
            var html = '';
            data.posts.forEach(function (post) {
              html += '<a href="' + escapeHtml(post.url) + '" class="ih-search-result-item">';
              if (post.category) {
                html += '<span class="ih-cat-label">' + escapeHtml(post.category) + '</span>';
              }
              html += '<h3>' + escapeHtml(post.title) + '</h3>';
              if (post.excerpt) {
                html += '<p style="font-size:14px;color:#707070;margin:4px 0 0;font-family:\'Inter\',sans-serif;">' + escapeHtml(post.excerpt) + '</p>';
              }
              html += '</a>';
            });
            searchResults.innerHTML = html;
          })
          .catch(function () {
            /* silent fail */
          });
      }, 300);
    });
  }

  // ─────────────────────────────────────────
  // Topic bar active state
  // ─────────────────────────────────────────
  var topicBtns = document.querySelectorAll('.ih-topic-btn');
  topicBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      topicBtns.forEach(function (b) { b.classList.remove('active'); });
      this.classList.add('active');
    });
  });

  // ─────────────────────────────────────────
  // Utility: HTML escape
  // ─────────────────────────────────────────
  function escapeHtml(str) {
    var div = document.createElement('div');
    div.appendChild(document.createTextNode(str));
    return div.innerHTML;
  }

})();
