<?php
/**
 * Imam Hussain Theme Customizer Options
 *
 * @package imam-hussain
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function ih_customizer_register( $wp_customize ) {

	// ─────────────────────────────────────────
	// Panel: Homepage
	// ─────────────────────────────────────────
	$wp_customize->add_panel( 'ih_homepage_panel', array(
		'title'       => __( 'Homepage Settings', 'imam-hussain' ),
		'description' => __( 'Control the content displayed on the homepage.', 'imam-hussain' ),
		'priority'    => 30,
	) );

	// ─────────────────────────────────────────
	// Section: Hero
	// ─────────────────────────────────────────
	$wp_customize->add_section( 'ih_hero_section', array(
		'title'    => __( 'Hero Section', 'imam-hussain' ),
		'panel'    => 'ih_homepage_panel',
		'priority' => 10,
	) );

	// Hero Heading
	$wp_customize->add_setting( 'hero_heading', array(
		'default'           => __( 'The Light of Karbala', 'imam-hussain' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'hero_heading', array(
		'label'   => __( 'Hero Heading', 'imam-hussain' ),
		'section' => 'ih_hero_section',
		'type'    => 'text',
	) );

	// Hero Subtext
	$wp_customize->add_setting( 'hero_subtext', array(
		'default'           => __( 'Explore the teachings, sacrifice, and eternal legacy of Imam Hussain ibn Ali (A.S.) — the master of martyrs whose stand at Karbala illuminated the path of justice for all humanity.', 'imam-hussain' ),
		'sanitize_callback' => 'sanitize_textarea_field',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'hero_subtext', array(
		'label'   => __( 'Hero Subtext', 'imam-hussain' ),
		'section' => 'ih_hero_section',
		'type'    => 'textarea',
	) );

	// Hero Image (Desktop)
	$wp_customize->add_setting( 'hero_image', array(
		'default'           => '',
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'hero_image', array(
		'label'     => __( 'Hero Background Image (Desktop)', 'imam-hussain' ),
		'section'   => 'ih_hero_section',
		'mime_type' => 'image',
	) ) );

	// Hero Image (Mobile)
	$wp_customize->add_setting( 'hero_image_mobile', array(
		'default'           => '',
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'hero_image_mobile', array(
		'label'     => __( 'Hero Background Image (Mobile)', 'imam-hussain' ),
		'section'   => 'ih_hero_section',
		'mime_type' => 'image',
	) ) );

	// ─────────────────────────────────────────
	// Section: Karbala & Ziarat
	// ─────────────────────────────────────────
	$wp_customize->add_section( 'ih_karbala_section', array(
		'title'    => __( 'Karbala & Ziarat Section', 'imam-hussain' ),
		'panel'    => 'ih_homepage_panel',
		'priority' => 20,
	) );

	// Karbala Image
	$wp_customize->add_setting( 'karbala_image', array(
		'default'           => '',
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'karbala_image', array(
		'label'     => __( 'Karbala Section Background Image', 'imam-hussain' ),
		'section'   => 'ih_karbala_section',
		'mime_type' => 'image',
	) ) );

	// ─────────────────────────────────────────
	// Section: Contact & Social
	// ─────────────────────────────────────────
	$wp_customize->add_section( 'ih_contact_section', array(
		'title'    => __( 'Contact & Social', 'imam-hussain' ),
		'priority' => 40,
	) );

	// Site Email
	$wp_customize->add_setting( 'site_email', array(
		'default'           => 'contact@imamhussain.org',
		'sanitize_callback' => 'sanitize_email',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'site_email', array(
		'label'   => __( 'Contact Email Address', 'imam-hussain' ),
		'section' => 'ih_contact_section',
		'type'    => 'email',
	) );

	// Twitter / X
	$wp_customize->add_setting( 'social_twitter', array(
		'default'           => '#',
		'sanitize_callback' => 'esc_url_raw',
	) );
	$wp_customize->add_control( 'social_twitter', array(
		'label'   => __( 'Twitter / X URL', 'imam-hussain' ),
		'section' => 'ih_contact_section',
		'type'    => 'url',
	) );

	// Facebook
	$wp_customize->add_setting( 'social_facebook', array(
		'default'           => '#',
		'sanitize_callback' => 'esc_url_raw',
	) );
	$wp_customize->add_control( 'social_facebook', array(
		'label'   => __( 'Facebook URL', 'imam-hussain' ),
		'section' => 'ih_contact_section',
		'type'    => 'url',
	) );

	// Instagram
	$wp_customize->add_setting( 'social_instagram', array(
		'default'           => '#',
		'sanitize_callback' => 'esc_url_raw',
	) );
	$wp_customize->add_control( 'social_instagram', array(
		'label'   => __( 'Instagram URL', 'imam-hussain' ),
		'section' => 'ih_contact_section',
		'type'    => 'url',
	) );

	// YouTube
	$wp_customize->add_setting( 'social_youtube', array(
		'default'           => '#',
		'sanitize_callback' => 'esc_url_raw',
	) );
	$wp_customize->add_control( 'social_youtube', array(
		'label'   => __( 'YouTube URL', 'imam-hussain' ),
		'section' => 'ih_contact_section',
		'type'    => 'url',
	) );

	// ─────────────────────────────────────────
	// Selective Refresh Partials
	// ─────────────────────────────────────────
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'hero_heading', array(
			'selector'        => '.ih-hero-content h1',
			'render_callback' => function() {
				return esc_html( get_theme_mod( 'hero_heading', __( 'The Light of Karbala', 'imam-hussain' ) ) );
			},
		) );
		$wp_customize->selective_refresh->add_partial( 'hero_subtext', array(
			'selector'        => '.ih-hero-content p',
			'render_callback' => function() {
				return esc_html( get_theme_mod( 'hero_subtext' ) );
			},
		) );
		$wp_customize->selective_refresh->add_partial( 'site_email', array(
			'selector'        => '.ih-footer-email span',
			'render_callback' => function() {
				return esc_html( get_theme_mod( 'site_email', 'contact@imamhussain.org' ) );
			},
		) );
	}
}
add_action( 'customize_register', 'ih_customizer_register' );
