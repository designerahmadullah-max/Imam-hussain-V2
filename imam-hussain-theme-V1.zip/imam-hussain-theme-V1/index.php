<?php
/**
 * Homepage Template
 *
 * @package imam-hussain
 */

get_header();

// ─────────────────────────────────────────────
// Customizer values
// ─────────────────────────────────────────────
$hero_heading       = get_theme_mod( 'hero_heading', __( 'The Light of Karbala', 'imam-hussain' ) );
$hero_subtext       = get_theme_mod( 'hero_subtext', __( 'Explore the teachings, sacrifice, and eternal legacy of Imam Hussain ibn Ali (A.S.) — the master of martyrs whose stand at Karbala illuminated the path of justice for all humanity.', 'imam-hussain' ) );
$hero_image_id      = get_theme_mod( 'hero_image', 0 );
$hero_image_mobile  = get_theme_mod( 'hero_image_mobile', 0 );
$karbala_image_id   = get_theme_mod( 'karbala_image', 0 );

$hero_img_url = $hero_image_id ? wp_get_attachment_image_url( $hero_image_id, 'article-hero' ) : '';
$karbala_img_url = $karbala_image_id ? wp_get_attachment_image_url( $karbala_image_id, 'article-hero' ) : '';
?>

<!-- ======================================================
     SECTION 1: HERO
====================================================== -->
<section class="ih-hero" aria-label="<?php esc_attr_e( 'Hero section', 'imam-hussain' ); ?>">
  <div class="ih-hero-bg">
    <?php if ( $hero_img_url ) : ?>
      <img src="<?php echo esc_url( $hero_img_url ); ?>" alt="" aria-hidden="true" loading="eager">
    <?php else : ?>
      <div style="width:100%;height:100%;background:linear-gradient(135deg,#1a0000 0%,#3d0000 40%,#5c1010 70%,#2a0000 100%);"></div>
    <?php endif; ?>
  </div>
  <div class="ih-hero-overlay" aria-hidden="true"></div>

  <div class="ih-hero-content">
    <div class="ih-eyebrow"><?php esc_html_e( 'Islamic Knowledge Portal', 'imam-hussain' ); ?></div>
    <h1><?php echo esc_html( $hero_heading ); ?></h1>
    <p><?php echo esc_html( $hero_subtext ); ?></p>
    <div class="ih-hero-cta">
      <a href="<?php echo esc_url( home_url( '/category/karbala/' ) ); ?>" class="ih-btn ih-btn-primary">
        <?php esc_html_e( 'Explore Karbala', 'imam-hussain' ); ?>
      </a>
      <a href="<?php echo esc_url( home_url( '/category/teachings/' ) ); ?>" class="ih-btn ih-btn-outline-white">
        <?php esc_html_e( 'Read Teachings', 'imam-hussain' ); ?>
      </a>
    </div>
  </div>
</section>

<!-- ======================================================
     SECTION 2: TOPICS BAR
====================================================== -->
<section class="ih-topics">
  <div class="ih-container">
    <div class="ih-topics-label">
      <span class="ih-label"><?php esc_html_e( 'Browse by Topic', 'imam-hussain' ); ?></span>
    </div>
    <div class="ih-topics-row" role="list">
      <?php
      $topic_cats = get_categories( array(
        'orderby'    => 'count',
        'order'      => 'DESC',
        'number'     => 8,
        'hide_empty' => false,
      ) );

      $topic_descriptions = array(
        'karbala'          => 'The eternal stand',
        'teachings'        => 'Words of wisdom',
        'arbaeen'          => '20 million walk',
        'ziarat'           => 'Sacred pilgrimage',
        'companions'       => 'Heroes of faith',
        'muharram'         => 'Month of mourning',
        'life-of-imam-hussain' => 'Birth to martyrdom',
        'duas'             => 'Prayers & litanies',
        'ashura'           => 'Day of sacrifice',
        'family'           => 'Ahl al-Bayt',
      );

      $is_first = true;
      foreach ( $topic_cats as $cat ) {
        $desc = isset( $topic_descriptions[ $cat->slug ] ) ? $topic_descriptions[ $cat->slug ] : '';
        ?>
        <a href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>"
           class="ih-topic-btn<?php echo $is_first ? ' active' : ''; ?>"
           role="listitem">
          <span class="name"><?php echo esc_html( $cat->name ); ?></span>
          <?php if ( $desc ) : ?>
            <span class="desc"><?php echo esc_html( $desc ); ?></span>
          <?php endif; ?>
        </a>
        <?php
        $is_first = false;
      }

      // Fallback if no categories
      if ( empty( $topic_cats ) ) {
        $fallback_topics = array(
          array( 'name' => 'Karbala',          'desc' => 'The eternal stand',    'slug' => 'karbala' ),
          array( 'name' => 'Teachings',        'desc' => 'Words of wisdom',      'slug' => 'teachings' ),
          array( 'name' => 'Arbaeen',          'desc' => '20 million walk',      'slug' => 'arbaeen' ),
          array( 'name' => 'Ziarat',           'desc' => 'Sacred pilgrimage',    'slug' => 'ziarat' ),
          array( 'name' => 'Companions',       'desc' => 'Heroes of faith',      'slug' => 'companions' ),
          array( 'name' => 'Muharram',         'desc' => 'Month of mourning',    'slug' => 'muharram' ),
          array( 'name' => 'Life & Legacy',    'desc' => 'Birth to martyrdom',   'slug' => 'life-of-imam-hussain' ),
          array( 'name' => 'Duas',             'desc' => 'Prayers & litanies',   'slug' => 'duas' ),
        );
        foreach ( $fallback_topics as $i => $topic ) {
          ?>
          <a href="<?php echo esc_url( home_url( '/category/' . $topic['slug'] . '/' ) ); ?>"
             class="ih-topic-btn<?php echo $i === 0 ? ' active' : ''; ?>"
             role="listitem">
            <span class="name"><?php echo esc_html( $topic['name'] ); ?></span>
            <span class="desc"><?php echo esc_html( $topic['desc'] ); ?></span>
          </a>
          <?php
        }
      }
      ?>
    </div>
  </div>
</section>

<!-- ======================================================
     SECTION 3: EDITORIAL 2-COL (Karbala category)
====================================================== -->
<?php
$karbala_query = new WP_Query( array(
  'category_name'  => 'karbala',
  'posts_per_page' => 1,
  'post_status'    => 'publish',
) );

if ( $karbala_query->have_posts() ) :
  $karbala_query->the_post();
  $k_img     = get_the_post_thumbnail_url( null, 'article-hero' );
  $k_cat     = ih_primary_category();
  $k_excerpt = get_the_excerpt();
?>
<section class="ih-section ih-section-light">
  <div class="ih-container">
    <div class="ih-article-2col">
      <div class="ih-article-2col-text">
        <?php if ( $k_cat ) : ?>
          <span class="ih-eyebrow"><?php echo esc_html( $k_cat->name ); ?></span>
        <?php endif; ?>
        <h2><?php the_title(); ?></h2>
        <p><?php echo esc_html( $k_excerpt ); ?></p>
        <a href="<?php the_permalink(); ?>" class="ih-btn ih-btn-primary">
          <?php esc_html_e( 'Read Article', 'imam-hussain' ); ?>
        </a>
      </div>
      <div class="ih-article-2col-img">
        <?php if ( $k_img ) : ?>
          <img src="<?php echo esc_url( $k_img ); ?>"
               alt="<?php echo esc_attr( get_the_title() ); ?>"
               loading="lazy">
        <?php else : ?>
          <div class="ih-img-placeholder">
            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#aaa" stroke-width="1" aria-hidden="true">
              <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>
            </svg>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
<?php
  wp_reset_postdata();
endif;
?>

<!-- ======================================================
     SECTION 4: 3-COL (2 images + Arbaeen text)
====================================================== -->
<?php
$arbaeen_query = new WP_Query( array(
  'category_name'  => 'arbaeen',
  'posts_per_page' => 2,
  'post_status'    => 'publish',
) );
$arbaeen_posts = array();
if ( $arbaeen_query->have_posts() ) {
  while ( $arbaeen_query->have_posts() ) {
    $arbaeen_query->the_post();
    $arbaeen_posts[] = array(
      'id'    => get_the_ID(),
      'title' => get_the_title(),
      'img'   => get_the_post_thumbnail_url( null, 'article-thumb' ),
      'url'   => get_the_permalink(),
    );
  }
  wp_reset_postdata();
}
?>
<section class="ih-section">
  <div class="ih-container">
    <div class="ih-article-3col">

      <!-- Image 1 -->
      <div class="ih-3col-img">
        <?php if ( ! empty( $arbaeen_posts[0]['img'] ) ) : ?>
          <a href="<?php echo esc_url( $arbaeen_posts[0]['url'] ); ?>">
            <img src="<?php echo esc_url( $arbaeen_posts[0]['img'] ); ?>"
                 alt="<?php echo esc_attr( $arbaeen_posts[0]['title'] ); ?>"
                 loading="lazy">
          </a>
        <?php else : ?>
          <div class="ih-img-placeholder" style="height:100%;min-height:240px;">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#aaa" stroke-width="1" aria-hidden="true">
              <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>
            </svg>
          </div>
        <?php endif; ?>
      </div>

      <!-- Image 2 -->
      <div class="ih-3col-img">
        <?php if ( ! empty( $arbaeen_posts[1]['img'] ) ) : ?>
          <a href="<?php echo esc_url( $arbaeen_posts[1]['url'] ); ?>">
            <img src="<?php echo esc_url( $arbaeen_posts[1]['img'] ); ?>"
                 alt="<?php echo esc_attr( $arbaeen_posts[1]['title'] ); ?>"
                 loading="lazy">
          </a>
        <?php else : ?>
          <div class="ih-img-placeholder" style="height:100%;min-height:240px;">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#aaa" stroke-width="1" aria-hidden="true">
              <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>
            </svg>
          </div>
        <?php endif; ?>
      </div>

      <!-- Text -->
      <div class="ih-3col-text">
        <span class="ih-eyebrow"><?php esc_html_e( 'Arbaeen', 'imam-hussain' ); ?></span>
        <h2><?php esc_html_e( 'The World\'s Largest', 'imam-hussain' ); ?> <span><?php esc_html_e( 'Peaceful Gathering', 'imam-hussain' ); ?></span></h2>
        <p><?php esc_html_e( 'Every year, millions of pilgrims walk hundreds of kilometres to Karbala to commemorate the 40th day after the martyrdom of Imam Hussain (A.S.). The Arbaeen pilgrimage stands as the largest peaceful human gathering in the world — a testament to the enduring power of his message.', 'imam-hussain' ); ?></p>
        <a href="<?php echo esc_url( home_url( '/category/arbaeen/' ) ); ?>" class="ih-btn ih-btn-outline">
          <?php esc_html_e( 'Explore Arbaeen', 'imam-hussain' ); ?>
        </a>
      </div>

    </div>
  </div>
</section>

<!-- ======================================================
     SECTION 5: FEATURED ARTICLES (1 large + 6 thumbs)
====================================================== -->
<?php
$featured_query = new WP_Query( array(
  'posts_per_page' => 7,
  'post_status'    => 'publish',
  'orderby'        => 'date',
  'order'          => 'DESC',
) );
$feat_posts = array();
if ( $featured_query->have_posts() ) {
  while ( $featured_query->have_posts() ) {
    $featured_query->the_post();
    $cat = ih_primary_category();
    $feat_posts[] = array(
      'id'      => get_the_ID(),
      'title'   => get_the_title(),
      'excerpt' => get_the_excerpt(),
      'img'     => get_the_post_thumbnail_url( null, 'article-hero' ),
      'thumb'   => get_the_post_thumbnail_url( null, 'thumb-small' ),
      'url'     => get_the_permalink(),
      'cat'     => $cat ? $cat->name : '',
      'time'    => ih_reading_time(),
    );
  }
  wp_reset_postdata();
}
$feat_main   = $feat_posts[0] ?? null;
$feat_thumbs = array_slice( $feat_posts, 1, 6 );
?>
<section class="ih-section ih-section-light">
  <div class="ih-container">
    <div class="ih-section-header">
      <h2><?php esc_html_e( 'Featured Articles', 'imam-hussain' ); ?></h2>
      <a href="<?php echo esc_url( home_url( '/?orderby=date' ) ); ?>" class="ih-btn ih-btn-outline" style="font-size:13px;padding:8px 20px;">
        <?php esc_html_e( 'View All', 'imam-hussain' ); ?>
      </a>
    </div>

    <?php if ( $feat_main || ! empty( $feat_thumbs ) ) : ?>
    <div class="ih-featured-grid">

      <!-- Main featured -->
      <?php if ( $feat_main ) : ?>
      <a href="<?php echo esc_url( $feat_main['url'] ); ?>" class="ih-featured-main">
        <?php if ( $feat_main['img'] ) : ?>
          <img src="<?php echo esc_url( $feat_main['img'] ); ?>"
               alt="<?php echo esc_attr( $feat_main['title'] ); ?>"
               loading="lazy">
        <?php else : ?>
          <div style="position:absolute;inset:0;background:linear-gradient(135deg,#1a0000,#5c1010);"></div>
        <?php endif; ?>
        <div class="ih-featured-overlay" aria-hidden="true"></div>
        <div class="ih-featured-text">
          <?php if ( $feat_main['cat'] ) : ?>
            <span class="ih-cat-label"><?php echo esc_html( $feat_main['cat'] ); ?></span>
          <?php endif; ?>
          <h3><?php echo esc_html( $feat_main['title'] ); ?></h3>
          <p><?php echo esc_html( $feat_main['excerpt'] ); ?></p>
          <div class="ih-read-time">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
              <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
            </svg>
            <?php printf( esc_html__( '%d min read', 'imam-hussain' ), $feat_main['time'] ); ?>
          </div>
        </div>
      </a>
      <?php endif; ?>

      <!-- Thumbnail grid -->
      <div class="ih-featured-thumbs">
        <?php foreach ( $feat_thumbs as $thumb ) : ?>
        <a href="<?php echo esc_url( $thumb['url'] ); ?>" class="ih-thumb-item">
          <div class="ih-thumb-img">
            <?php if ( $thumb['thumb'] ) : ?>
              <img src="<?php echo esc_url( $thumb['thumb'] ); ?>"
                   alt="<?php echo esc_attr( $thumb['title'] ); ?>"
                   loading="lazy">
            <?php else : ?>
              <div class="ih-img-placeholder" style="height:100%;">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#aaa" stroke-width="1" aria-hidden="true">
                  <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>
                </svg>
              </div>
            <?php endif; ?>
          </div>
          <div class="ih-thumb-body">
            <?php if ( $thumb['cat'] ) : ?>
              <span class="ih-cat-label"><?php echo esc_html( $thumb['cat'] ); ?></span>
            <?php endif; ?>
            <h3><?php echo esc_html( $thumb['title'] ); ?></h3>
            <div class="ih-read-time">
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
              </svg>
              <?php printf( esc_html__( '%d min read', 'imam-hussain' ), $thumb['time'] ); ?>
            </div>
          </div>
        </a>
        <?php endforeach; ?>
      </div>

    </div>
    <?php endif; ?>
  </div>
</section>

<!-- ======================================================
     SECTION 6: RED PHILOSOPHY PANEL
====================================================== -->
<section class="ih-philosophy" aria-label="<?php esc_attr_e( 'Philosophy statements', 'imam-hussain' ); ?>">
  <div class="ih-container">
    <div class="ih-philosophy-grid">

      <div class="ih-philosophy-item">
        <div class="icon" aria-hidden="true">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
        </div>
        <p><?php esc_html_e( '"Death with dignity is better than a life of humiliation."', 'imam-hussain' ); ?></p>
      </div>

      <div class="ih-philosophy-item">
        <div class="icon" aria-hidden="true">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
          </svg>
        </div>
        <p><?php esc_html_e( '"If you have no religion, at least be free in your present life."', 'imam-hussain' ); ?></p>
      </div>

      <div class="ih-philosophy-item">
        <div class="icon" aria-hidden="true">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 8v4l3 3"/>
          </svg>
        </div>
        <p><?php esc_html_e( '"Every day is Ashura, every land is Karbala."', 'imam-hussain' ); ?></p>
      </div>

    </div>
  </div>
</section>

<!-- ======================================================
     SECTION 7: NEW ARTICLES (6 most recent)
====================================================== -->
<?php
$recent_query = new WP_Query( array(
  'posts_per_page' => 6,
  'post_status'    => 'publish',
  'orderby'        => 'date',
  'order'          => 'DESC',
  'offset'         => 7, // skip already shown posts
) );
$recent_posts = array();
if ( $recent_query->have_posts() ) {
  while ( $recent_query->have_posts() ) {
    $recent_query->the_post();
    $cat = ih_primary_category();
    $recent_posts[] = array(
      'title'   => get_the_title(),
      'excerpt' => get_the_excerpt(),
      'img'     => get_the_post_thumbnail_url( null, 'article-thumb' ),
      'url'     => get_the_permalink(),
      'cat'     => $cat ? $cat->name : '',
      'time'    => ih_reading_time(),
      'date'    => get_the_date( 'M j, Y' ),
    );
  }
  wp_reset_postdata();
}
?>
<section class="ih-section">
  <div class="ih-container">
    <div class="ih-section-header">
      <h2><?php esc_html_e( 'Latest Articles', 'imam-hussain' ); ?></h2>
      <a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>" class="ih-btn ih-btn-outline" style="font-size:13px;padding:8px 20px;">
        <?php esc_html_e( 'All Articles', 'imam-hussain' ); ?>
      </a>
    </div>
    <div class="ih-articles-grid">
      <?php
      if ( ! empty( $recent_posts ) ) :
        foreach ( $recent_posts as $rpost ) :
      ?>
      <a href="<?php echo esc_url( $rpost['url'] ); ?>" class="ih-article-card">
        <div class="ih-article-card-img">
          <?php if ( $rpost['img'] ) : ?>
            <img src="<?php echo esc_url( $rpost['img'] ); ?>"
                 alt="<?php echo esc_attr( $rpost['title'] ); ?>"
                 loading="lazy">
          <?php else : ?>
            <div class="ih-img-placeholder" style="height:100%;">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#aaa" stroke-width="1" aria-hidden="true">
                <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>
              </svg>
            </div>
          <?php endif; ?>
        </div>
        <?php if ( $rpost['cat'] ) : ?>
          <span class="ih-cat-label"><?php echo esc_html( $rpost['cat'] ); ?></span>
        <?php endif; ?>
        <h3><?php echo esc_html( $rpost['title'] ); ?></h3>
        <p style="font-size:14px;color:#707070;line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;">
          <?php echo esc_html( $rpost['excerpt'] ); ?>
        </p>
        <div class="ih-read-time" style="margin-top:12px;">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
            <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
          </svg>
          <?php printf( esc_html__( '%d min read', 'imam-hussain' ), $rpost['time'] ); ?>
          <span style="color:#ccc;">•</span>
          <span><?php echo esc_html( $rpost['date'] ); ?></span>
        </div>
      </a>
      <?php
        endforeach;
      else :
        // If no posts yet, show placeholders
        for ( $i = 0; $i < 6; $i++ ) :
        ?>
        <div class="ih-article-card" style="opacity:.5;">
          <div class="ih-article-card-img">
            <div class="ih-img-placeholder" style="height:100%;min-height:200px;"></div>
          </div>
          <span class="ih-cat-label"><?php esc_html_e( 'Category', 'imam-hussain' ); ?></span>
          <h3><?php esc_html_e( 'Article Title Will Appear Here', 'imam-hussain' ); ?></h3>
        </div>
        <?php
        endfor;
      endif;
      ?>
    </div>
  </div>
</section>

<!-- ======================================================
     SECTION 8: MESSAGE CARDS SCROLL
====================================================== -->
<section class="ih-messages">
  <div class="ih-container">
    <div class="ih-messages-heading">
      <span class="ih-eyebrow"><?php esc_html_e( 'His Message', 'imam-hussain' ); ?></span>
      <h2><?php esc_html_e( 'Timeless Wisdom for All of Humanity', 'imam-hussain' ); ?></h2>
      <p><?php esc_html_e( 'The teachings of Imam Hussain (A.S.) transcend time, culture, and religion — offering guidance on justice, dignity, and the pursuit of truth.', 'imam-hussain' ); ?></p>
    </div>
  </div>

  <div class="ih-scroll-container" aria-label="<?php esc_attr_e( 'Scrolling message cards', 'imam-hussain' ); ?>">
    <div class="ih-scroll-track">
      <?php
      // We output two copies for seamless infinite scroll
      $message_cards = array(
        array(
          'icon'  => 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
          'title' => __( 'Justice Above All', 'imam-hussain' ),
          'text'  => __( 'Imam Hussain\'s stand at Karbala was a declaration that oppression must never be accepted silently. His sacrifice became the eternal symbol of resistance for the righteous.', 'imam-hussain' ),
        ),
        array(
          'icon'  => 'M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z',
          'title' => __( 'The Power of Love', 'imam-hussain' ),
          'text'  => __( 'Even on the night before Ashura, Imam Hussain requested time from his enemies — to spend the night in prayer and supplication to God. His love for his Creator was unmatched.', 'imam-hussain' ),
        ),
        array(
          'icon'  => 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2 M23 21v-2a4 4 0 0 0-3-3.87 M16 3.13a4 4 0 0 1 0 7.75',
          'title' => __( 'Universal Brotherhood', 'imam-hussain' ),
          'text'  => __( 'The Arbaeen walk draws millions of people from over 40 nations — Muslims and non-Muslims alike — united by a shared reverence for sacrifice, justice, and human dignity.', 'imam-hussain' ),
        ),
        array(
          'icon'  => 'M12 2L2 7l10 5 10-5-10-5z M2 17l10 5 10-5 M2 12l10 5 10-5',
          'title' => __( 'Nobility of Character', 'imam-hussain' ),
          'text'  => __( 'Imam Hussain was known for his extraordinary generosity, his care for the poor, and his unwavering moral character — qualities that continue to inspire people across the world.', 'imam-hussain' ),
        ),
        array(
          'icon'  => 'M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
          'title' => __( 'The Right to Truth', 'imam-hussain' ),
          'text'  => __( 'He refused to pledge allegiance to corruption and falsehood. His example teaches that every human being has a responsibility to speak the truth regardless of consequences.', 'imam-hussain' ),
        ),
        array(
          'icon'  => 'M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z M12 6v6l4 2',
          'title' => __( 'The Legacy Lives On', 'imam-hussain' ),
          'text'  => __( 'Fourteen centuries after Karbala, the message of Imam Hussain resonates louder than ever. His sacrifice did not end an era — it began one, awakening the conscience of generations.', 'imam-hussain' ),
        ),
      );

      // Output twice for CSS infinite scroll loop
      for ( $loop = 0; $loop < 2; $loop++ ) :
        foreach ( $message_cards as $card ) :
      ?>
      <div class="ih-message-card">
        <div class="icon" aria-hidden="true">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="<?php echo esc_attr( $card['icon'] ); ?>"/>
          </svg>
        </div>
        <h3><?php echo esc_html( $card['title'] ); ?></h3>
        <p><?php echo esc_html( $card['text'] ); ?></p>
      </div>
      <?php
        endforeach;
      endfor;
      ?>
    </div><!-- /.ih-scroll-track -->
  </div><!-- /.ih-scroll-container -->
</section>

<!-- ======================================================
     SECTION 9: KARBALA & ZIARAT
====================================================== -->
<section class="ih-karbala">
  <div class="ih-karbala-img-wrap">
    <?php if ( $karbala_img_url ) : ?>
      <img src="<?php echo esc_url( $karbala_img_url ); ?>"
           alt="<?php esc_attr_e( 'Karbala shrine', 'imam-hussain' ); ?>"
           loading="lazy">
    <?php else : ?>
      <div style="width:100%;height:100%;background:linear-gradient(180deg,#8b3333 0%,#5c1010 40%,#3d0000 100%);"></div>
    <?php endif; ?>
  </div>

  <div class="ih-karbala-text">
    <span class="ih-eyebrow"><?php esc_html_e( 'Karbala & Ziarat', 'imam-hussain' ); ?></span>
    <h2><?php esc_html_e( 'Journey to', 'imam-hussain' ); ?> <span class="red"><?php esc_html_e( 'the Sacred Land', 'imam-hussain' ); ?></span></h2>
    <p><?php esc_html_e( 'The city of Karbala holds one of the holiest shrines in the Islamic world — the resting place of Imam Hussain ibn Ali (A.S.). Every year, pilgrims from across the globe journey here to pay their respects, recite ziarat, and renew their connection to his timeless message.', 'imam-hussain' ); ?></p>

    <?php
    $ziarat_query = new WP_Query( array(
      'category_name'  => 'ziarat',
      'posts_per_page' => 3,
      'post_status'    => 'publish',
    ) );
    if ( $ziarat_query->have_posts() ) :
    ?>
    <div class="ih-karbala-3imgs">
      <?php
      while ( $ziarat_query->have_posts() ) :
        $ziarat_query->the_post();
        $z_img = get_the_post_thumbnail_url( null, 'article-thumb' );
      ?>
      <a href="<?php the_permalink(); ?>" class="img-item" aria-label="<?php echo esc_attr( get_the_title() ); ?>">
        <?php if ( $z_img ) : ?>
          <img src="<?php echo esc_url( $z_img ); ?>"
               alt="<?php echo esc_attr( get_the_title() ); ?>"
               loading="lazy">
        <?php else : ?>
          <div class="ih-img-placeholder" style="height:100%;min-height:200px;background:linear-gradient(135deg,#3d0000,#8b3333);"></div>
        <?php endif; ?>
      </a>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
    <?php
    else :
      // Placeholder grid
    ?>
    <div class="ih-karbala-3imgs">
      <?php for ( $i = 0; $i < 3; $i++ ) : ?>
      <div class="img-item">
        <div class="ih-img-placeholder" style="height:100%;min-height:200px;background:linear-gradient(135deg,#3d0000,#8b3333);"></div>
      </div>
      <?php endfor; ?>
    </div>
    <?php endif; ?>

    <div style="margin-top:40px;">
      <a href="<?php echo esc_url( home_url( '/category/ziarat/' ) ); ?>" class="ih-btn ih-btn-primary">
        <?php esc_html_e( 'Explore Ziarat', 'imam-hussain' ); ?>
      </a>
    </div>
  </div>
</section>

<!-- ======================================================
     SECTION 10: MOST POPULAR
====================================================== -->
<?php
$categories_list = get_categories( array(
  'orderby'    => 'count',
  'order'      => 'DESC',
  'number'     => 4,
  'hide_empty' => true,
) );
?>
<section class="ih-most-popular">
  <div class="ih-container">
    <div class="ih-section-header" style="margin-bottom:32px;">
      <h2><?php esc_html_e( 'Most Popular', 'imam-hussain' ); ?></h2>
    </div>
    <div class="ih-most-popular-grid">
      <?php foreach ( $categories_list as $pop_cat ) : ?>
      <div class="ih-popular-col">
        <h3><?php echo esc_html( $pop_cat->name ); ?></h3>
        <?php
        $pop_query = new WP_Query( array(
          'cat'            => $pop_cat->term_id,
          'posts_per_page' => 5,
          'post_status'    => 'publish',
          'orderby'        => 'comment_count',
          'order'          => 'DESC',
        ) );
        ?>
        <ul>
          <?php
          while ( $pop_query->have_posts() ) :
            $pop_query->the_post();
          ?>
          <li>
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
          </li>
          <?php endwhile; wp_reset_postdata(); ?>
        </ul>
      </div>
      <?php endforeach; ?>

      <?php if ( empty( $categories_list ) ) : ?>
      <!-- Fallback if no categories with posts -->
      <?php
      $fallback_cats = array(
        __( 'Karbala', 'imam-hussain' ),
        __( 'Teachings', 'imam-hussain' ),
        __( 'Arbaeen', 'imam-hussain' ),
        __( 'Ziarat', 'imam-hussain' ),
      );
      foreach ( $fallback_cats as $fc_name ) : ?>
      <div class="ih-popular-col">
        <h3><?php echo esc_html( $fc_name ); ?></h3>
        <p style="font-size:13px;color:#707070;"><?php esc_html_e( 'Articles will appear here.', 'imam-hussain' ); ?></p>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>

    </div>
  </div>
</section>

<?php get_footer(); ?>
