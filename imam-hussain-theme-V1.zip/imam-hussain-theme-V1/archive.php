<?php
/**
 * Archive / Category Page Template
 *
 * @package imam-hussain
 */

get_header();

$queried_object  = get_queried_object();
$is_category     = is_category();
$archive_title   = get_the_archive_title();
$archive_desc    = get_the_archive_description();
$cat_name        = $is_category ? single_cat_title( '', false ) : $archive_title;

// Related categories for pills
$sibling_cats    = get_categories( array(
  'number'     => 12,
  'orderby'    => 'count',
  'order'      => 'DESC',
  'hide_empty' => true,
) );
?>

<!-- ======================================================
     CATEGORY HEADER
====================================================== -->
<header class="ih-category-header">
  <div class="ih-container">
    <span class="ih-eyebrow">
      <?php
      if ( is_category() ) {
        esc_html_e( 'Category', 'imam-hussain' );
      } elseif ( is_tag() ) {
        esc_html_e( 'Tag', 'imam-hussain' );
      } elseif ( is_author() ) {
        esc_html_e( 'Author', 'imam-hussain' );
      } elseif ( is_date() ) {
        esc_html_e( 'Archive', 'imam-hussain' );
      } else {
        esc_html_e( 'Browse', 'imam-hussain' );
      }
      ?>
    </span>
    <h1><?php echo esc_html( $cat_name ); ?></h1>
    <?php if ( $archive_desc ) : ?>
      <p><?php echo wp_kses_post( $archive_desc ); ?></p>
    <?php endif; ?>

    <!-- Category filter pills -->
    <?php if ( ! empty( $sibling_cats ) && $is_category ) : ?>
    <nav class="ih-category-pills" aria-label="<?php esc_attr_e( 'Category filter', 'imam-hussain' ); ?>">
      <a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>" class="ih-pill">
        <?php esc_html_e( 'All', 'imam-hussain' ); ?>
      </a>
      <?php foreach ( $sibling_cats as $sib_cat ) : ?>
        <a href="<?php echo esc_url( get_category_link( $sib_cat->term_id ) ); ?>"
           class="ih-pill<?php echo ( is_category( $sib_cat->term_id ) ) ? ' active' : ''; ?>">
          <?php echo esc_html( $sib_cat->name ); ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <?php endif; ?>
  </div>
</header>

<!-- ======================================================
     ARCHIVE CONTENT
====================================================== -->
<main class="ih-section" id="main-content">
  <div class="ih-container">

    <?php if ( have_posts() ) : ?>

      <?php
      // First post — featured hero
      the_post();
      $first_img     = get_the_post_thumbnail_url( null, 'article-hero' );
      $first_cat     = ih_primary_category();
      $first_excerpt = get_the_excerpt();
      ?>

      <!-- Featured first post -->
      <a href="<?php the_permalink(); ?>" class="ih-archive-hero">
        <?php if ( $first_img ) : ?>
          <img src="<?php echo esc_url( $first_img ); ?>"
               alt="<?php echo esc_attr( get_the_title() ); ?>"
               loading="eager">
        <?php else : ?>
          <div style="width:100%;height:100%;background:linear-gradient(135deg,#1a0000,#5c1010);"></div>
        <?php endif; ?>
        <div class="ih-archive-hero-overlay" aria-hidden="true"></div>
        <div class="ih-archive-hero-text">
          <?php if ( $first_cat ) : ?>
            <span class="ih-cat-label"><?php echo esc_html( $first_cat->name ); ?></span>
          <?php endif; ?>
          <h2><?php the_title(); ?></h2>
          <p><?php echo esc_html( $first_excerpt ); ?></p>
          <div class="ih-read-time" style="color:rgba(255,255,255,.7);">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
              <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
            </svg>
            <?php printf( esc_html__( '%d min read', 'imam-hussain' ), ih_reading_time() ); ?>
            <span style="margin-left:8px;opacity:.6;"><?php echo esc_html( get_the_date( 'F j, Y' ) ); ?></span>
          </div>
        </div>
      </a>

      <!-- Remaining posts grid -->
      <?php if ( have_posts() ) : ?>
      <div class="ih-articles-grid" style="margin-top:16px;">
        <?php
        while ( have_posts() ) :
          the_post();
          $g_img     = get_the_post_thumbnail_url( null, 'article-thumb' );
          $g_cat     = ih_primary_category();
        ?>
        <a href="<?php the_permalink(); ?>" class="ih-article-card">
          <div class="ih-article-card-img">
            <?php if ( $g_img ) : ?>
              <img src="<?php echo esc_url( $g_img ); ?>"
                   alt="<?php echo esc_attr( get_the_title() ); ?>"
                   loading="lazy">
            <?php else : ?>
              <div class="ih-img-placeholder" style="height:100%;min-height:200px;"></div>
            <?php endif; ?>
          </div>
          <?php if ( $g_cat ) : ?>
            <span class="ih-cat-label"><?php echo esc_html( $g_cat->name ); ?></span>
          <?php endif; ?>
          <h3><?php the_title(); ?></h3>
          <p style="font-size:14px;color:#707070;line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;">
            <?php the_excerpt(); ?>
          </p>
          <div class="ih-read-time" style="margin-top:12px;">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
              <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
            </svg>
            <?php printf( esc_html__( '%d min read', 'imam-hussain' ), ih_reading_time() ); ?>
            <span style="color:#ccc;">•</span>
            <span><?php echo esc_html( get_the_date( 'M j, Y' ) ); ?></span>
          </div>
        </a>
        <?php endwhile; ?>
      </div>
      <?php endif; ?>

      <!-- Pagination -->
      <nav class="ih-pagination" aria-label="<?php esc_attr_e( 'Page navigation', 'imam-hussain' ); ?>">
        <?php
        $big = 999999999; // need an unlikely integer
        echo paginate_links( array(
          'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
          'format'  => '?paged=%#%',
          'current' => max( 1, get_query_var( 'paged' ) ),
          'total'   => $wp_query->max_num_pages,
          'prev_text' => '&lsaquo;',
          'next_text' => '&rsaquo;',
        ) );
        ?>
      </nav>

    <?php else : ?>
      <!-- No posts found -->
      <div style="text-align:center;padding:80px 0;">
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1.5" style="margin:0 auto 24px;" aria-hidden="true">
          <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
        </svg>
        <h2 style="font-size:32px;color:#212121;margin-bottom:16px;">
          <?php esc_html_e( 'No articles found', 'imam-hussain' ); ?>
        </h2>
        <p style="font-size:16px;color:#707070;margin-bottom:32px;">
          <?php esc_html_e( 'There are no articles in this category yet. Check back soon.', 'imam-hussain' ); ?>
        </p>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="ih-btn ih-btn-primary">
          <?php esc_html_e( 'Return Home', 'imam-hussain' ); ?>
        </a>
      </div>
    <?php endif; ?>

  </div>
</main>

<?php get_footer(); ?>
