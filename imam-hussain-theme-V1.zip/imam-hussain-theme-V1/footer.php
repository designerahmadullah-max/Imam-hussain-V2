<!-- ======================================================
     FOOTER
====================================================== -->
<footer class="ih-footer" role="contentinfo">

  <!-- Red arc behind logo -->
  <div class="ih-footer-arc" aria-hidden="true"></div>

  <!-- Main body -->
  <div class="ih-footer-body">

    <!-- Logo column -->
    <div class="ih-footer-logo-wrap">
      <?php
      if ( has_custom_logo() ) {
        the_custom_logo();
      } else {
        ?>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" style="text-decoration:none;">
          <div class="ih-footer-logo-text">Imam<br>Hussain</div>
          <div class="ih-footer-logo-sub">Editorial</div>
        </a>
        <?php
      }
      ?>
      <p style="font-family:'Manrope',sans-serif;font-size:13px;color:rgba(255,255,255,.5);line-height:1.6;margin-top:20px;max-width:200px;">
        <?php esc_html_e( 'Illuminating the path of justice through the legacy of Imam Hussain (A.S.)', 'imam-hussain' ); ?>
      </p>
    </div><!-- /.ih-footer-logo-wrap -->

    <!-- Navigation columns -->
    <div class="ih-footer-nav">

      <!-- Column 1 -->
      <div class="ih-footer-nav-col">
        <?php
        if ( has_nav_menu( 'footer-col-1' ) ) {
          wp_nav_menu( array(
            'theme_location' => 'footer-col-1',
            'container'      => false,
            'before'         => '',
            'after'          => '',
            'link_before'    => '',
            'link_after'     => '',
            'depth'          => 1,
            'fallback_cb'    => false,
          ) );
        } else {
          ?>
          <div class="chapter">01</div>
          <h4><?php esc_html_e( 'Life & Teachings', 'imam-hussain' ); ?></h4>
          <ul>
            <li><a href="<?php echo esc_url( home_url( '/category/life-of-imam-hussain/' ) ); ?>"><?php esc_html_e( 'Life of Imam Hussain', 'imam-hussain' ); ?></a></li>
            <li><a href="<?php echo esc_url( home_url( '/category/teachings/' ) ); ?>"><?php esc_html_e( 'Teachings &amp; Wisdom', 'imam-hussain' ); ?></a></li>
            <li><a href="<?php echo esc_url( home_url( '/category/duas/' ) ); ?>"><?php esc_html_e( "Duas &amp; Supplications", 'imam-hussain' ); ?></a></li>
            <li><a href="<?php echo esc_url( home_url( '/category/family/' ) ); ?>"><?php esc_html_e( 'Family of the Prophet', 'imam-hussain' ); ?></a></li>
            <li><a href="<?php echo esc_url( home_url( '/category/companions/' ) ); ?>"><?php esc_html_e( 'Companions of Karbala', 'imam-hussain' ); ?></a></li>
          </ul>
          <?php
        }
        ?>
      </div><!-- /.ih-footer-nav-col -->

      <!-- Column 2 -->
      <div class="ih-footer-nav-col">
        <?php
        if ( has_nav_menu( 'footer-col-2' ) ) {
          wp_nav_menu( array(
            'theme_location' => 'footer-col-2',
            'container'      => false,
            'before'         => '',
            'after'          => '',
            'link_before'    => '',
            'link_after'     => '',
            'depth'          => 1,
            'fallback_cb'    => false,
          ) );
        } else {
          ?>
          <div class="chapter">02</div>
          <h4><?php esc_html_e( 'Karbala & Ziarat', 'imam-hussain' ); ?></h4>
          <ul>
            <li><a href="<?php echo esc_url( home_url( '/category/karbala/' ) ); ?>"><?php esc_html_e( 'The Battle of Karbala', 'imam-hussain' ); ?></a></li>
            <li><a href="<?php echo esc_url( home_url( '/category/arbaeen/' ) ); ?>"><?php esc_html_e( 'Arbaeen Walk', 'imam-hussain' ); ?></a></li>
            <li><a href="<?php echo esc_url( home_url( '/category/ziarat/' ) ); ?>"><?php esc_html_e( 'Ziarat &amp; Pilgrimage', 'imam-hussain' ); ?></a></li>
            <li><a href="<?php echo esc_url( home_url( '/category/muharram/' ) ); ?>"><?php esc_html_e( 'Muharram', 'imam-hussain' ); ?></a></li>
            <li><a href="<?php echo esc_url( home_url( '/category/ashura/' ) ); ?>"><?php esc_html_e( 'Day of Ashura', 'imam-hussain' ); ?></a></li>
          </ul>
          <?php
        }
        ?>
      </div><!-- /.ih-footer-nav-col -->

      <!-- Column 3 -->
      <div class="ih-footer-nav-col">
        <?php
        if ( has_nav_menu( 'footer-col-3' ) ) {
          wp_nav_menu( array(
            'theme_location' => 'footer-col-3',
            'container'      => false,
            'before'         => '',
            'after'          => '',
            'link_before'    => '',
            'link_after'     => '',
            'depth'          => 1,
            'fallback_cb'    => false,
          ) );
        } else {
          ?>
          <div class="chapter">03</div>
          <h4><?php esc_html_e( 'About', 'imam-hussain' ); ?></h4>
          <ul>
            <li><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>"><?php esc_html_e( 'About Us', 'imam-hussain' ); ?></a></li>
            <li><a href="<?php echo esc_url( home_url( '/editorial-team/' ) ); ?>"><?php esc_html_e( 'Editorial Team', 'imam-hussain' ); ?></a></li>
            <li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Contact', 'imam-hussain' ); ?></a></li>
            <li><a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>"><?php esc_html_e( 'Privacy Policy', 'imam-hussain' ); ?></a></li>
            <li><a href="<?php echo esc_url( home_url( '/terms/' ) ); ?>"><?php esc_html_e( 'Terms of Use', 'imam-hussain' ); ?></a></li>
          </ul>
          <?php
        }
        ?>
      </div><!-- /.ih-footer-nav-col -->

    </div><!-- /.ih-footer-nav -->

  </div><!-- /.ih-footer-body -->

  <!-- Bottom bar -->
  <div class="ih-footer-bottom">

    <!-- Email -->
    <div class="ih-footer-email">
      <div class="ih-footer-email-icon" aria-hidden="true">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
        </svg>
      </div>
      <span><?php echo esc_html( get_theme_mod( 'site_email', 'contact@imamhussain.org' ) ); ?></span>
    </div>

    <!-- Social icons -->
    <div class="ih-footer-social">
      <?php
      $twitter   = get_theme_mod( 'social_twitter',   '#' );
      $facebook  = get_theme_mod( 'social_facebook',  '#' );
      $instagram = get_theme_mod( 'social_instagram', '#' );
      $youtube   = get_theme_mod( 'social_youtube',   '#' );
      ?>

      <?php if ( $twitter ) : ?>
      <a href="<?php echo esc_url( $twitter ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'Follow us on X / Twitter', 'imam-hussain' ); ?>">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.737-8.835L2 2.25h7.078l4.253 5.622Zm-1.161 17.52h1.833L7.084 4.126H5.117Z"/>
        </svg>
      </a>
      <?php endif; ?>

      <?php if ( $facebook ) : ?>
      <a href="<?php echo esc_url( $facebook ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'Follow us on Facebook', 'imam-hussain' ); ?>">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
        </svg>
      </a>
      <?php endif; ?>

      <?php if ( $instagram ) : ?>
      <a href="<?php echo esc_url( $instagram ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'Follow us on Instagram', 'imam-hussain' ); ?>">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
          <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
        </svg>
      </a>
      <?php endif; ?>

      <?php if ( $youtube ) : ?>
      <a href="<?php echo esc_url( $youtube ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'Subscribe on YouTube', 'imam-hussain' ); ?>">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
          <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
        </svg>
      </a>
      <?php endif; ?>
    </div>

    <!-- Copyright -->
    <p class="ih-footer-copy">
      &copy; <?php echo esc_html( date( 'Y' ) ); ?>
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="color:inherit;"><?php bloginfo( 'name' ); ?></a>.
      <?php esc_html_e( 'All rights reserved.', 'imam-hussain' ); ?>
    </p>

  </div><!-- /.ih-footer-bottom -->

</footer><!-- /.ih-footer -->

<?php wp_footer(); ?>
</body>
</html>
