<?php
/**
 * Single Article Template
 *
 * @package imam-hussain
 */

get_header();

while ( have_posts() ) :
  the_post();

  $cat      = ih_primary_category();
  $hero_img = get_the_post_thumbnail_url( null, 'article-hero' );
  $read_time = ih_reading_time();
?>

<!-- ======================================================
     BREADCRUMB
====================================================== -->
<nav class="ih-breadcrumb" aria-label="<?php esc_attr_e( 'Breadcrumb', 'imam-hussain' ); ?>">
  <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'imam-hussain' ); ?></a>
  <span class="ih-breadcrumb-sep" aria-hidden="true">›</span>
  <?php if ( $cat ) : ?>
    <a href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>"><?php echo esc_html( $cat->name ); ?></a>
    <span class="ih-breadcrumb-sep" aria-hidden="true">›</span>
  <?php endif; ?>
  <span aria-current="page"><?php the_title(); ?></span>
</nav>

<!-- ======================================================
     ARTICLE HEADER
====================================================== -->
<header class="ih-article-header">
  <?php if ( $cat ) : ?>
    <span class="ih-cat-label"><?php echo esc_html( $cat->name ); ?></span>
  <?php endif; ?>
  <h1><?php the_title(); ?></h1>
  <div class="ih-article-meta">
    <span class="author">
      <?php esc_html_e( 'By', 'imam-hussain' ); ?>
      <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"
         style="color:inherit;font-weight:600;">
        <?php the_author(); ?>
      </a>
    </span>
    <span class="separator" aria-hidden="true">·</span>
    <span class="date">
      <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
        <?php echo esc_html( get_the_date( 'F j, Y' ) ); ?>
      </time>
    </span>
    <span class="separator" aria-hidden="true">·</span>
    <span style="display:flex;align-items:center;gap:5px;color:#707070;font-size:14px;">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
        <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
      </svg>
      <?php printf( esc_html__( '%d min read', 'imam-hussain' ), $read_time ); ?>
    </span>
  </div>
</header>

<!-- ======================================================
     HERO IMAGE
====================================================== -->
<?php if ( $hero_img ) : ?>
<div class="ih-article-hero">
  <img src="<?php echo esc_url( $hero_img ); ?>"
       alt="<?php echo esc_attr( get_the_title() ); ?>"
       loading="eager">
</div>
<?php endif; ?>

<!-- ======================================================
     ARTICLE BODY
====================================================== -->
<article class="ih-article-body" id="article-content">
  <?php the_content(); ?>

  <?php
  // Page links for paginated posts
  wp_link_pages( array(
    'before' => '<div style="margin:32px 0;display:flex;gap:8px;align-items:center;"><span style="font-size:14px;color:#707070;">' . esc_html__( 'Pages:', 'imam-hussain' ) . '</span>',
    'after'  => '</div>',
    'link_before' => '<span style="padding:6px 14px;border:1px solid #e8e8e8;border-radius:6px;font-family:\'Manrope\',sans-serif;font-size:14px;color:#212121;text-decoration:none;">',
    'link_after'  => '</span>',
  ) );
  ?>

  <!-- Tags -->
  <?php
  $tags = get_the_tags();
  if ( $tags ) :
  ?>
  <div style="margin-top:48px;padding-top:32px;border-top:1px solid #f0f0f0;">
    <span style="font-size:12px;font-weight:600;letter-spacing:2px;text-transform:uppercase;color:#707070;font-family:'Manrope',sans-serif;">
      <?php esc_html_e( 'Topics:', 'imam-hussain' ); ?>
    </span>
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:12px;">
      <?php foreach ( $tags as $tag ) : ?>
      <a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>" class="ih-pill">
        <?php echo esc_html( $tag->name ); ?>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- Author bio -->
  <?php if ( get_the_author_meta( 'description' ) ) : ?>
  <div style="margin-top:48px;padding:28px;background:#faf9f5;border-radius:16px;display:flex;gap:20px;align-items:flex-start;">
    <div style="flex-shrink:0;">
      <?php echo get_avatar( get_the_author_meta( 'ID' ), 64, '', '', array( 'style' => 'border-radius:50%;' ) ); ?>
    </div>
    <div>
      <div style="font-family:'Manrope',sans-serif;font-size:11px;font-weight:600;letter-spacing:2px;text-transform:uppercase;color:#c81e1e;margin-bottom:4px;">
        <?php esc_html_e( 'About the Author', 'imam-hussain' ); ?>
      </div>
      <div style="font-family:'DM Serif Display',serif;font-size:20px;color:#212121;margin-bottom:8px;">
        <?php the_author(); ?>
      </div>
      <p style="font-size:14px;color:#3a3a3a;line-height:1.6;">
        <?php echo esc_html( get_the_author_meta( 'description' ) ); ?>
      </p>
    </div>
  </div>
  <?php endif; ?>

</article>

<!-- ======================================================
     RELATED ARTICLES
====================================================== -->
<?php
if ( $cat ) :
  $related_query = new WP_Query( array(
    'category__in'   => array( $cat->term_id ),
    'post__not_in'   => array( get_the_ID() ),
    'posts_per_page' => 3,
    'post_status'    => 'publish',
    'orderby'        => 'rand',
  ) );

  if ( $related_query->have_posts() ) :
?>
<section class="ih-related">
  <div class="ih-container">
    <h2><?php esc_html_e( 'Related Articles', 'imam-hussain' ); ?></h2>
    <div class="ih-articles-grid">
      <?php
      while ( $related_query->have_posts() ) :
        $related_query->the_post();
        $rel_cat = ih_primary_category();
        $rel_img = get_the_post_thumbnail_url( null, 'article-thumb' );
      ?>
      <a href="<?php the_permalink(); ?>" class="ih-article-card">
        <div class="ih-article-card-img">
          <?php if ( $rel_img ) : ?>
            <img src="<?php echo esc_url( $rel_img ); ?>"
                 alt="<?php echo esc_attr( get_the_title() ); ?>"
                 loading="lazy">
          <?php else : ?>
            <div class="ih-img-placeholder" style="height:100%;min-height:200px;"></div>
          <?php endif; ?>
        </div>
        <?php if ( $rel_cat ) : ?>
          <span class="ih-cat-label"><?php echo esc_html( $rel_cat->name ); ?></span>
        <?php endif; ?>
        <h3><?php the_title(); ?></h3>
        <div class="ih-read-time" style="margin-top:8px;">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
            <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
          </svg>
          <?php printf( esc_html__( '%d min read', 'imam-hussain' ), ih_reading_time() ); ?>
        </div>
      </a>
      <?php
      endwhile;
      wp_reset_postdata();
      ?>
    </div>
  </div>
</section>
<?php
  endif;
endif;
?>

<!-- Comments -->
<?php
if ( comments_open() || get_comments_number() ) :
  echo '<div style="max-width:740px;margin:0 auto;padding:0 24px 64px;">';
  comments_template();
  echo '</div>';
endif;
?>

<?php
endwhile;

get_footer();
?>
