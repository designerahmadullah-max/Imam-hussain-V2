<?php
/**
 * Search Results Template
 *
 * @package imam-hussain
 */

get_header();
?>

<header class="ih-category-header">
  <div class="ih-container">
    <span class="ih-eyebrow"><?php esc_html_e( 'Search Results', 'imam-hussain' ); ?></span>
    <h1>
      <?php
      printf(
        /* translators: %s: search query */
        esc_html__( 'Results for: %s', 'imam-hussain' ),
        '<em>' . esc_html( get_search_query() ) . '</em>'
      );
      ?>
    </h1>
    <?php if ( have_posts() ) : ?>
      <p style="margin-top:8px;font-size:16px;color:#707070;">
        <?php printf( esc_html__( 'Found %d articles', 'imam-hussain' ), $wp_query->found_posts ); ?>
      </p>
    <?php endif; ?>
  </div>
</header>

<main class="ih-section" id="main-content">
  <div class="ih-container">
    <?php if ( have_posts() ) : ?>
      <div class="ih-articles-grid">
        <?php
        while ( have_posts() ) :
          the_post();
          $s_img = get_the_post_thumbnail_url( null, 'article-thumb' );
          $s_cat = ih_primary_category();
        ?>
        <a href="<?php the_permalink(); ?>" class="ih-article-card">
          <div class="ih-article-card-img">
            <?php if ( $s_img ) : ?>
              <img src="<?php echo esc_url( $s_img ); ?>"
                   alt="<?php echo esc_attr( get_the_title() ); ?>"
                   loading="lazy">
            <?php else : ?>
              <div class="ih-img-placeholder" style="height:100%;min-height:200px;"></div>
            <?php endif; ?>
          </div>
          <?php if ( $s_cat ) : ?>
            <span class="ih-cat-label"><?php echo esc_html( $s_cat->name ); ?></span>
          <?php endif; ?>
          <h3><?php the_title(); ?></h3>
          <p style="font-size:14px;color:#707070;line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;">
            <?php the_excerpt(); ?>
          </p>
          <div class="ih-read-time" style="margin-top:12px;">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
              <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
            </svg>
            <?php printf( esc_html__( '%d min read', 'imam-hussain' ), ih_reading_time() ); ?>
          </div>
        </a>
        <?php endwhile; ?>
      </div>

      <nav class="ih-pagination" aria-label="<?php esc_attr_e( 'Page navigation', 'imam-hussain' ); ?>">
        <?php
        $big = 999999999;
        echo paginate_links( array(
          'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
          'format'    => '?paged=%#%',
          'current'   => max( 1, get_query_var( 'paged' ) ),
          'total'     => $wp_query->max_num_pages,
          'prev_text' => '&lsaquo;',
          'next_text' => '&rsaquo;',
        ) );
        ?>
      </nav>

    <?php else : ?>
      <div style="text-align:center;padding:80px 0;">
        <h2 style="font-size:32px;color:#212121;margin-bottom:16px;"><?php esc_html_e( 'No results found', 'imam-hussain' ); ?></h2>
        <p style="font-size:16px;color:#707070;margin-bottom:32px;">
          <?php esc_html_e( 'Try a different search term or browse our categories.', 'imam-hussain' ); ?>
        </p>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="ih-btn ih-btn-primary">
          <?php esc_html_e( 'Return Home', 'imam-hussain' ); ?>
        </a>
      </div>
    <?php endif; ?>
  </div>
</main>

<?php get_footer(); ?>
