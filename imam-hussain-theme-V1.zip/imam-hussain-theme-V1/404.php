<?php
/**
 * 404 Error Page Template
 *
 * @package imam-hussain
 */

get_header();
?>

<main style="min-height:60vh;display:flex;align-items:center;justify-content:center;padding:80px 24px;">
  <div style="text-align:center;max-width:560px;">
    <div style="font-family:'DM Serif Display',serif;font-size:120px;color:#f0ede6;line-height:1;margin-bottom:0;" aria-hidden="true">404</div>
    <h1 style="font-family:'DM Serif Display',serif;font-size:40px;color:#212121;margin:-20px 0 16px;position:relative;z-index:1;">
      <?php esc_html_e( 'Page Not Found', 'imam-hussain' ); ?>
    </h1>
    <p style="font-size:16px;color:#707070;margin-bottom:32px;line-height:1.6;">
      <?php esc_html_e( 'The page you are looking for may have moved or no longer exists. Return to the homepage or search for what you need.', 'imam-hussain' ); ?>
    </p>
    <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap;">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="ih-btn ih-btn-primary">
        <?php esc_html_e( 'Return Home', 'imam-hussain' ); ?>
      </a>
      <button class="ih-btn ih-btn-outline ih-search-btn">
        <?php esc_html_e( 'Search Articles', 'imam-hussain' ); ?>
      </button>
    </div>
  </div>
</main>

<?php get_footer(); ?>
