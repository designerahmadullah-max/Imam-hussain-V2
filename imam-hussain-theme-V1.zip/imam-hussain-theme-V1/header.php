<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Inter:wght@300;400;500;600;700&family=Manrope:wght@300;400;500;600;700;800&family=Merriweather:ital,wght@0,400;1,400&display=swap" rel="stylesheet">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- ======================================================
     HEADER
====================================================== -->
<header class="ih-header" role="banner">

  <!-- Desktop Header -->
  <div class="ih-header-desktop">

    <!-- Left Side -->
    <div class="ih-header-side ih-header-side-left">
      <div class="ih-red-bar"></div>
      <?php
      wp_nav_menu( array(
        'theme_location' => 'primary-left',
        'container'      => 'nav',
        'container_attr' => array( 'aria-label' => __( 'Primary left navigation', 'imam-hussain' ) ),
        'walker'         => new IH_Nav_Walker(),
        'fallback_cb'    => 'ih_fallback_nav_left',
      ) );
      ?>
    </div><!-- /.ih-header-side-left -->

    <!-- Logo -->
    <div class="ih-header-logo">
      <?php
      if ( has_custom_logo() ) {
        the_custom_logo();
      } else {
        ?>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" style="display:flex;flex-direction:column;align-items:center;text-decoration:none;">
          <span style="font-family:'DM Serif Display',serif;font-size:26px;color:#212121;line-height:1.1;">Imam Hussain</span>
          <span style="font-family:'Manrope',sans-serif;font-size:11px;letter-spacing:2px;text-transform:uppercase;color:#c81e1e;margin-top:4px;">Editorial</span>
        </a>
        <?php
      }
      ?>
    </div><!-- /.ih-header-logo -->

    <!-- Right Side -->
    <div class="ih-header-side ih-header-side-right">
      <div class="ih-red-bar"></div>
      <?php
      wp_nav_menu( array(
        'theme_location' => 'primary-right',
        'container'      => 'nav',
        'container_attr' => array( 'aria-label' => __( 'Primary right navigation', 'imam-hussain' ) ),
        'walker'         => new IH_Nav_Walker(),
        'fallback_cb'    => 'ih_fallback_nav_right',
      ) );
      ?>
      <button class="ih-search-btn" aria-label="<?php esc_attr_e( 'Open search', 'imam-hussain' ); ?>">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
        </svg>
      </button>
    </div><!-- /.ih-header-side-right -->

  </div><!-- /.ih-header-desktop -->

  <!-- Mobile Header -->
  <div class="ih-mobile-header">
    <div class="ih-mobile-logo">
      <?php
      if ( has_custom_logo() ) {
        the_custom_logo();
      } else {
        ?>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" style="text-decoration:none;">
          <span style="font-family:'DM Serif Display',serif;font-size:22px;color:#212121;">Imam Hussain</span>
        </a>
        <?php
      }
      ?>
    </div>

    <div style="display:flex;align-items:center;gap:8px;">
      <button class="ih-mobile-search-btn" aria-label="<?php esc_attr_e( 'Open search', 'imam-hussain' ); ?>">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
        </svg>
      </button>
      <button class="ih-mobile-menu-btn" aria-expanded="false" aria-controls="ih-mobile-nav" aria-label="<?php esc_attr_e( 'Toggle menu', 'imam-hussain' ); ?>">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <line x1="3" y1="6" x2="21" y2="6"/>
          <line x1="3" y1="12" x2="21" y2="12"/>
          <line x1="3" y1="18" x2="21" y2="18"/>
        </svg>
      </button>
    </div>
  </div><!-- /.ih-mobile-header -->

  <!-- Mobile Nav -->
  <nav id="ih-mobile-nav" class="ih-mobile-nav" aria-label="<?php esc_attr_e( 'Mobile navigation', 'imam-hussain' ); ?>">
    <?php
    $all_locations = array( 'primary-left', 'primary-right' );
    $order = 1;
    foreach ( $all_locations as $location ) {
      $menu_items = wp_get_nav_menu_items( get_nav_menu_locations()[ $location ] ?? 0 );
      if ( $menu_items ) {
        foreach ( $menu_items as $item ) {
          $chapter = sprintf( '%02d', $order );
          ?>
          <a href="<?php echo esc_url( $item->url ); ?>" class="ih-mobile-nav-item">
            <span class="chapter"><?php echo esc_html( $chapter ); ?></span>
            <span class="label"><?php echo esc_html( $item->title ); ?></span>
          </a>
          <?php
          $order++;
        }
      }
    }
    // Fallback links if no menus set
    if ( $order === 1 ) {
      $fallback_items = array(
        array( 'url' => home_url( '/category/life-of-imam-hussain/' ), 'chapter' => '01', 'label' => 'Life & Legacy' ),
        array( 'url' => home_url( '/category/karbala/' ),              'chapter' => '02', 'label' => 'Karbala' ),
        array( 'url' => home_url( '/category/teachings/' ),            'chapter' => '03', 'label' => 'Teachings' ),
        array( 'url' => home_url( '/category/arbaeen/' ),              'chapter' => '04', 'label' => 'Arbaeen' ),
        array( 'url' => home_url( '/category/ziarat/' ),               'chapter' => '05', 'label' => 'Ziarat' ),
        array( 'url' => home_url( '/category/companions/' ),           'chapter' => '06', 'label' => 'Companions' ),
      );
      foreach ( $fallback_items as $item ) {
        ?>
        <a href="<?php echo esc_url( $item['url'] ); ?>" class="ih-mobile-nav-item">
          <span class="chapter"><?php echo esc_html( $item['chapter'] ); ?></span>
          <span class="label"><?php echo esc_html( $item['label'] ); ?></span>
        </a>
        <?php
      }
    }
    ?>
  </nav><!-- /.ih-mobile-nav -->

</header><!-- /.ih-header -->

<!-- ======================================================
     SEARCH OVERLAY
====================================================== -->
<div class="ih-search-overlay" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Search', 'imam-hussain' ); ?>">

  <div class="ih-search-overlay-top">
    <?php
    if ( has_custom_logo() ) {
      the_custom_logo();
    } else {
      ?>
      <span style="font-family:'DM Serif Display',serif;font-size:22px;color:#212121;">Imam Hussain</span>
      <?php
    }
    ?>
    <button class="ih-search-cancel" aria-label="<?php esc_attr_e( 'Close search', 'imam-hussain' ); ?>">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="M18 6 6 18"/><path d="m6 6 12 12"/>
      </svg>
      <?php esc_html_e( 'Close', 'imam-hussain' ); ?>
    </button>
  </div>

  <div class="ih-search-form">
    <form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
      <div class="ih-search-input-wrap">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#ccc" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex-shrink:0;">
          <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
        </svg>
        <input
          type="search"
          name="s"
          class="ih-search-input"
          placeholder="<?php esc_attr_e( 'Search teachings, articles...', 'imam-hussain' ); ?>"
          value="<?php echo esc_attr( get_search_query() ); ?>"
          autocomplete="off"
          aria-label="<?php esc_attr_e( 'Search', 'imam-hussain' ); ?>"
        >
      </div>
    </form>
  </div>

  <div class="ih-search-results" aria-live="polite" aria-atomic="true"></div>

</div><!-- /.ih-search-overlay -->

<?php
// ─────────────────────────────────────────────────────────
// Fallback nav functions (used when menus are not assigned)
// ─────────────────────────────────────────────────────────
function ih_fallback_nav_left() {
  $items = array(
    array( 'url' => home_url( '/category/life-of-imam-hussain/' ), 'chapter' => '01', 'label' => 'Life & Legacy' ),
    array( 'url' => home_url( '/category/karbala/' ),              'chapter' => '02', 'label' => 'Karbala' ),
    array( 'url' => home_url( '/category/teachings/' ),            'chapter' => '03', 'label' => 'Teachings' ),
  );
  echo '<nav aria-label="' . esc_attr__( 'Primary left navigation', 'imam-hussain' ) . '"><ul style="display:flex;align-items:center;list-style:none;margin:0;padding:0;">';
  foreach ( $items as $item ) {
    echo '<li><a href="' . esc_url( $item['url'] ) . '" class="ih-nav-item"><span class="chapter">' . esc_html( $item['chapter'] ) . '</span><span class="label">' . esc_html( $item['label'] ) . '</span></a></li>';
  }
  echo '</ul></nav>';
}

function ih_fallback_nav_right() {
  $items = array(
    array( 'url' => home_url( '/category/arbaeen/' ),    'chapter' => '04', 'label' => 'Arbaeen' ),
    array( 'url' => home_url( '/category/ziarat/' ),     'chapter' => '05', 'label' => 'Ziarat' ),
    array( 'url' => home_url( '/category/companions/' ), 'chapter' => '06', 'label' => 'Companions' ),
  );
  echo '<nav aria-label="' . esc_attr__( 'Primary right navigation', 'imam-hussain' ) . '"><ul style="display:flex;align-items:center;list-style:none;margin:0;padding:0;">';
  foreach ( $items as $item ) {
    echo '<li><a href="' . esc_url( $item['url'] ) . '" class="ih-nav-item"><span class="chapter">' . esc_html( $item['chapter'] ) . '</span><span class="label">' . esc_html( $item['label'] ) . '</span></a></li>';
  }
  echo '</ul></nav>';
}
?>
