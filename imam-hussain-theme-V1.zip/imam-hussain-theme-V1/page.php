<?php
/**
 * Static Page Template
 *
 * @package imam-hussain
 */

get_header();

while ( have_posts() ) :
  the_post();
  $hero_img = get_the_post_thumbnail_url( null, 'article-hero' );
?>

<nav class="ih-breadcrumb" aria-label="<?php esc_attr_e( 'Breadcrumb', 'imam-hussain' ); ?>">
  <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'imam-hussain' ); ?></a>
  <span class="ih-breadcrumb-sep" aria-hidden="true">›</span>
  <span aria-current="page"><?php the_title(); ?></span>
</nav>

<header class="ih-article-header">
  <h1><?php the_title(); ?></h1>
</header>

<?php if ( $hero_img ) : ?>
<div class="ih-article-hero">
  <img src="<?php echo esc_url( $hero_img ); ?>"
       alt="<?php echo esc_attr( get_the_title() ); ?>"
       loading="eager">
</div>
<?php endif; ?>

<div class="ih-article-body">
  <?php the_content(); ?>
</div>

<?php endwhile; ?>

<?php get_footer(); ?>
