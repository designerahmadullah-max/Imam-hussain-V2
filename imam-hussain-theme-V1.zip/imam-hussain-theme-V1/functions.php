<?php
/**
 * Imam Hussain Editorial Theme Functions
 *
 * @package imam-hussain
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'IH_VERSION', '1.0.0' );
define( 'IH_DIR', get_template_directory() );
define( 'IH_URI', get_template_directory_uri() );

// ─────────────────────────────────────────────
// Theme Setup
// ─────────────────────────────────────────────
function ih_setup() {
	load_theme_textdomain( 'imam-hussain', IH_DIR . '/languages' );

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'customize-selective-refresh-widgets' );

	add_theme_support( 'custom-logo', array(
		'height'      => 90,
		'width'       => 200,
		'flex-height' => true,
		'flex-width'  => true,
	) );

	// Custom image sizes
	add_image_size( 'article-thumb', 800, 500, true );
	add_image_size( 'article-hero', 1400, 700, true );
	add_image_size( 'thumb-small', 220, 168, true );

	// Navigation menus
	register_nav_menus( array(
		'primary-left'  => __( 'Primary Left Navigation', 'imam-hussain' ),
		'primary-right' => __( 'Primary Right Navigation', 'imam-hussain' ),
		'footer-col-1'  => __( 'Footer Column 1', 'imam-hussain' ),
		'footer-col-2'  => __( 'Footer Column 2', 'imam-hussain' ),
		'footer-col-3'  => __( 'Footer Column 3', 'imam-hussain' ),
	) );
}
add_action( 'after_setup_theme', 'ih_setup' );

// ─────────────────────────────────────────────
// Enqueue Scripts & Styles
// ─────────────────────────────────────────────
function ih_enqueue_assets() {
	// Google Fonts
	$google_fonts_url = 'https://fonts.googleapis.com/css2?' .
		'family=DM+Serif+Display:ital@0;1' .
		'&family=Inter:wght@300;400;500;600;700' .
		'&family=Manrope:wght@300;400;500;600;700;800' .
		'&family=Merriweather:ital,wght@0,400;1,400' .
		'&display=swap';

	wp_enqueue_style( 'ih-google-fonts', $google_fonts_url, array(), null );
	wp_enqueue_style( 'ih-main', IH_URI . '/assets/css/main.css', array( 'ih-google-fonts' ), IH_VERSION );
	wp_enqueue_script( 'ih-main', IH_URI . '/assets/js/main.js', array(), IH_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'ih_enqueue_assets' );

// ─────────────────────────────────────────────
// Custom Post Type: imam-hussain
// ─────────────────────────────────────────────
function ih_register_post_types() {
	$labels = array(
		'name'                  => _x( 'Teachings', 'Post type general name', 'imam-hussain' ),
		'singular_name'         => _x( 'Teaching', 'Post type singular name', 'imam-hussain' ),
		'menu_name'             => _x( 'Teachings', 'Admin Menu text', 'imam-hussain' ),
		'name_admin_bar'        => _x( 'Teaching', 'Add New on Toolbar', 'imam-hussain' ),
		'add_new'               => __( 'Add New', 'imam-hussain' ),
		'add_new_item'          => __( 'Add New Teaching', 'imam-hussain' ),
		'new_item'              => __( 'New Teaching', 'imam-hussain' ),
		'edit_item'             => __( 'Edit Teaching', 'imam-hussain' ),
		'view_item'             => __( 'View Teaching', 'imam-hussain' ),
		'all_items'             => __( 'All Teachings', 'imam-hussain' ),
		'search_items'          => __( 'Search Teachings', 'imam-hussain' ),
		'not_found'             => __( 'No teachings found.', 'imam-hussain' ),
		'not_found_in_trash'    => __( 'No teachings found in Trash.', 'imam-hussain' ),
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'teachings' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 5,
		'menu_icon'          => 'dashicons-book-alt',
		'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments', 'revisions' ),
		'show_in_rest'       => true,
		'taxonomies'         => array( 'category', 'post_tag' ),
	);

	register_post_type( 'imam-hussain', $args );
}
add_action( 'init', 'ih_register_post_types' );

// ─────────────────────────────────────────────
// Customizer
// ─────────────────────────────────────────────
require_once IH_DIR . '/inc/customizer.php';

// ─────────────────────────────────────────────
// Helper: Get post reading time
// ─────────────────────────────────────────────
function ih_reading_time( $post_id = null ) {
	$post_id  = $post_id ? $post_id : get_the_ID();
	$content  = get_post_field( 'post_content', $post_id );
	$word_count = str_word_count( strip_tags( $content ) );
	$minutes    = (int) ceil( $word_count / 200 );
	return max( 1, $minutes );
}

// ─────────────────────────────────────────────
// Helper: Get category label
// ─────────────────────────────────────────────
function ih_primary_category( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$cats    = get_the_category( $post_id );
	if ( ! empty( $cats ) ) {
		return $cats[0];
	}
	return null;
}

// ─────────────────────────────────────────────
// Custom nav walker for chapter numbers
// ─────────────────────────────────────────────
class IH_Nav_Walker extends Walker_Nav_Menu {

	public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
		$classes = empty( $item->classes ) ? array() : (array) $item->classes;
		$classes[] = 'ih-nav-item';
		if ( in_array( 'current-menu-item', $classes ) ) {
			$classes[] = 'active';
		}

		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );
		$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

		$atts           = array();
		$atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
		$atts['target'] = ! empty( $item->target ) ? $item->target : '';
		$atts['rel']    = ! empty( $item->xfn ) ? $item->xfn : '';
		$atts['href']   = ! empty( $item->url ) ? $item->url : '';
		$atts           = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args );

		$attributes = '';
		foreach ( $atts as $attr => $value ) {
			if ( ! empty( $value ) ) {
				$value       = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
				$attributes .= ' ' . $attr . '="' . $value . '"';
			}
		}

		$position  = isset( $item->menu_order ) ? absint( $item->menu_order ) : $item->menu_order;
		$chapter   = sprintf( '%02d', $position );
		$title     = apply_filters( 'the_title', $item->title, $item->ID );

		$output .= '<li id="menu-item-' . $item->ID . '"' . $class_names . '>';
		$output .= '<a' . $attributes . $class_names . '>';
		$output .= '<span class="chapter">' . $chapter . '</span>';
		$output .= '<span class="label">' . $title . '</span>';
		$output .= '</a>';
	}

	public function end_el( &$output, $item, $depth = 0, $args = array() ) {
		$output .= '</li>';
	}
}

// ─────────────────────────────────────────────
// Add body classes
// ─────────────────────────────────────────────
function ih_body_classes( $classes ) {
	if ( is_singular() ) {
		$classes[] = 'ih-singular';
	}
	return $classes;
}
add_filter( 'body_class', 'ih_body_classes' );

// ─────────────────────────────────────────────
// Excerpt length
// ─────────────────────────────────────────────
function ih_excerpt_length( $length ) {
	return 25;
}
add_filter( 'excerpt_length', 'ih_excerpt_length' );

function ih_excerpt_more( $more ) {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'ih_excerpt_more' );
